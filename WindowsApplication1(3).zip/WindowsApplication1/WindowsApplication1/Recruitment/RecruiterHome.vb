﻿Imports System.Data.OleDb
Public Class RecruiterHome
    Dim ConnInfo As DBConnectionInfo = New DBConnectionInfo
    Dim ConnString As String = ConnInfo.GetConnString()

    'Connection Variable for the database
    Dim con As New OleDbConnection()

    'Variables for the datagridview
    Dim ds As New DataSet
    Dim OledbAdapter As OleDbDataAdapter

    Private Sub FileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FileToolStripMenuItem.Click
        NewJobRequest.Show()
        Me.Hide()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()

    End Sub

    Private Sub BackToHomeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BackToHomeToolStripMenuItem.Click
        Form1.Show()
        Me.Hide()

    End Sub

    Private Sub RecruiterHome_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles SearchB.Click
        Dim StudID As Integer = IDTB.Text

        ApplicationsDG.Refresh()

        Try
            con.ConnectionString = ConnString

            Dim sql As String = "SELECT * FROM Recruitment WHERE StudentID = " & StudID & " AND WHERE TYPE1 = 'A';"

            con.Open()
            OledbAdapter = New OleDbDataAdapter(sql, con)
            OledbAdapter.Fill(ds)
            ApplicationsDG.DataSource = ds.Tables(0)
            ApplicationsDG.Columns(0).Width = 100
            ApplicationsDG.Columns(1).Width = 100
            ApplicationsDG.Columns(2).Width = 100
            ApplicationsDG.Columns(3).Width = 100
            con.Close()
        Catch ex As Exception
            con.Close()
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles SearchALl.Click

        ApplicationsDG.Refresh()
        Try
            con.ConnectionString = ConnString

            Dim sql As String = "SELECT * FROM Recruitment WHERE TYPE1 = 'A';"

            con.Open()
            OledbAdapter = New OleDbDataAdapter(sql, con)
            OledbAdapter.Fill(ds)
            ApplicationsDG.DataSource = ds.Tables(0)
            ApplicationsDG.Columns(0).Width = 100
            ApplicationsDG.Columns(1).Width = 100
            ApplicationsDG.Columns(2).Width = 100
            ApplicationsDG.Columns(3).Width = 100
            con.Close()
        Catch ex As Exception
            con.Close()
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim Year As Integer
        Dim Honors As Boolean
        Dim GPA As Integer = GPATB.Text
        Dim State As String = StateCB.SelectedText
        Dim Move As Boolean
        Dim Major As String = MajorCB.SelectedText

        If GradCB.Checked = True Then
            Year = 1
        End If
        If HonorsCB.checked = True Then
            Honors = 1
        Else Honors = 0
        End If
        If StrictCB.Checked = False Then
            GPA = GPA - 0.25
        End If
        If MoveCB.Checked = True Then
            Move = 1
        Else Move = 0
        End If

        ApplicationsDG.Refresh()
        'Try
        '    con.ConnectionString = ConnString

        '    Dim sql As String = "SELECT * FROM GradStudents WHERE ;"

        '    con.Open()
        '    OledbAdapter = New OleDbDataAdapter(sql, con)
        '    OledbAdapter.Fill(ds)
        '    ApplicationsDG.DataSource = ds.Tables(0)
        '    ApplicationsDG.Columns(0).Width = 100
        '    ApplicationsDG.Columns(1).Width = 100
        '    ApplicationsDG.Columns(2).Width = 100
        '    ApplicationsDG.Columns(3).Width = 100
        '    con.Close()
        'Catch ex As Exception
        '    con.Close()
        '    MessageBox.Show(ex.Message)
        'End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles ApplicationsDG.CellContentClick
        'Here we need to find the matches with the clicked job application

        MatchesDG.Refresh()
        'Try
        '    con.ConnectionString = ConnString

        '    Dim sql As String = "SELECT * FROM GradStudents WHERE ;"

        '    con.Open()
        '    OledbAdapter = New OleDbDataAdapter(sql, con)
        '    OledbAdapter.Fill(ds)
        '    MatchesDG.DataSource = ds.Tables(0)
        '    MatchesDG.Columns(0).Width = 100
        '    MatchesDG.Columns(1).Width = 100
        '    MatchesDG.Columns(2).Width = 100
        '    MatchesDG.Columns(3).Width = 100
        '    con.Close()
        'Catch ex As Exception
        '    con.Close()
        '    MessageBox.Show(ex.Message)
        'End Try

    End Sub

    Private Sub DataGridView2_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles MatchesDG.CellContentDoubleClick
        'Dim the student ID as TempID and make it a global object so that Matches can access it

        'Here we need to open up the matches form so the recruiter could see the details about that student

        Matches.Show()
        Me.Hide()

    End Sub
End Class