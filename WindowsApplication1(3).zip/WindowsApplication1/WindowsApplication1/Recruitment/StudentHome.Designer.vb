﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StudentHome
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ApplicationsDG = New System.Windows.Forms.DataGridView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.CompanyCB = New System.Windows.Forms.ComboBox()
        Me.SearchAll = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SearchB = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.MajorCB = New System.Windows.Forms.ComboBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.StateCB = New System.Windows.Forms.ComboBox()
        Me.MoveCB = New System.Windows.Forms.CheckBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GPATB = New System.Windows.Forms.TextBox()
        Me.StrictCB = New System.Windows.Forms.CheckBox()
        Me.HonorsCB = New System.Windows.Forms.CheckBox()
        Me.GradCB = New System.Windows.Forms.CheckBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackToHomeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MatchesDG = New System.Windows.Forms.DataGridView()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        CType(Me.ApplicationsDG, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.MatchesDG, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ApplicationsDG
        '
        Me.ApplicationsDG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ApplicationsDG.Location = New System.Drawing.Point(13, 132)
        Me.ApplicationsDG.Name = "ApplicationsDG"
        Me.ApplicationsDG.Size = New System.Drawing.Size(346, 410)
        Me.ApplicationsDG.TabIndex = 4
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.CompanyCB)
        Me.GroupBox1.Controls.Add(Me.SearchAll)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.SearchB)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 27)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(220, 86)
        Me.GroupBox1.TabIndex = 21
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Search For My Applications"
        '
        'CompanyCB
        '
        Me.CompanyCB.FormattingEnabled = True
        Me.CompanyCB.Location = New System.Drawing.Point(6, 38)
        Me.CompanyCB.Name = "CompanyCB"
        Me.CompanyCB.Size = New System.Drawing.Size(103, 21)
        Me.CompanyCB.TabIndex = 24
        '
        'SearchAll
        '
        Me.SearchAll.Location = New System.Drawing.Point(115, 52)
        Me.SearchAll.Name = "SearchAll"
        Me.SearchAll.Size = New System.Drawing.Size(100, 23)
        Me.SearchAll.TabIndex = 18
        Me.SearchAll.Text = "See All"
        Me.SearchAll.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(9, 22)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 13)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Company"
        '
        'SearchB
        '
        Me.SearchB.Location = New System.Drawing.Point(114, 22)
        Me.SearchB.Name = "SearchB"
        Me.SearchB.Size = New System.Drawing.Size(100, 23)
        Me.SearchB.TabIndex = 12
        Me.SearchB.Text = "Search Mine"
        Me.SearchB.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.MajorCB)
        Me.GroupBox2.Controls.Add(Me.Button4)
        Me.GroupBox2.Controls.Add(Me.GroupBox4)
        Me.GroupBox2.Controls.Add(Me.GroupBox3)
        Me.GroupBox2.Controls.Add(Me.HonorsCB)
        Me.GroupBox2.Controls.Add(Me.GradCB)
        Me.GroupBox2.Location = New System.Drawing.Point(239, 27)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(488, 86)
        Me.GroupBox2.TabIndex = 22
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Quick Employer Search"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(324, 15)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(33, 13)
        Me.Label7.TabIndex = 21
        Me.Label7.Text = "Major"
        '
        'MajorCB
        '
        Me.MajorCB.FormattingEnabled = True
        Me.MajorCB.Location = New System.Drawing.Point(327, 33)
        Me.MajorCB.Name = "MajorCB"
        Me.MajorCB.Size = New System.Drawing.Size(138, 21)
        Me.MajorCB.TabIndex = 23
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(344, 60)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(99, 24)
        Me.Button4.TabIndex = 22
        Me.Button4.Text = "Search"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.StateCB)
        Me.GroupBox4.Controls.Add(Me.MoveCB)
        Me.GroupBox4.Location = New System.Drawing.Point(184, 15)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(125, 71)
        Me.GroupBox4.TabIndex = 6
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "State"
        '
        'StateCB
        '
        Me.StateCB.FormattingEnabled = True
        Me.StateCB.Items.AddRange(New Object() {"Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "District Of Columbia", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"})
        Me.StateCB.Location = New System.Drawing.Point(7, 18)
        Me.StateCB.Name = "StateCB"
        Me.StateCB.Size = New System.Drawing.Size(104, 21)
        Me.StateCB.TabIndex = 5
        '
        'MoveCB
        '
        Me.MoveCB.AutoSize = True
        Me.MoveCB.Location = New System.Drawing.Point(6, 47)
        Me.MoveCB.Name = "MoveCB"
        Me.MoveCB.Size = New System.Drawing.Size(105, 17)
        Me.MoveCB.TabIndex = 4
        Me.MoveCB.Text = "Willing to Move?"
        Me.MoveCB.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.GPATB)
        Me.GroupBox3.Controls.Add(Me.StrictCB)
        Me.GroupBox3.Location = New System.Drawing.Point(107, 15)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(71, 71)
        Me.GroupBox3.TabIndex = 5
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "GPA"
        '
        'GPATB
        '
        Me.GPATB.Location = New System.Drawing.Point(6, 21)
        Me.GPATB.Name = "GPATB"
        Me.GPATB.Size = New System.Drawing.Size(50, 20)
        Me.GPATB.TabIndex = 3
        '
        'StrictCB
        '
        Me.StrictCB.AutoSize = True
        Me.StrictCB.Location = New System.Drawing.Point(6, 47)
        Me.StrictCB.Name = "StrictCB"
        Me.StrictCB.Size = New System.Drawing.Size(56, 17)
        Me.StrictCB.TabIndex = 4
        Me.StrictCB.Text = "Strict?"
        Me.StrictCB.UseVisualStyleBackColor = True
        '
        'HonorsCB
        '
        Me.HonorsCB.AutoSize = True
        Me.HonorsCB.Location = New System.Drawing.Point(7, 58)
        Me.HonorsCB.Name = "HonorsCB"
        Me.HonorsCB.Size = New System.Drawing.Size(60, 17)
        Me.HonorsCB.TabIndex = 1
        Me.HonorsCB.Text = "Honors"
        Me.HonorsCB.UseVisualStyleBackColor = True
        '
        'GradCB
        '
        Me.GradCB.AutoSize = True
        Me.GradCB.Location = New System.Drawing.Point(7, 32)
        Me.GradCB.Name = "GradCB"
        Me.GradCB.Size = New System.Drawing.Size(78, 17)
        Me.GradCB.TabIndex = 0
        Me.GradCB.Text = "Graduating"
        Me.GradCB.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.BackToHomeToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(742, 24)
        Me.MenuStrip1.TabIndex = 23
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(117, 20)
        Me.FileToolStripMenuItem.Text = "Add New Application"
        '
        'BackToHomeToolStripMenuItem
        '
        Me.BackToHomeToolStripMenuItem.Name = "BackToHomeToolStripMenuItem"
        Me.BackToHomeToolStripMenuItem.Size = New System.Drawing.Size(102, 20)
        Me.BackToHomeToolStripMenuItem.Text = "Back To Welcome"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'MatchesDG
        '
        Me.MatchesDG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.MatchesDG.Location = New System.Drawing.Point(381, 132)
        Me.MatchesDG.Name = "MatchesDG"
        Me.MatchesDG.Size = New System.Drawing.Size(346, 410)
        Me.MatchesDG.TabIndex = 24
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(10, 116)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(81, 13)
        Me.Label5.TabIndex = 18
        Me.Label5.Text = "My Applications"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(378, 116)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(48, 13)
        Me.Label6.TabIndex = 25
        Me.Label6.Text = "Matches"
        '
        'StudentHome
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(742, 558)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.MatchesDG)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.ApplicationsDG)
        Me.Name = "StudentHome"
        Me.Text = "StudentHome"
        CType(Me.ApplicationsDG, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.MatchesDG, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ApplicationsDG As DataGridView
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label3 As Label
    Friend WithEvents SearchB As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents MoveCB As CheckBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GPATB As TextBox
    Friend WithEvents StrictCB As CheckBox
    Friend WithEvents HonorsCB As CheckBox
    Friend WithEvents GradCB As CheckBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MatchesDG As DataGridView
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents SearchAll As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents MajorCB As ComboBox
    Friend WithEvents Button4 As Button
    Friend WithEvents BackToHomeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StateCB As ComboBox
    Friend WithEvents CompanyCB As ComboBox
End Class
