﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NewJobRequest
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UndergradL = New System.Windows.Forms.Label()
        Me.DegreeL = New System.Windows.Forms.Label()
        Me.MDegree2 = New System.Windows.Forms.Label()
        Me.GradL = New System.Windows.Forms.Label()
        Me.Strict2 = New System.Windows.Forms.CheckBox()
        Me.Strict1 = New System.Windows.Forms.CheckBox()
        Me.MoveCB = New System.Windows.Forms.CheckBox()
        Me.JobL1 = New System.Windows.Forms.Label()
        Me.JobTB = New System.Windows.Forms.TextBox()
        Me.JobTB2 = New System.Windows.Forms.TextBox()
        Me.JobL2 = New System.Windows.Forms.Label()
        Me.PayTB = New System.Windows.Forms.TextBox()
        Me.PayL = New System.Windows.Forms.Label()
        Me.PayGB = New System.Windows.Forms.GroupBox()
        Me.SalaryRB = New System.Windows.Forms.RadioButton()
        Me.HourlyRB = New System.Windows.Forms.RadioButton()
        Me.CityL1 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.StateL1 = New System.Windows.Forms.Label()
        Me.UTB = New System.Windows.Forms.TextBox()
        Me.GTB = New System.Windows.Forms.TextBox()
        Me.DegreeCB = New System.Windows.Forms.ComboBox()
        Me.MDegreeCB = New System.Windows.Forms.ComboBox()
        Me.HonorsCB = New System.Windows.Forms.CheckBox()
        Me.SeekingL = New System.Windows.Forms.Label()
        Me.JobL = New System.Windows.Forms.Label()
        Me.Line2L = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Line1L = New System.Windows.Forms.Label()
        Me.CompanyL = New System.Windows.Forms.Label()
        Me.SelectB = New System.Windows.Forms.Button()
        Me.EmployerL = New System.Windows.Forms.Label()
        Me.CompanyTB = New System.Windows.Forms.TextBox()
        Me.CompanyL2 = New System.Windows.Forms.Label()
        Me.EmployerCB = New System.Windows.Forms.ComboBox()
        Me.POCL = New System.Windows.Forms.Label()
        Me.POCTB = New System.Windows.Forms.TextBox()
        Me.PhoneL = New System.Windows.Forms.Label()
        Me.PhoneTB = New System.Windows.Forms.TextBox()
        Me.CreateB = New System.Windows.Forms.Button()
        Me.PostB = New System.Windows.Forms.Button()
        Me.ClearB = New System.Windows.Forms.Button()
        Me.CityL = New System.Windows.Forms.Label()
        Me.CityTB = New System.Windows.Forms.TextBox()
        Me.StateCB = New System.Windows.Forms.ComboBox()
        Me.StateL = New System.Windows.Forms.Label()
        Me.Line3L = New System.Windows.Forms.Label()
        Me.StateCB2 = New System.Windows.Forms.ComboBox()
        Me.MenuStrip1.SuspendLayout()
        Me.PayGB.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(646, 24)
        Me.MenuStrip1.TabIndex = 19
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(41, 20)
        Me.FileToolStripMenuItem.Text = "Back"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'UndergradL
        '
        Me.UndergradL.AutoSize = True
        Me.UndergradL.Location = New System.Drawing.Point(20, 372)
        Me.UndergradL.Name = "UndergradL"
        Me.UndergradL.Size = New System.Drawing.Size(82, 13)
        Me.UndergradL.TabIndex = 439
        Me.UndergradL.Text = "Undergrad GPA"
        Me.UndergradL.Visible = False
        '
        'DegreeL
        '
        Me.DegreeL.AutoSize = True
        Me.DegreeL.Location = New System.Drawing.Point(184, 389)
        Me.DegreeL.Name = "DegreeL"
        Me.DegreeL.Size = New System.Drawing.Size(45, 13)
        Me.DegreeL.TabIndex = 442
        Me.DegreeL.Text = "Degree:"
        Me.DegreeL.Visible = False
        '
        'MDegree2
        '
        Me.MDegree2.AutoSize = True
        Me.MDegree2.Location = New System.Drawing.Point(184, 427)
        Me.MDegree2.Name = "MDegree2"
        Me.MDegree2.Size = New System.Drawing.Size(85, 13)
        Me.MDegree2.TabIndex = 443
        Me.MDegree2.Text = "Masters Degree:"
        Me.MDegree2.Visible = False
        '
        'GradL
        '
        Me.GradL.AutoSize = True
        Me.GradL.Location = New System.Drawing.Point(20, 411)
        Me.GradL.Name = "GradL"
        Me.GradL.Size = New System.Drawing.Size(76, 13)
        Me.GradL.TabIndex = 444
        Me.GradL.Text = "Graduate GPA"
        Me.GradL.Visible = False
        '
        'Strict2
        '
        Me.Strict2.AutoSize = True
        Me.Strict2.Location = New System.Drawing.Point(93, 423)
        Me.Strict2.Name = "Strict2"
        Me.Strict2.Size = New System.Drawing.Size(56, 17)
        Me.Strict2.TabIndex = 445
        Me.Strict2.Text = "Strict?"
        Me.Strict2.UseVisualStyleBackColor = True
        Me.Strict2.Visible = False
        '
        'Strict1
        '
        Me.Strict1.AutoSize = True
        Me.Strict1.Location = New System.Drawing.Point(93, 388)
        Me.Strict1.Name = "Strict1"
        Me.Strict1.Size = New System.Drawing.Size(56, 17)
        Me.Strict1.TabIndex = 446
        Me.Strict1.Text = "Strict?"
        Me.Strict1.UseVisualStyleBackColor = True
        Me.Strict1.Visible = False
        '
        'MoveCB
        '
        Me.MoveCB.AutoSize = True
        Me.MoveCB.Location = New System.Drawing.Point(437, 426)
        Me.MoveCB.Name = "MoveCB"
        Me.MoveCB.Size = New System.Drawing.Size(109, 17)
        Me.MoveCB.TabIndex = 447
        Me.MoveCB.Text = "Willing To Move?"
        Me.MoveCB.UseVisualStyleBackColor = True
        Me.MoveCB.Visible = False
        '
        'JobL1
        '
        Me.JobL1.AutoSize = True
        Me.JobL1.Location = New System.Drawing.Point(20, 223)
        Me.JobL1.Name = "JobL1"
        Me.JobL1.Size = New System.Drawing.Size(55, 13)
        Me.JobL1.TabIndex = 450
        Me.JobL1.Text = "Job Name"
        Me.JobL1.Visible = False
        '
        'JobTB
        '
        Me.JobTB.Location = New System.Drawing.Point(20, 239)
        Me.JobTB.Name = "JobTB"
        Me.JobTB.Size = New System.Drawing.Size(128, 20)
        Me.JobTB.TabIndex = 448
        Me.JobTB.Visible = False
        '
        'JobTB2
        '
        Me.JobTB2.Location = New System.Drawing.Point(158, 239)
        Me.JobTB2.Name = "JobTB2"
        Me.JobTB2.Size = New System.Drawing.Size(378, 20)
        Me.JobTB2.TabIndex = 451
        Me.JobTB2.Visible = False
        '
        'JobL2
        '
        Me.JobL2.AutoSize = True
        Me.JobL2.Location = New System.Drawing.Point(158, 223)
        Me.JobL2.Name = "JobL2"
        Me.JobL2.Size = New System.Drawing.Size(80, 13)
        Me.JobL2.TabIndex = 452
        Me.JobL2.Text = "Job Description"
        Me.JobL2.Visible = False
        '
        'PayTB
        '
        Me.PayTB.Location = New System.Drawing.Point(78, 33)
        Me.PayTB.Name = "PayTB"
        Me.PayTB.Size = New System.Drawing.Size(81, 20)
        Me.PayTB.TabIndex = 453
        '
        'PayL
        '
        Me.PayL.AutoSize = True
        Me.PayL.Location = New System.Drawing.Point(75, 16)
        Me.PayL.Name = "PayL"
        Me.PayL.Size = New System.Drawing.Size(25, 13)
        Me.PayL.TabIndex = 454
        Me.PayL.Text = "Pay"
        '
        'PayGB
        '
        Me.PayGB.Controls.Add(Me.SalaryRB)
        Me.PayGB.Controls.Add(Me.HourlyRB)
        Me.PayGB.Controls.Add(Me.PayL)
        Me.PayGB.Controls.Add(Me.PayTB)
        Me.PayGB.Location = New System.Drawing.Point(20, 265)
        Me.PayGB.Name = "PayGB"
        Me.PayGB.Size = New System.Drawing.Size(184, 64)
        Me.PayGB.TabIndex = 457
        Me.PayGB.TabStop = False
        Me.PayGB.Text = "Hourly/Salary"
        Me.PayGB.Visible = False
        '
        'SalaryRB
        '
        Me.SalaryRB.AutoSize = True
        Me.SalaryRB.Location = New System.Drawing.Point(8, 41)
        Me.SalaryRB.Name = "SalaryRB"
        Me.SalaryRB.Size = New System.Drawing.Size(54, 17)
        Me.SalaryRB.TabIndex = 456
        Me.SalaryRB.TabStop = True
        Me.SalaryRB.Text = "Salary"
        Me.SalaryRB.UseVisualStyleBackColor = True
        '
        'HourlyRB
        '
        Me.HourlyRB.AutoSize = True
        Me.HourlyRB.Location = New System.Drawing.Point(8, 20)
        Me.HourlyRB.Name = "HourlyRB"
        Me.HourlyRB.Size = New System.Drawing.Size(55, 17)
        Me.HourlyRB.TabIndex = 455
        Me.HourlyRB.TabStop = True
        Me.HourlyRB.Text = "Hourly"
        Me.HourlyRB.UseVisualStyleBackColor = True
        '
        'CityL1
        '
        Me.CityL1.AutoSize = True
        Me.CityL1.Location = New System.Drawing.Point(217, 281)
        Me.CityL1.Name = "CityL1"
        Me.CityL1.Size = New System.Drawing.Size(24, 13)
        Me.CityL1.TabIndex = 459
        Me.CityL1.Text = "City"
        Me.CityL1.Visible = False
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(217, 298)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(89, 20)
        Me.TextBox3.TabIndex = 458
        Me.TextBox3.Visible = False
        '
        'StateL1
        '
        Me.StateL1.AutoSize = True
        Me.StateL1.Location = New System.Drawing.Point(333, 281)
        Me.StateL1.Name = "StateL1"
        Me.StateL1.Size = New System.Drawing.Size(32, 13)
        Me.StateL1.TabIndex = 461
        Me.StateL1.Text = "State"
        Me.StateL1.Visible = False
        '
        'UTB
        '
        Me.UTB.Location = New System.Drawing.Point(20, 385)
        Me.UTB.Name = "UTB"
        Me.UTB.Size = New System.Drawing.Size(56, 20)
        Me.UTB.TabIndex = 462
        Me.UTB.Visible = False
        '
        'GTB
        '
        Me.GTB.Location = New System.Drawing.Point(20, 427)
        Me.GTB.Name = "GTB"
        Me.GTB.Size = New System.Drawing.Size(56, 20)
        Me.GTB.TabIndex = 463
        Me.GTB.Visible = False
        '
        'DegreeCB
        '
        Me.DegreeCB.FormattingEnabled = True
        Me.DegreeCB.Location = New System.Drawing.Point(290, 384)
        Me.DegreeCB.Name = "DegreeCB"
        Me.DegreeCB.Size = New System.Drawing.Size(141, 21)
        Me.DegreeCB.TabIndex = 464
        Me.DegreeCB.Visible = False
        '
        'MDegreeCB
        '
        Me.MDegreeCB.FormattingEnabled = True
        Me.MDegreeCB.Location = New System.Drawing.Point(290, 424)
        Me.MDegreeCB.Name = "MDegreeCB"
        Me.MDegreeCB.Size = New System.Drawing.Size(141, 21)
        Me.MDegreeCB.TabIndex = 465
        Me.MDegreeCB.Visible = False
        '
        'HonorsCB
        '
        Me.HonorsCB.AutoSize = True
        Me.HonorsCB.Location = New System.Drawing.Point(437, 389)
        Me.HonorsCB.Name = "HonorsCB"
        Me.HonorsCB.Size = New System.Drawing.Size(66, 17)
        Me.HonorsCB.TabIndex = 466
        Me.HonorsCB.Text = "Honors?"
        Me.HonorsCB.UseVisualStyleBackColor = True
        Me.HonorsCB.Visible = False
        '
        'SeekingL
        '
        Me.SeekingL.AutoSize = True
        Me.SeekingL.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SeekingL.Location = New System.Drawing.Point(20, 345)
        Me.SeekingL.Name = "SeekingL"
        Me.SeekingL.Size = New System.Drawing.Size(65, 16)
        Me.SeekingL.TabIndex = 467
        Me.SeekingL.Text = "Seeking"
        Me.SeekingL.Visible = False
        '
        'JobL
        '
        Me.JobL.AutoSize = True
        Me.JobL.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.JobL.Location = New System.Drawing.Point(20, 200)
        Me.JobL.Name = "JobL"
        Me.JobL.Size = New System.Drawing.Size(34, 16)
        Me.JobL.TabIndex = 468
        Me.JobL.Text = "Job"
        Me.JobL.Visible = False
        '
        'Line2L
        '
        Me.Line2L.AutoSize = True
        Me.Line2L.Location = New System.Drawing.Point(20, 170)
        Me.Line2L.Name = "Line2L"
        Me.Line2L.Size = New System.Drawing.Size(769, 13)
        Me.Line2L.TabIndex = 469
        Me.Line2L.Text = "_________________________________________________________________________________" &
    "______________________________________________"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(15, 28)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(74, 16)
        Me.Label10.TabIndex = 470
        Me.Label10.Text = "Employer"
        '
        'Line1L
        '
        Me.Line1L.AutoSize = True
        Me.Line1L.Location = New System.Drawing.Point(20, 70)
        Me.Line1L.Name = "Line1L"
        Me.Line1L.Size = New System.Drawing.Size(289, 13)
        Me.Line1L.TabIndex = 472
        Me.Line1L.Text = "_______________________________________________" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'CompanyL
        '
        Me.CompanyL.AutoSize = True
        Me.CompanyL.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CompanyL.Location = New System.Drawing.Point(317, 189)
        Me.CompanyL.Name = "CompanyL"
        Me.CompanyL.Size = New System.Drawing.Size(16, 16)
        Me.CompanyL.TabIndex = 475
        Me.CompanyL.Text = "_"
        Me.CompanyL.Visible = False
        '
        'SelectB
        '
        Me.SelectB.Location = New System.Drawing.Point(205, 47)
        Me.SelectB.Name = "SelectB"
        Me.SelectB.Size = New System.Drawing.Size(75, 23)
        Me.SelectB.TabIndex = 476
        Me.SelectB.Text = "Select"
        Me.SelectB.UseVisualStyleBackColor = True
        '
        'EmployerL
        '
        Me.EmployerL.AutoSize = True
        Me.EmployerL.Location = New System.Drawing.Point(20, 96)
        Me.EmployerL.Name = "EmployerL"
        Me.EmployerL.Size = New System.Drawing.Size(109, 13)
        Me.EmployerL.TabIndex = 477
        Me.EmployerL.Text = "Create New Employer"
        '
        'CompanyTB
        '
        Me.CompanyTB.Location = New System.Drawing.Point(20, 134)
        Me.CompanyTB.Name = "CompanyTB"
        Me.CompanyTB.Size = New System.Drawing.Size(117, 20)
        Me.CompanyTB.TabIndex = 478
        '
        'CompanyL2
        '
        Me.CompanyL2.AutoSize = True
        Me.CompanyL2.Location = New System.Drawing.Point(20, 118)
        Me.CompanyL2.Name = "CompanyL2"
        Me.CompanyL2.Size = New System.Drawing.Size(82, 13)
        Me.CompanyL2.TabIndex = 479
        Me.CompanyL2.Text = "Company Name"
        '
        'EmployerCB
        '
        Me.EmployerCB.FormattingEnabled = True
        Me.EmployerCB.Location = New System.Drawing.Point(20, 49)
        Me.EmployerCB.Name = "EmployerCB"
        Me.EmployerCB.Size = New System.Drawing.Size(156, 21)
        Me.EmployerCB.TabIndex = 480
        '
        'POCL
        '
        Me.POCL.AutoSize = True
        Me.POCL.Location = New System.Drawing.Point(163, 118)
        Me.POCL.Name = "POCL"
        Me.POCL.Size = New System.Drawing.Size(83, 13)
        Me.POCL.TabIndex = 482
        Me.POCL.Text = "Point of Contact"
        '
        'POCTB
        '
        Me.POCTB.Location = New System.Drawing.Point(161, 134)
        Me.POCTB.Name = "POCTB"
        Me.POCTB.Size = New System.Drawing.Size(117, 20)
        Me.POCTB.TabIndex = 481
        '
        'PhoneL
        '
        Me.PhoneL.AutoSize = True
        Me.PhoneL.Location = New System.Drawing.Point(296, 118)
        Me.PhoneL.Name = "PhoneL"
        Me.PhoneL.Size = New System.Drawing.Size(38, 13)
        Me.PhoneL.TabIndex = 484
        Me.PhoneL.Text = "Phone"
        '
        'PhoneTB
        '
        Me.PhoneTB.Location = New System.Drawing.Point(294, 134)
        Me.PhoneTB.Name = "PhoneTB"
        Me.PhoneTB.Size = New System.Drawing.Size(117, 20)
        Me.PhoneTB.TabIndex = 483
        '
        'CreateB
        '
        Me.CreateB.Location = New System.Drawing.Point(277, 160)
        Me.CreateB.Name = "CreateB"
        Me.CreateB.Size = New System.Drawing.Size(75, 23)
        Me.CreateB.TabIndex = 485
        Me.CreateB.Text = "Create"
        Me.CreateB.UseVisualStyleBackColor = True
        '
        'PostB
        '
        Me.PostB.Location = New System.Drawing.Point(559, 435)
        Me.PostB.Name = "PostB"
        Me.PostB.Size = New System.Drawing.Size(75, 23)
        Me.PostB.TabIndex = 486
        Me.PostB.Text = "Post"
        Me.PostB.UseVisualStyleBackColor = True
        Me.PostB.Visible = False
        '
        'ClearB
        '
        Me.ClearB.Location = New System.Drawing.Point(559, 406)
        Me.ClearB.Name = "ClearB"
        Me.ClearB.Size = New System.Drawing.Size(75, 23)
        Me.ClearB.TabIndex = 487
        Me.ClearB.Text = "Clear"
        Me.ClearB.UseVisualStyleBackColor = True
        Me.ClearB.Visible = False
        '
        'CityL
        '
        Me.CityL.AutoSize = True
        Me.CityL.Location = New System.Drawing.Point(420, 118)
        Me.CityL.Name = "CityL"
        Me.CityL.Size = New System.Drawing.Size(24, 13)
        Me.CityL.TabIndex = 489
        Me.CityL.Text = "City"
        '
        'CityTB
        '
        Me.CityTB.Location = New System.Drawing.Point(418, 134)
        Me.CityTB.Name = "CityTB"
        Me.CityTB.Size = New System.Drawing.Size(117, 20)
        Me.CityTB.TabIndex = 488
        '
        'StateCB
        '
        Me.StateCB.FormattingEnabled = True
        Me.StateCB.Items.AddRange(New Object() {"Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "District Of Columbia", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"})
        Me.StateCB.Location = New System.Drawing.Point(542, 134)
        Me.StateCB.Name = "StateCB"
        Me.StateCB.Size = New System.Drawing.Size(104, 21)
        Me.StateCB.TabIndex = 490
        '
        'StateL
        '
        Me.StateL.AutoSize = True
        Me.StateL.Location = New System.Drawing.Point(539, 118)
        Me.StateL.Name = "StateL"
        Me.StateL.Size = New System.Drawing.Size(32, 13)
        Me.StateL.TabIndex = 491
        Me.StateL.Text = "State"
        '
        'Line3L
        '
        Me.Line3L.AutoSize = True
        Me.Line3L.Location = New System.Drawing.Point(20, 332)
        Me.Line3L.Name = "Line3L"
        Me.Line3L.Size = New System.Drawing.Size(769, 13)
        Me.Line3L.TabIndex = 492
        Me.Line3L.Text = "_________________________________________________________________________________" &
    "______________________________________________"
        '
        'StateCB2
        '
        Me.StateCB2.FormattingEnabled = True
        Me.StateCB2.Items.AddRange(New Object() {"Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "District Of Columbia", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"})
        Me.StateCB2.Location = New System.Drawing.Point(333, 297)
        Me.StateCB2.Name = "StateCB2"
        Me.StateCB2.Size = New System.Drawing.Size(127, 21)
        Me.StateCB2.TabIndex = 493
        '
        'NewJobRequest
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(646, 465)
        Me.Controls.Add(Me.StateCB2)
        Me.Controls.Add(Me.Line3L)
        Me.Controls.Add(Me.StateL)
        Me.Controls.Add(Me.StateCB)
        Me.Controls.Add(Me.CityL)
        Me.Controls.Add(Me.CityTB)
        Me.Controls.Add(Me.ClearB)
        Me.Controls.Add(Me.PostB)
        Me.Controls.Add(Me.CreateB)
        Me.Controls.Add(Me.PhoneL)
        Me.Controls.Add(Me.PhoneTB)
        Me.Controls.Add(Me.POCL)
        Me.Controls.Add(Me.POCTB)
        Me.Controls.Add(Me.EmployerCB)
        Me.Controls.Add(Me.CompanyL2)
        Me.Controls.Add(Me.CompanyTB)
        Me.Controls.Add(Me.EmployerL)
        Me.Controls.Add(Me.SelectB)
        Me.Controls.Add(Me.CompanyL)
        Me.Controls.Add(Me.Line1L)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Line2L)
        Me.Controls.Add(Me.JobL)
        Me.Controls.Add(Me.SeekingL)
        Me.Controls.Add(Me.HonorsCB)
        Me.Controls.Add(Me.MDegreeCB)
        Me.Controls.Add(Me.DegreeCB)
        Me.Controls.Add(Me.GTB)
        Me.Controls.Add(Me.UTB)
        Me.Controls.Add(Me.StateL1)
        Me.Controls.Add(Me.CityL1)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.PayGB)
        Me.Controls.Add(Me.JobL2)
        Me.Controls.Add(Me.JobTB2)
        Me.Controls.Add(Me.JobL1)
        Me.Controls.Add(Me.JobTB)
        Me.Controls.Add(Me.MoveCB)
        Me.Controls.Add(Me.Strict1)
        Me.Controls.Add(Me.Strict2)
        Me.Controls.Add(Me.GradL)
        Me.Controls.Add(Me.MDegree2)
        Me.Controls.Add(Me.DegreeL)
        Me.Controls.Add(Me.UndergradL)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "NewJobRequest"
        Me.Text = "NewJobRequest"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.PayGB.ResumeLayout(False)
        Me.PayGB.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UndergradL As Label
    Friend WithEvents DegreeL As Label
    Friend WithEvents MDegree2 As Label
    Friend WithEvents GradL As Label
    Friend WithEvents Strict2 As CheckBox
    Friend WithEvents Strict1 As CheckBox
    Friend WithEvents MoveCB As CheckBox
    Friend WithEvents JobL1 As Label
    Friend WithEvents JobTB As TextBox
    Friend WithEvents JobTB2 As TextBox
    Friend WithEvents JobL2 As Label
    Friend WithEvents PayTB As TextBox
    Friend WithEvents PayL As Label
    Friend WithEvents PayGB As GroupBox
    Friend WithEvents SalaryRB As RadioButton
    Friend WithEvents HourlyRB As RadioButton
    Friend WithEvents CityL1 As Label
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents StateL1 As Label
    Friend WithEvents UTB As TextBox
    Friend WithEvents GTB As TextBox
    Friend WithEvents DegreeCB As ComboBox
    Friend WithEvents MDegreeCB As ComboBox
    Friend WithEvents HonorsCB As CheckBox
    Friend WithEvents SeekingL As Label
    Friend WithEvents JobL As Label
    Friend WithEvents Line2L As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Line1L As Label
    Friend WithEvents CompanyL As Label
    Friend WithEvents SelectB As Button
    Friend WithEvents EmployerL As Label
    Friend WithEvents CompanyTB As TextBox
    Friend WithEvents CompanyL2 As Label
    Friend WithEvents EmployerCB As ComboBox
    Friend WithEvents POCL As Label
    Friend WithEvents POCTB As TextBox
    Friend WithEvents PhoneL As Label
    Friend WithEvents PhoneTB As TextBox
    Friend WithEvents CreateB As Button
    Friend WithEvents PostB As Button
    Friend WithEvents ClearB As Button
    Friend WithEvents CityL As Label
    Friend WithEvents CityTB As TextBox
    Friend WithEvents StateCB As ComboBox
    Friend WithEvents StateL As Label
    Friend WithEvents Line3L As Label
    Friend WithEvents StateCB2 As ComboBox
End Class
