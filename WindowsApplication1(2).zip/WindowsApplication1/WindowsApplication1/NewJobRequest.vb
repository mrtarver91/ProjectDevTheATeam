﻿Imports System.Data.OleDb
Public Class NewJobRequest
    Dim ConnInfo As DBConnectionInfo = New DBConnectionInfo
    Dim ConnString As String = ConnInfo.GetConnString()

    'Connection Variable for the database
    Dim con As New OleDbConnection()

    Private Sub FileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FileToolStripMenuItem.Click
        RecruiterHome.Show()
        Me.Hide()
    End Sub

    Private Sub CheckBox4_CheckedChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles SelectB.Click
        Dim CompanyName As String = EmployerCB.SelectedText

        Try
            Dim Command As New OleDbCommand("SELECT CompanyName from Company;", con)
            Dim Dr As OleDbDataReader

            'Open Connection String
            con.ConnectionString = ConnString
            con.Open()

            'Select the Records from the DB
            Dr = Command.ExecuteReader

            While Dr.Read()
                CompanyL.Text = (Dr.GetString(0))
            End While
            con.Close()

            JobL.Visible = True
            JobL1.Visible = True
            JobL2.Visible = True
            ClearB.Visible = True
            PostB.Visible = True
            JobTB.Visible = True
            JobTB2.Visible = True
            PayGB.Visible = True
            HourlyRB.Visible = True
            SalaryRB.Visible = True
            CityL.Visible = True
            StateL.Visible = True
            CityTB.Visible = True
            StateCB2.Visible = True
            Line2L.Visible = True
            Line3L.Visible = True
            SeekingL.Visible = True
            UndergradL.Visible = True
            GradL.Visible = True
            UTB.Visible = True
            GTB.Visible = True
            Strict1.Visible = True
            Strict2.Visible = True
            DegreeCB.Visible = True
            DegreeL.Visible = True
            MDegree2.Visible = True
            MDegreeCB.Visible = True
            HonorsCB.Visible = True
            MoveCB.Visible = True

            EmployerL.Visible = False
            CompanyTB.Visible = False
            PhoneL.Visible = False
            PhoneTB.Visible = False
            CityL.Visible = False
            CityTB.Visible = False
            StateL.Visible = False
            StateCB2.Visible = False

        Catch ex As Exception
            'MessageBox.Show(ex.Message())
            con.Close()
            JobL.Visible = False
            JobL1.Visible = False
            JobL2.Visible = False
            ClearB.Visible = False
            PostB.Visible = False
            JobTB.Visible = False
            JobTB2.Visible = False
            PayGB.Visible = False
            HourlyRB.Visible = False
            SalaryRB.Visible = False
            CityL.Visible = False
            StateL.Visible = False
            CityTB.Visible = False
            StateCB2.Visible = False
            Line2L.Visible = False
            Line3L.Visible = False
            SeekingL.Visible = False
            UndergradL.Visible = False
            GradL.Visible = False
            UTB.Visible = False
            GTB.Visible = False
            Strict1.Visible = False
            Strict2.Visible = False
            DegreeCB.Visible = False
            DegreeL.Visible = False
            MDegree2.Visible = False
            MDegreeCB.Visible = False
            HonorsCB.Visible = False
            MoveCB.Visible = False

            EmployerCB.Select()
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles CreateB.Click
        Dim Company As String = CompanyTB.Text
        Dim POC As String = POCTB.Text
        Dim Phone As Date = PhoneTB.Text
        Dim City As Date = CityTB.Text
        Dim State As Date = StateCB.SelectedText

        Try

            Dim Command As New OleDbCommand("INSERT INTO Company(CompanName, POC, Phone, City, State) VALUES('" & Company & "','" & POC & "','" & Phone & "','" & City & "','" & State & "');", con)
            Dim Dr As OleDbDataReader

            'Open Connection String
            con.ConnectionString = ConnString
            con.Open()

            'Select the Records from the DB
            Command.ExecuteNonQuery()
            MessageBox.Show("Welcome! And Good luck!", "Resume Successfully posted", MessageBoxButtons.OK)
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message())
            con.Close()
        End Try






    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles ClearB.Click

        JobTB.Clear()
        JobTB2.Clear()
        HourlyRB.Checked = False
        SalaryRB.Checked = False
        PayTB.Clear()
        CityTB.Clear()
        StateCB2.SelectedIndex = -1
        UTB.Clear()
        GTB.Clear()
        Strict1.Checked = False
        Strict2.Checked = False
        DegreeCB.SelectedIndex = -1
        MDegreeCB.SelectedIndex = -1
        HonorsCB.Checked = False
        MoveCB.Checked = False


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles PostB.Click
        Dim JobName As String = JobTB.Text
        Dim JobDescription As String = JobTB2.Text
        Dim Hourly As Boolean
        Dim Salary As Boolean
        Dim Pay As String = PayTB.Text
        Dim City As String = CityTB.Text
        Dim State As String = StateCB2.SelectedText
        Dim UGPA As String = UTB.Text
        Dim GGPA As String = GTB.Text
        Dim UStrict As Boolean
        Dim MStrict As Boolean
        Dim Degree As String = DegreeCB.SelectedText
        Dim MDegree As String = MDegreeCB.SelectedText

        Try

            Dim Command As New OleDbCommand("INSERT INTO Recruitment(CompanyName, JobNameR, JobDescriptionR, HourlyR, SalaryR, PayR, CityR, StateR, UGPAR, GGPAR, UDegreeR, GDegreeR, HonorsR, MoveR) VALUES('" & CompanyName & "','" & JobName & "','" & JobDescription & "','" & Hourly & "','" & Salary & "','" & Pay & "','" & City & "', '" & State & "','" & UGPA & "','" & GGPA & "','" & UStrict & "','" & MStrict & "','" & Degree & "','" & MDegree & "');", con)
            Dim Dr As OleDbDataReader

            'Open Connection String
            con.ConnectionString = ConnString
            con.Open()

            'Select the Records from the DB
            Command.ExecuteNonQuery()
            MessageBox.Show("Welcome! And Good luck!", "Resume Successfully posted", MessageBoxButtons.OK)
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message())
            con.Close()
        End Try
    End Sub

    Private Sub NewJobRequest_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class