﻿Imports System.Data.OleDb
Public Class DBConnectionInfo
    'These are constant variables (unchangable)
    'My username/password for accessing the database
    Private Const username As String = "ISYS4283232"
    Private Const password As String = "KG75zm$"
    Private Const database As String = "ISYS4283232"


    'Connection string for establishing the connection with the database
    Private ConnString = "Provider =SQLNCLI11;Server=msenterprise.waltoncollege.uark.edu;Database=" & database & ";UID=" & username & ";PWD=" & password & ";"

    Public Function GetConnString() As String
        Return ConnString
    End Function
End Class
