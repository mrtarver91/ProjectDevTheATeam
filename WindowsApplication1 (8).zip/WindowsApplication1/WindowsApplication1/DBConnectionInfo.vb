﻿Public Class DBConnectionInfo



    Private Const username As String = "ISYS4283232"
    Private Const password As String = "KG75zm$"
    Private Const database As String = "ISYS4283232"

    'Connection String for connecting to the DB
    Private Const ConnString As String = "Provider =SQLNCLI11;Server=msenterprise.waltoncollege.uark.edu;Database=" + database + ";UID=" + username + ";PWD=" + password + ";"


    Public Function GetConnString() As String
        Return ConnString
    End Function

End Class
