﻿
Imports System.Data.OleDb

Public Class Advisors
    'Declares variables for application

    Dim RowsInsertedInteger = 0

    'Declares variables for application


    'Connection variables for the database
    Dim con As New OleDbConnection()

    'This goes to the connection class file and gets the connection string with username/password
    Dim ConnInfo As DBConnectionInfo = New DBConnectionInfo
    Dim ConnString As String = ConnInfo.GetConnString()

    'These are variables for the datagrid view

    Dim oledbAdapter As OleDbDataAdapter
    Dim sqlstring As String

    Private Sub PostToDB_Course()
        'This is where you would put all code to be executed
        Try
            'Create a SQL command to insert the new student information
            Dim command As New OleDbCommand("INSERT INTO GRADSTUDENTS (STUDENTID, LASTNAME, MIDDLENAME, FIRSTNAME, SSN, DOB, BIRTHPLACE, RACE, GENDER, CITIZENSHIP, PERMADDRESS, PERMCITY, PERMZIPCODE,PERMSTATE, YEARSATPERM,MAILADDRESS,MAILCITY, MAILSTATE,MAILZIPCODE, FORMERADDRESS, FORMERCITY, FORMERSTATE,FORMERZIPCODE,YEARSATFORMER,ARRESIDENT,HOMEPHONE,CELLPHONE,EMAIL,HISORLATIN, ADMITREQYEAR,ADMITREQTERM,ADMITREQPROGRAM,APPLIEDWHEN,PREVENROLL,APPLIEDBEFORE,PREVENROLLWHEN,PREVENROLLLEVEL,COLLEGE1,COLLEGE2,COLLEGE1HOURS,COLLEGE2HOURS,COLLEGE1GPA,COLLEGE2GPA,COLLEGE1GRADUATED,COLLEGE2GRADUATED,COLLEGE1DEGREE,COLLEGE2DEGREE,COLLEGE1DATET,COLLEGE1DATEF,COLLEGE2DATET,COLLEGE2DATEF,GMATDATE,TOEFLDATE,GREDATE,GMAT,TOEFL,GRE,APPLICFORM,APPLICFEE,RESUME,LORS,TRANSCRIPTS,ESSAYQ,GMATGRE,EDUEXP,SUPPFINNFORM,TOEFLINCLU) VALUES (" & Me.txtStudentID.Text & ",'" & Me.txtLastName.Text & "','" & Me.txtMiddleName.Text & "','" & Me.txtFirstName.Text & "','" & Me.txtSSN.Text & "','" & Me.txtBirthday1.Text & "','" & Me.cbxOrigin.Text & "','" & Me.cbxEthnic.Text & "','" & Me.cbxGender.Text & "','" & Me.cbxCitizenship.Text & "','" & Me.txtPAddress.Text & "','" & Me.txtPCity.Text & "','" & Me.txtPZipCode.Text & "','" & Me.cbxPState.Text & "','" & Me.txtPYears.Text & "','" & Me.txtLAddress.Text & "','" & Me.txtLCity.Text & "','" & Me.cbxLState.Text & "','" & Me.txtLZipCode.Text & "','" & Me.txtFAddress.Text & "','" & Me.txtFCity.Text & "','" & Me.cbxFState.Text & "','" & Me.txtFZipCode.Text & "','" & Me.txtFYears.Text & "','" & Me.chkResident.Checked.ToString & "','" & Me.txtCurrentPhone.Text & "','" & Me.txtWorkPhone.Text & "','" & Me.txtEmail.Text & "','" & Me.chbxHisorLatin.Checked.ToString & "' ,'" & Me.txtRequestYear.Text & "','" & Me.cbxSession.Text & "','" & Me.cbxReqProgram.Text & "','" & Me.txtBefore_when.Text & "','" & Me.chkBefore.Checked.ToString & "' ,'" & Me.chkEnrolled.Checked.ToString & "' ,'" & Me.txtEnrolled_When.Text & "','" & Me.cbxStanding.Text & "','" & Me.txtCName1.Text & "','" & Me.txtCName2.Text & "','" & Me.txtHoursEarned1.Text & "','" & Me.txtHoursEarned2.Text & "''" & Me.txtCGPA1.Text & "','" & Me.txtCGPA2.Text & "','" & Me.ckbGraduated1.Checked.ToString & "' ,'" & Me.ckbGraduated2.Checked.ToString & "','" & Me.txtDegree1.Text & "' ,'" & Me.txtDegree2.Text & "' ,'" & Me.txtCTo1.Text & "','" & Me.txtCFrom1.Text & "','" & Me.txtCTo2.Text & "','" & Me.txtCFrom2.Text & "','" & Me.txtGMATDate.Text & "','" & Me.txtTOEFLDate.Text & "','" & Me.txtTSEDate.Text & "' ,'" & Me.txtGMATTotal.Text & "','" & Me.txtTOEFLTotal.Text & "','" & Me.txtTSETotal.Text & "' ,'" & Me.chkAppForm.Checked.ToString & "','" & Me.chkAppFeePaid.Checked.ToString & "','" & Me.chkResume.Checked.ToString & "','" & Me.chkLOR.Checked.ToString & "','" & Me.chkTranscript.Checked.ToString & "','" & Me.chkEssay.Checked.ToString & "','" & Me.chkGMATScore.Checked.ToString & "','" & Me.chkEducation.Checked.ToString & "','" & Me.chkFinancial.Checked.ToString & "','" & Me.chkTOEFL.Checked.ToString & "');", con)
            MessageBox.Show(command.CommandText.ToString())

            'Another method of inserting fields into the database
            'Dim command As New OleDbCommand("INSERT INTO COURSE (NA ME,CLSTIME,ROOM,TID)" & "VALUES(?, ?, ?, ?)", con)
            'command.Parameters.AddWithValue("NAME", NAME1)
            'command.Parameters.AddWithValue("CLSTIME", CLSTIME)
            'command.Parameters.AddWithValue("ROOM", ROOM)
            'command.Parameters.AddWithValue("TID", TID)



            'Insert a new record into the database table
            'Opens connection to the database
            con.ConnectionString = ConnString
            con.Open()

            'Execute the Insert Statement in the command variable
            RowsInsertedInteger = command.ExecuteNonQuery()

            'Close the connection
            con.Close()

        Catch ex As Exception
            'This is what happens if there is an error
            MessageBox.Show("Error in saving information to the database: " & ex.Message)
            con.Close()
        Finally
            'If all else fails, this will run
            'Close DB Connection here
            con.Close()
        End Try
    End Sub



    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()

    End Sub

    Private Sub InsertButton_Click(sender As Object, e As EventArgs) Handles InsertButton.Click
        PostToDB_Course()
    End Sub
End Class