﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Advisors
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.chbGraduated2 = New System.Windows.Forms.TabPage()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtRequestYear = New System.Windows.Forms.TextBox()
        Me.chkBefore = New System.Windows.Forms.CheckBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtBefore_when = New System.Windows.Forms.TextBox()
        Me.chkEnrolled = New System.Windows.Forms.CheckBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.txtEnrolled_When = New System.Windows.Forms.TextBox()
        Me.cbxSession = New System.Windows.Forms.ComboBox()
        Me.lblSession = New System.Windows.Forms.Label()
        Me.cbxStanding = New System.Windows.Forms.ComboBox()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.cbxReqProgram = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tabPersonalInfo = New System.Windows.Forms.TabPage()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.lblMiddleName = New System.Windows.Forms.Label()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtMiddleName = New System.Windows.Forms.TextBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblSSN = New System.Windows.Forms.Label()
        Me.lblDOB = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cbxEthnic = New System.Windows.Forms.ComboBox()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.txtPAddress = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtPCity = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtPYears = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtFAddress = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtFCity = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.chkResident = New System.Windows.Forms.CheckBox()
        Me.txtLAddress = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtLCity = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.txtFYears = New System.Windows.Forms.TextBox()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.txtStudentID = New System.Windows.Forms.TextBox()
        Me.cbxGender = New System.Windows.Forms.ComboBox()
        Me.cbxCitizenship = New System.Windows.Forms.ComboBox()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.cbxOrigin = New System.Windows.Forms.ComboBox()
        Me.txtSSN = New System.Windows.Forms.MaskedTextBox()
        Me.txtBirthday1 = New System.Windows.Forms.MaskedTextBox()
        Me.txtCurrentPhone = New System.Windows.Forms.MaskedTextBox()
        Me.txtWorkPhone = New System.Windows.Forms.MaskedTextBox()
        Me.txtFZipCode = New System.Windows.Forms.MaskedTextBox()
        Me.txtLZipCode = New System.Windows.Forms.MaskedTextBox()
        Me.txtPZipCode = New System.Windows.Forms.MaskedTextBox()
        Me.cbxPState = New System.Windows.Forms.ComboBox()
        Me.cbxLState = New System.Windows.Forms.ComboBox()
        Me.cbxFState = New System.Windows.Forms.ComboBox()
        Me.lblBirthdayFormat = New System.Windows.Forms.Label()
        Me.chbxHisorLatin = New System.Windows.Forms.CheckBox()
        Me.tabApplication = New System.Windows.Forms.TabControl()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.txtTSEDate = New System.Windows.Forms.TextBox()
        Me.txtTOEFLDate = New System.Windows.Forms.TextBox()
        Me.txtGMATTotal = New System.Windows.Forms.TextBox()
        Me.txtTSETotal = New System.Windows.Forms.TextBox()
        Me.txtTOEFLTotal = New System.Windows.Forms.TextBox()
        Me.txtGMATDate = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chkAppForm = New System.Windows.Forms.CheckBox()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.chkAppFeePaid = New System.Windows.Forms.CheckBox()
        Me.chkResume = New System.Windows.Forms.CheckBox()
        Me.chkLOR = New System.Windows.Forms.CheckBox()
        Me.chkTranscript = New System.Windows.Forms.CheckBox()
        Me.chkEssay = New System.Windows.Forms.CheckBox()
        Me.chkGMATScore = New System.Windows.Forms.CheckBox()
        Me.chkEducation = New System.Windows.Forms.CheckBox()
        Me.chkFinancial = New System.Windows.Forms.CheckBox()
        Me.chkTOEFL = New System.Windows.Forms.CheckBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.txtCFrom1 = New System.Windows.Forms.TextBox()
        Me.txtCFrom2 = New System.Windows.Forms.TextBox()
        Me.txtCTo1 = New System.Windows.Forms.TextBox()
        Me.txtCTo2 = New System.Windows.Forms.TextBox()
        Me.txtCurrentHours2 = New System.Windows.Forms.TextBox()
        Me.txtCurrentHours1 = New System.Windows.Forms.TextBox()
        Me.txtDegree2 = New System.Windows.Forms.TextBox()
        Me.txtDegree1 = New System.Windows.Forms.TextBox()
        Me.txtHoursEarned2 = New System.Windows.Forms.TextBox()
        Me.txtHoursEarned1 = New System.Windows.Forms.TextBox()
        Me.txtCGPA2 = New System.Windows.Forms.TextBox()
        Me.txtCGPA1 = New System.Windows.Forms.TextBox()
        Me.txtCName2 = New System.Windows.Forms.TextBox()
        Me.txtCName1 = New System.Windows.Forms.TextBox()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.InsertButton = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ckbGraduated1 = New System.Windows.Forms.CheckBox()
        Me.ckbGraduated2 = New System.Windows.Forms.CheckBox()
        Me.chbGraduated2.SuspendLayout()
        Me.tabPersonalInfo.SuspendLayout()
        Me.tabApplication.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'chbGraduated2
        '
        Me.chbGraduated2.Controls.Add(Me.ckbGraduated2)
        Me.chbGraduated2.Controls.Add(Me.ckbGraduated1)
        Me.chbGraduated2.Controls.Add(Me.InsertButton)
        Me.chbGraduated2.Controls.Add(Me.Label42)
        Me.chbGraduated2.Controls.Add(Me.Label39)
        Me.chbGraduated2.Controls.Add(Me.Label38)
        Me.chbGraduated2.Controls.Add(Me.txtCFrom1)
        Me.chbGraduated2.Controls.Add(Me.txtCFrom2)
        Me.chbGraduated2.Controls.Add(Me.txtCTo1)
        Me.chbGraduated2.Controls.Add(Me.txtCTo2)
        Me.chbGraduated2.Controls.Add(Me.txtCurrentHours2)
        Me.chbGraduated2.Controls.Add(Me.txtCurrentHours1)
        Me.chbGraduated2.Controls.Add(Me.txtDegree2)
        Me.chbGraduated2.Controls.Add(Me.txtDegree1)
        Me.chbGraduated2.Controls.Add(Me.txtHoursEarned2)
        Me.chbGraduated2.Controls.Add(Me.txtHoursEarned1)
        Me.chbGraduated2.Controls.Add(Me.txtCGPA2)
        Me.chbGraduated2.Controls.Add(Me.txtCGPA1)
        Me.chbGraduated2.Controls.Add(Me.txtCName2)
        Me.chbGraduated2.Controls.Add(Me.txtCName1)
        Me.chbGraduated2.Controls.Add(Me.Label61)
        Me.chbGraduated2.Controls.Add(Me.Label62)
        Me.chbGraduated2.Controls.Add(Me.Label60)
        Me.chbGraduated2.Controls.Add(Me.Label59)
        Me.chbGraduated2.Controls.Add(Me.Label58)
        Me.chbGraduated2.Controls.Add(Me.Label57)
        Me.chbGraduated2.Controls.Add(Me.Label56)
        Me.chbGraduated2.Controls.Add(Me.Label55)
        Me.chbGraduated2.Controls.Add(Me.Label54)
        Me.chbGraduated2.Controls.Add(Me.Label53)
        Me.chbGraduated2.Controls.Add(Me.Label36)
        Me.chbGraduated2.Controls.Add(Me.Label43)
        Me.chbGraduated2.Controls.Add(Me.GroupBox1)
        Me.chbGraduated2.Controls.Add(Me.Label34)
        Me.chbGraduated2.Controls.Add(Me.txtTSEDate)
        Me.chbGraduated2.Controls.Add(Me.txtTOEFLDate)
        Me.chbGraduated2.Controls.Add(Me.txtGMATTotal)
        Me.chbGraduated2.Controls.Add(Me.txtTSETotal)
        Me.chbGraduated2.Controls.Add(Me.txtTOEFLTotal)
        Me.chbGraduated2.Controls.Add(Me.txtGMATDate)
        Me.chbGraduated2.Controls.Add(Me.Label24)
        Me.chbGraduated2.Controls.Add(Me.Label41)
        Me.chbGraduated2.Controls.Add(Me.Label40)
        Me.chbGraduated2.Controls.Add(Me.Label35)
        Me.chbGraduated2.Controls.Add(Me.Label33)
        Me.chbGraduated2.Controls.Add(Me.Label30)
        Me.chbGraduated2.Controls.Add(Me.Label29)
        Me.chbGraduated2.Controls.Add(Me.Label32)
        Me.chbGraduated2.Controls.Add(Me.Label28)
        Me.chbGraduated2.Controls.Add(Me.Label2)
        Me.chbGraduated2.Controls.Add(Me.cbxReqProgram)
        Me.chbGraduated2.Controls.Add(Me.Label37)
        Me.chbGraduated2.Controls.Add(Me.Label31)
        Me.chbGraduated2.Controls.Add(Me.Label67)
        Me.chbGraduated2.Controls.Add(Me.cbxStanding)
        Me.chbGraduated2.Controls.Add(Me.lblSession)
        Me.chbGraduated2.Controls.Add(Me.cbxSession)
        Me.chbGraduated2.Controls.Add(Me.txtEnrolled_When)
        Me.chbGraduated2.Controls.Add(Me.txtBefore_when)
        Me.chbGraduated2.Controls.Add(Me.txtRequestYear)
        Me.chbGraduated2.Controls.Add(Me.Label27)
        Me.chbGraduated2.Controls.Add(Me.Label26)
        Me.chbGraduated2.Controls.Add(Me.chkEnrolled)
        Me.chbGraduated2.Controls.Add(Me.Label25)
        Me.chbGraduated2.Controls.Add(Me.chkBefore)
        Me.chbGraduated2.Controls.Add(Me.Label23)
        Me.chbGraduated2.Controls.Add(Me.Label22)
        Me.chbGraduated2.Location = New System.Drawing.Point(4, 22)
        Me.chbGraduated2.Name = "chbGraduated2"
        Me.chbGraduated2.Padding = New System.Windows.Forms.Padding(3)
        Me.chbGraduated2.Size = New System.Drawing.Size(864, 542)
        Me.chbGraduated2.TabIndex = 1
        Me.chbGraduated2.Text = "Admission Request"
        Me.chbGraduated2.UseVisualStyleBackColor = True
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(4, 4)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(126, 13)
        Me.Label22.TabIndex = 236
        Me.Label22.Text = "Adminission Request For:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(6, 23)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(32, 13)
        Me.Label23.TabIndex = 237
        Me.Label23.Text = "Year:"
        '
        'txtRequestYear
        '
        Me.txtRequestYear.Location = New System.Drawing.Point(45, 21)
        Me.txtRequestYear.Name = "txtRequestYear"
        Me.txtRequestYear.Size = New System.Drawing.Size(48, 20)
        Me.txtRequestYear.TabIndex = 33
        '
        'chkBefore
        '
        Me.chkBefore.AutoSize = True
        Me.chkBefore.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkBefore.Location = New System.Drawing.Point(178, 19)
        Me.chkBefore.Name = "chkBefore"
        Me.chkBefore.Size = New System.Drawing.Size(163, 17)
        Me.chkBefore.TabIndex = 239
        Me.chkBefore.Text = "Applied to the U of A before?"
        Me.chkBefore.UseVisualStyleBackColor = True
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(349, 21)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(42, 13)
        Me.Label25.TabIndex = 240
        Me.Label25.Text = "When?"
        '
        'txtBefore_when
        '
        Me.txtBefore_when.Location = New System.Drawing.Point(394, 18)
        Me.txtBefore_when.Name = "txtBefore_when"
        Me.txtBefore_when.Size = New System.Drawing.Size(70, 20)
        Me.txtBefore_when.TabIndex = 36
        '
        'chkEnrolled
        '
        Me.chkEnrolled.AutoSize = True
        Me.chkEnrolled.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkEnrolled.Location = New System.Drawing.Point(178, 42)
        Me.chkEnrolled.Name = "chkEnrolled"
        Me.chkEnrolled.Size = New System.Drawing.Size(70, 17)
        Me.chkEnrolled.TabIndex = 241
        Me.chkEnrolled.Text = "Enrolled?"
        Me.chkEnrolled.UseVisualStyleBackColor = True
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(178, 62)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(56, 13)
        Me.Label26.TabIndex = 243
        Me.Label26.Text = "If enrolled:"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(257, 43)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(42, 13)
        Me.Label27.TabIndex = 242
        Me.Label27.Text = "When?"
        '
        'txtEnrolled_When
        '
        Me.txtEnrolled_When.Location = New System.Drawing.Point(302, 40)
        Me.txtEnrolled_When.Name = "txtEnrolled_When"
        Me.txtEnrolled_When.Size = New System.Drawing.Size(70, 20)
        Me.txtEnrolled_When.TabIndex = 38
        '
        'cbxSession
        '
        Me.cbxSession.FormattingEnabled = True
        Me.cbxSession.Items.AddRange(New Object() {"Spring", "Fall"})
        Me.cbxSession.Location = New System.Drawing.Point(9, 59)
        Me.cbxSession.Name = "cbxSession"
        Me.cbxSession.Size = New System.Drawing.Size(133, 21)
        Me.cbxSession.TabIndex = 34
        '
        'lblSession
        '
        Me.lblSession.AutoSize = True
        Me.lblSession.Location = New System.Drawing.Point(6, 43)
        Me.lblSession.Name = "lblSession"
        Me.lblSession.Size = New System.Drawing.Size(47, 13)
        Me.lblSession.TabIndex = 238
        Me.lblSession.Text = "Session:"
        '
        'cbxStanding
        '
        Me.cbxStanding.FormattingEnabled = True
        Me.cbxStanding.Items.AddRange(New Object() {"Graduate", "Undergraduate", "Other"})
        Me.cbxStanding.Location = New System.Drawing.Point(181, 78)
        Me.cbxStanding.Name = "cbxStanding"
        Me.cbxStanding.Size = New System.Drawing.Size(133, 21)
        Me.cbxStanding.TabIndex = 39
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Location = New System.Drawing.Point(6, 128)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(775, 13)
        Me.Label67.TabIndex = 313
        Me.Label67.Text = "_________________________________________________________________________________" &
    "_______________________________________________"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label31.Location = New System.Drawing.Point(300, 65)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(60, 10)
        Me.Label31.TabIndex = 317
        Me.Label31.Text = "YYYY-MM-DD"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label37.Location = New System.Drawing.Point(378, 46)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(60, 10)
        Me.Label37.TabIndex = 318
        Me.Label37.Text = "YYYY-MM-DD"
        '
        'cbxReqProgram
        '
        Me.cbxReqProgram.FormattingEnabled = True
        Me.cbxReqProgram.Items.AddRange(New Object() {"MAcc", "MAEcon", "MBA", "MMBA", "MIS", "PMIS", "ERP", "BI"})
        Me.cbxReqProgram.Location = New System.Drawing.Point(9, 104)
        Me.cbxReqProgram.Name = "cbxReqProgram"
        Me.cbxReqProgram.Size = New System.Drawing.Size(133, 21)
        Me.cbxReqProgram.TabIndex = 323
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 88)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 13)
        Me.Label2.TabIndex = 324
        Me.Label2.Text = "Program:"
        '
        'tabPersonalInfo
        '
        Me.tabPersonalInfo.Controls.Add(Me.chbxHisorLatin)
        Me.tabPersonalInfo.Controls.Add(Me.lblBirthdayFormat)
        Me.tabPersonalInfo.Controls.Add(Me.cbxFState)
        Me.tabPersonalInfo.Controls.Add(Me.cbxLState)
        Me.tabPersonalInfo.Controls.Add(Me.cbxPState)
        Me.tabPersonalInfo.Controls.Add(Me.txtPZipCode)
        Me.tabPersonalInfo.Controls.Add(Me.txtLZipCode)
        Me.tabPersonalInfo.Controls.Add(Me.txtFZipCode)
        Me.tabPersonalInfo.Controls.Add(Me.txtWorkPhone)
        Me.tabPersonalInfo.Controls.Add(Me.txtCurrentPhone)
        Me.tabPersonalInfo.Controls.Add(Me.txtBirthday1)
        Me.tabPersonalInfo.Controls.Add(Me.txtSSN)
        Me.tabPersonalInfo.Controls.Add(Me.cbxOrigin)
        Me.tabPersonalInfo.Controls.Add(Me.txtEmail)
        Me.tabPersonalInfo.Controls.Add(Me.txtStudentID)
        Me.tabPersonalInfo.Controls.Add(Me.txtFYears)
        Me.tabPersonalInfo.Controls.Add(Me.txtLCity)
        Me.tabPersonalInfo.Controls.Add(Me.txtLAddress)
        Me.tabPersonalInfo.Controls.Add(Me.txtFCity)
        Me.tabPersonalInfo.Controls.Add(Me.txtFAddress)
        Me.tabPersonalInfo.Controls.Add(Me.txtPYears)
        Me.tabPersonalInfo.Controls.Add(Me.txtPCity)
        Me.tabPersonalInfo.Controls.Add(Me.txtPAddress)
        Me.tabPersonalInfo.Controls.Add(Me.txtFirstName)
        Me.tabPersonalInfo.Controls.Add(Me.txtMiddleName)
        Me.tabPersonalInfo.Controls.Add(Me.txtLastName)
        Me.tabPersonalInfo.Controls.Add(Me.Label72)
        Me.tabPersonalInfo.Controls.Add(Me.cbxCitizenship)
        Me.tabPersonalInfo.Controls.Add(Me.cbxGender)
        Me.tabPersonalInfo.Controls.Add(Me.Label71)
        Me.tabPersonalInfo.Controls.Add(Me.Label66)
        Me.tabPersonalInfo.Controls.Add(Me.Label3)
        Me.tabPersonalInfo.Controls.Add(Me.Label21)
        Me.tabPersonalInfo.Controls.Add(Me.Label65)
        Me.tabPersonalInfo.Controls.Add(Me.Label50)
        Me.tabPersonalInfo.Controls.Add(Me.Label46)
        Me.tabPersonalInfo.Controls.Add(Me.Label16)
        Me.tabPersonalInfo.Controls.Add(Me.Label17)
        Me.tabPersonalInfo.Controls.Add(Me.Label18)
        Me.tabPersonalInfo.Controls.Add(Me.Label19)
        Me.tabPersonalInfo.Controls.Add(Me.Label20)
        Me.tabPersonalInfo.Controls.Add(Me.chkResident)
        Me.tabPersonalInfo.Controls.Add(Me.Label12)
        Me.tabPersonalInfo.Controls.Add(Me.Label13)
        Me.tabPersonalInfo.Controls.Add(Me.Label14)
        Me.tabPersonalInfo.Controls.Add(Me.Label15)
        Me.tabPersonalInfo.Controls.Add(Me.Label11)
        Me.tabPersonalInfo.Controls.Add(Me.Label10)
        Me.tabPersonalInfo.Controls.Add(Me.Label9)
        Me.tabPersonalInfo.Controls.Add(Me.Label8)
        Me.tabPersonalInfo.Controls.Add(Me.Label7)
        Me.tabPersonalInfo.Controls.Add(Me.Label6)
        Me.tabPersonalInfo.Controls.Add(Me.Label5)
        Me.tabPersonalInfo.Controls.Add(Me.Label49)
        Me.tabPersonalInfo.Controls.Add(Me.Label48)
        Me.tabPersonalInfo.Controls.Add(Me.cbxEthnic)
        Me.tabPersonalInfo.Controls.Add(Me.Label1)
        Me.tabPersonalInfo.Controls.Add(Me.Label4)
        Me.tabPersonalInfo.Controls.Add(Me.lblDOB)
        Me.tabPersonalInfo.Controls.Add(Me.lblSSN)
        Me.tabPersonalInfo.Controls.Add(Me.lblName)
        Me.tabPersonalInfo.Controls.Add(Me.lblMiddleName)
        Me.tabPersonalInfo.Controls.Add(Me.lblFirstName)
        Me.tabPersonalInfo.Controls.Add(Me.lblLastName)
        Me.tabPersonalInfo.Location = New System.Drawing.Point(4, 22)
        Me.tabPersonalInfo.Name = "tabPersonalInfo"
        Me.tabPersonalInfo.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPersonalInfo.Size = New System.Drawing.Size(864, 542)
        Me.tabPersonalInfo.TabIndex = 0
        Me.tabPersonalInfo.Text = "Personal Information"
        Me.tabPersonalInfo.UseVisualStyleBackColor = True
        '
        'lblLastName
        '
        Me.lblLastName.AutoSize = True
        Me.lblLastName.Location = New System.Drawing.Point(7, 26)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(31, 13)
        Me.lblLastName.TabIndex = 201
        Me.lblLastName.Text = "Last*"
        '
        'lblFirstName
        '
        Me.lblFirstName.AutoSize = True
        Me.lblFirstName.Location = New System.Drawing.Point(6, 53)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(26, 13)
        Me.lblFirstName.TabIndex = 202
        Me.lblFirstName.Text = "First"
        '
        'lblMiddleName
        '
        Me.lblMiddleName.AutoSize = True
        Me.lblMiddleName.Location = New System.Drawing.Point(6, 79)
        Me.lblMiddleName.Name = "lblMiddleName"
        Me.lblMiddleName.Size = New System.Drawing.Size(38, 13)
        Me.lblMiddleName.TabIndex = 203
        Me.lblMiddleName.Text = "Middle"
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(62, 25)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(145, 20)
        Me.txtLastName.TabIndex = 1
        '
        'txtMiddleName
        '
        Me.txtMiddleName.Location = New System.Drawing.Point(62, 77)
        Me.txtMiddleName.Name = "txtMiddleName"
        Me.txtMiddleName.Size = New System.Drawing.Size(100, 20)
        Me.txtMiddleName.TabIndex = 3
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(62, 51)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(145, 20)
        Me.txtFirstName.TabIndex = 2
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(6, 7)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(38, 13)
        Me.lblName.TabIndex = 200
        Me.lblName.Text = "Name:"
        '
        'lblSSN
        '
        Me.lblSSN.AutoSize = True
        Me.lblSSN.Location = New System.Drawing.Point(9, 113)
        Me.lblSSN.Name = "lblSSN"
        Me.lblSSN.Size = New System.Drawing.Size(33, 13)
        Me.lblSSN.TabIndex = 206
        Me.lblSSN.Text = "SSN*"
        '
        'lblDOB
        '
        Me.lblDOB.AutoSize = True
        Me.lblDOB.Location = New System.Drawing.Point(219, 60)
        Me.lblDOB.Name = "lblDOB"
        Me.lblDOB.Size = New System.Drawing.Size(30, 13)
        Me.lblDOB.TabIndex = 207
        Me.lblDOB.Text = "DOB"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(362, 7)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(70, 13)
        Me.Label4.TabIndex = 208
        Me.Label4.Text = "Place of Birth"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(362, 49)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(84, 13)
        Me.Label1.TabIndex = 209
        Me.Label1.Text = "Race / Ethnicity"
        '
        'cbxEthnic
        '
        Me.cbxEthnic.FormattingEnabled = True
        Me.cbxEthnic.Items.AddRange(New Object() {"Alaskan Native or American Indian", "Black, Non-Hispanic", "Asian or Pacific Islander", "White, Non-Hispanic", "Hispanic"})
        Me.cbxEthnic.Location = New System.Drawing.Point(365, 65)
        Me.cbxEthnic.Name = "cbxEthnic"
        Me.cbxEthnic.Size = New System.Drawing.Size(121, 21)
        Me.cbxEthnic.TabIndex = 9
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(362, 89)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(45, 13)
        Me.Label48.TabIndex = 210
        Me.Label48.Text = "Gender:"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(163, 113)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(60, 13)
        Me.Label49.TabIndex = 211
        Me.Label49.Text = "Citizenship:"
        '
        'txtPAddress
        '
        Me.txtPAddress.Location = New System.Drawing.Point(48, 164)
        Me.txtPAddress.Name = "txtPAddress"
        Me.txtPAddress.Size = New System.Drawing.Size(273, 20)
        Me.txtPAddress.TabIndex = 12
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 149)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(102, 13)
        Me.Label5.TabIndex = 212
        Me.Label5.Text = "Permanent Address:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(7, 166)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(35, 13)
        Me.Label6.TabIndex = 213
        Me.Label6.Text = "Street"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(8, 191)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(24, 13)
        Me.Label7.TabIndex = 214
        Me.Label7.Text = "City"
        '
        'txtPCity
        '
        Me.txtPCity.Location = New System.Drawing.Point(48, 190)
        Me.txtPCity.Name = "txtPCity"
        Me.txtPCity.Size = New System.Drawing.Size(273, 20)
        Me.txtPCity.TabIndex = 13
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(8, 219)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(32, 13)
        Me.Label8.TabIndex = 215
        Me.Label8.Text = "State"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(10, 246)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(22, 13)
        Me.Label9.TabIndex = 216
        Me.Label9.Text = "Zip"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(10, 275)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(137, 13)
        Me.Label10.TabIndex = 217
        Me.Label10.Text = "Years at the above address"
        '
        'txtPYears
        '
        Me.txtPYears.Location = New System.Drawing.Point(153, 272)
        Me.txtPYears.Name = "txtPYears"
        Me.txtPYears.Size = New System.Drawing.Size(22, 20)
        Me.txtPYears.TabIndex = 16
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(10, 301)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(83, 13)
        Me.Label11.TabIndex = 223
        Me.Label11.Text = "Former Address:"
        '
        'txtFAddress
        '
        Me.txtFAddress.Location = New System.Drawing.Point(51, 317)
        Me.txtFAddress.Name = "txtFAddress"
        Me.txtFAddress.Size = New System.Drawing.Size(273, 20)
        Me.txtFAddress.TabIndex = 21
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(10, 319)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(35, 13)
        Me.Label15.TabIndex = 224
        Me.Label15.Text = "Street"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(11, 344)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(24, 13)
        Me.Label14.TabIndex = 225
        Me.Label14.Text = "City"
        '
        'txtFCity
        '
        Me.txtFCity.Location = New System.Drawing.Point(51, 343)
        Me.txtFCity.Name = "txtFCity"
        Me.txtFCity.Size = New System.Drawing.Size(273, 20)
        Me.txtFCity.TabIndex = 22
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(11, 372)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(32, 13)
        Me.Label13.TabIndex = 226
        Me.Label13.Text = "State"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(13, 399)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(22, 13)
        Me.Label12.TabIndex = 227
        Me.Label12.Text = "Zip"
        '
        'chkResident
        '
        Me.chkResident.AutoSize = True
        Me.chkResident.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkResident.Location = New System.Drawing.Point(208, 424)
        Me.chkResident.Name = "chkResident"
        Me.chkResident.Size = New System.Drawing.Size(115, 17)
        Me.chkResident.TabIndex = 26
        Me.chkResident.Text = "Arkansas Resident"
        Me.chkResident.UseVisualStyleBackColor = True
        '
        'txtLAddress
        '
        Me.txtLAddress.Location = New System.Drawing.Point(369, 164)
        Me.txtLAddress.Name = "txtLAddress"
        Me.txtLAddress.Size = New System.Drawing.Size(273, 20)
        Me.txtLAddress.TabIndex = 17
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(328, 149)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(84, 13)
        Me.Label20.TabIndex = 218
        Me.Label20.Text = "Mailing Address:"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(328, 166)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(35, 13)
        Me.Label19.TabIndex = 219
        Me.Label19.Text = "Street"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(329, 191)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(24, 13)
        Me.Label18.TabIndex = 220
        Me.Label18.Text = "City"
        '
        'txtLCity
        '
        Me.txtLCity.Location = New System.Drawing.Point(369, 190)
        Me.txtLCity.Name = "txtLCity"
        Me.txtLCity.Size = New System.Drawing.Size(273, 20)
        Me.txtLCity.TabIndex = 18
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(329, 219)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(32, 13)
        Me.Label17.TabIndex = 221
        Me.Label17.Text = "State"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(331, 246)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(22, 13)
        Me.Label16.TabIndex = 222
        Me.Label16.Text = "Zip"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(388, 301)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(102, 13)
        Me.Label46.TabIndex = 230
        Me.Label46.Text = "Contact Information:"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(13, 424)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(137, 13)
        Me.Label50.TabIndex = 228
        Me.Label50.Text = "Years at the above address"
        '
        'txtFYears
        '
        Me.txtFYears.Location = New System.Drawing.Point(156, 421)
        Me.txtFYears.Name = "txtFYears"
        Me.txtFYears.Size = New System.Drawing.Size(22, 20)
        Me.txtFYears.TabIndex = 25
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(5, 129)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(769, 13)
        Me.Label65.TabIndex = 314
        Me.Label65.Text = "_________________________________________________________________________________" &
    "______________________________________________"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(393, 321)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(92, 13)
        Me.Label21.TabIndex = 231
        Me.Label21.Text = "Home Telephone:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(393, 347)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(61, 13)
        Me.Label3.TabIndex = 232
        Me.Label3.Text = "Cell Phone:"
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Location = New System.Drawing.Point(331, 275)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(439, 13)
        Me.Label66.TabIndex = 315
        Me.Label66.Text = "________________________________________________________________________"
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Location = New System.Drawing.Point(219, 7)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(62, 13)
        Me.Label71.TabIndex = 205
        Me.Label71.Text = "Student ID*"
        '
        'txtStudentID
        '
        Me.txtStudentID.Location = New System.Drawing.Point(222, 25)
        Me.txtStudentID.Name = "txtStudentID"
        Me.txtStudentID.Size = New System.Drawing.Size(128, 20)
        Me.txtStudentID.TabIndex = 5
        '
        'cbxGender
        '
        Me.cbxGender.FormattingEnabled = True
        Me.cbxGender.Items.AddRange(New Object() {"Male", "Female"})
        Me.cbxGender.Location = New System.Drawing.Point(365, 105)
        Me.cbxGender.Name = "cbxGender"
        Me.cbxGender.Size = New System.Drawing.Size(121, 21)
        Me.cbxGender.TabIndex = 10
        '
        'cbxCitizenship
        '
        Me.cbxCitizenship.FormattingEnabled = True
        Me.cbxCitizenship.Items.AddRange(New Object() {"U.S. Citizen", "Resident Alien", "Non-Resident Alien"})
        Me.cbxCitizenship.Location = New System.Drawing.Point(229, 105)
        Me.cbxCitizenship.Name = "cbxCitizenship"
        Me.cbxCitizenship.Size = New System.Drawing.Size(121, 21)
        Me.cbxCitizenship.TabIndex = 11
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.Location = New System.Drawing.Point(393, 377)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(80, 13)
        Me.Label72.TabIndex = 235
        Me.Label72.Text = "Email Address*:"
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(510, 374)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(132, 20)
        Me.txtEmail.TabIndex = 31
        '
        'cbxOrigin
        '
        Me.cbxOrigin.FormattingEnabled = True
        Me.cbxOrigin.Items.AddRange(New Object() {"Abkhazia – Republic of Abkhazia[5]", "Afghanistan Afghanistan – Islamic Republic of Afghanistan", "the United Kingdom Akrotiri and Dhekelia – Sovereign Base Areas of Akrotiri and D" &
                "hekelia (UK overseas territory)", "Åland Islands Åland – Åland Islands (Autonomous province of Finland)", "Albania Albania – Republic of Albania", "Algeria Algeria – People's Democratic Republic of Algeria", "American Samoa American Samoa – Territory of American Samoa (US territory)", "Andorra Andorra – Principality of Andorra", "Angola Angola – Republic of Angola", "Anguilla Anguilla (UK overseas territory)", "Antigua and Barbuda Antigua and Barbuda", "Argentina Argentina – Argentine Republic[11]", "Armenia Armenia – Republic of Armenia", "Aruba Aruba (Self-governing country in the Kingdom of the Netherlands)", "the United Kingdom Ascension Island (Dependency of the UK overseas territory of S" &
                "aint Helena)", "Australia Australia – Commonwealth of Australia", "Austria Austria – Republic of Austria", "Azerbaijan Azerbaijan – Republic of Azerbaijan[12]", "the Bahamas Bahamas, The – Commonwealth of The Bahamas", "Bahrain Bahrain – Kingdom of Bahrain", "Bangladesh Bangladesh – People's Republic of Bangladesh", "Barbados Barbados", "Belarus Belarus – Republic of Belarus", "Belgium Belgium – Kingdom of Belgium", "Belize Belize", "Benin Benin – Republic of Benin", "Bermuda Bermuda (UK overseas territory)", "Bhutan Bhutan – Kingdom of Bhutan", "Bolivia Bolivia – Republic of Bolivia", "Bosnia and Herzegovina Bosnia and Herzegovina[13]", "Botswana Botswana – Republic of Botswana", "Brazil Brazil – Federative Republic of Brazil", "Brunei Brunei – Negara Brunei Darussalam", "Bulgaria Bulgaria – Republic of Bulgaria", "Burkina Faso Burkina Faso", """Burma"", see Myanmar", "Burundi Burundi – Republic of Burundi", "Cambodia Cambodia – Kingdom of Cambodia", "Cameroon Cameroon – Republic of Cameroon", "Canada Canada[14]", "Cape Verde Cape Verde – Republic of Cape Verde", "Cayman Islands Cayman Islands (UK overseas territory)", "the Central African Republic Central African Republic[15]", "Chad Chad – Republic of Chad", "Chile Chile – Republic of Chile", "the People's Republic of China China, People's Republic of – People's Republic of" &
                " China[16]", "the Republic of China China, Republic of – Republic of China [17]", "Christmas Island Christmas Island – Territory of Christmas Island (Australian ove" &
                "rseas territory)", "the Cocos (Keeling) Islands Cocos (Keeling) Islands – Territory of Cocos (Keeling" &
                ") Islands (Australian overseas territory)", "Colombia Colombia – Republic of Colombia", "the Comoros Comoros – Union of the Comoros", "the Democratic Republic of the Congo Congo – Democratic Republic of the Congo[18]" &
                "", "the Republic of the Congo Congo – Republic of the Congo[19]", "the Cook Islands Cook Islands (Associated state of New Zealand)", "Costa Rica Costa Rica – Republic of Costa Rica", "Côte d'Ivoire Côte d'Ivoire – Republic of Côte d'Ivoire", "Croatia Croatia – Republic of Croatia", "Cuba Cuba – Republic of Cuba", "Cyprus Cyprus – Republic of Cyprus[20]", "the Czech Republic Czech Republic[21]", "Denmark Denmark – Kingdom of Denmark", """Dhekelia"", see Akrotiri and Dhekelia", "Djibouti Djibouti – Republic of Djibouti", "Dominica Dominica – Commonwealth of Dominica", "the Dominican Republic Dominican Republic", "East Timor East Timor – Democratic Republic of Timor-Leste", "Ecuador Ecuador – Republic of Ecuador", "Egypt Egypt – Arab Republic of Egypt", "El Salvador El Salvador – Republic of El Salvador", "Equatorial Guinea Equatorial Guinea – Republic of Equatorial Guinea", "Eritrea Eritrea – State of Eritrea", "Estonia Estonia – Republic of Estonia", "Ethiopia Ethiopia – Federal Democratic Republic of Ethiopia", "the Falkland Islands Falkland Islands (UK overseas territory)[22]", "the Faroe Islands Faroe Islands (Self-governing country in the Kingdom of Denmark" &
                ")", "Fiji Fiji – Republic of the Fiji Islands", "Finland Finland – Republic of Finland", "France France – French Republic", "French Polynesia French Polynesia (French overseas collectivity)", "Gabon Gabon – Gabonese Republic", "The Gambia Gambia, The – Republic of The Gambia", "Georgia (country) Georgia[23]", "Germany Germany – Federal Republic of Germany", "Ghana Ghana – Republic of Ghana", "Gibraltar Gibraltar (UK overseas territory)", "Greece Greece – Hellenic Republic", "Greenland Greenland (Self-governing country in the Kingdom of Denmark)", "Grenada Grenada", "Guam Guam – Territory of Guam (US organized territory)", "Guatemala Guatemala – Republic of Guatemala", "Guernsey Guernsey – Bailiwick of Guernsey (British Crown dependency)[24]", "Guinea Guinea – Republic of Guinea", "Guinea-Bissau Guinea-Bissau – Republic of Guinea-Bissau", "Guyana Guyana – Co-operative Republic of Guyana", "Haiti Haiti – Republic of Haiti", "Honduras Honduras – Republic of Honduras", "Hong Kong Hong Kong – Hong Kong Special Administrative Region of the People's Rep" &
                "ublic of China (Area of special sovereignty)[25]", "Hungary Hungary – Republic of Hungary", "Iceland Iceland – Republic of Iceland", "India India – Republic of India", "Indonesia Indonesia – Republic of Indonesia", "Iran Iran – Islamic Republic of Iran", "Iraq Iraq – Republic of Iraq", "Ireland Ireland - Republic of Ireland[26]", "the Isle of Man Isle of Man (British Crown dependency)", "Israel Israel – State of Israel", "Italy Italy – Italian Republic", """Ivory Coast"", see Côte d'Ivoire", "Jamaica Jamaica", "Japan Japan", "Jersey Jersey – Bailiwick of Jersey (British Crown dependency)", "Jordan Jordan – Hashemite Kingdom of Jordan", "Kazakhstan Kazakhstan – Republic of Kazakhstan", "Kenya Kenya – Republic of Kenya", "Kiribati Kiribati – Republic of Kiribati", "North Korea Korea, North – Democratic People's Republic of Korea[27]", "South Korea Korea, South – Republic of Korea[28]", "Kosovo Kosovo – Republic of Kosovo[3]", "Kuwait Kuwait – State of Kuwait", "Kyrgyzstan Kyrgyzstan – Kyrgyz Republic[29]", "Laos Laos – Lao People's Democratic Republic", "Latvia Latvia – Republic of Latvia", "Lebanon Lebanon – Republic of Lebanon", "Lesotho Lesotho – Kingdom of Lesotho", "Liberia Liberia – Republic of Liberia", "Libya Libya – Great Socialist People's Libyan Arab Jamahiriya", "Liechtenstein Liechtenstein – Principality of Liechtenstein", "Lithuania Lithuania – Republic of Lithuania", "Luxembourg Luxembourg – Grand Duchy of Luxembourg", "Macau Macao – Macao Special Administrative Region of the People's Republic of Chi" &
                "na (Area of special sovereignty)[30]", "the Republic of Macedonia Macedonia – Republic of Macedonia[31]", "Madagascar Madagascar – Republic of Madagascar", "Malawi Malawi – Republic of Malawi", "Malaysia Malaysia", "the Maldives Maldives – Republic of Maldives", "Mali Mali – Republic of Mali", "Malta Malta – Republic of Malta", "the Marshall Islands Marshall Islands – Republic of the Marshall Islands", "Mauritania Mauritania – Islamic Republic of Mauritania", "Mauritius Mauritius – Republic of Mauritius", "Mayotte Mayotte – Departmental Collectivity of Mayotte (French overseas collectiv" &
                "ity)", "Mexico Mexico – United Mexican States", "the Federated States of Micronesia Micronesia – Federated States of Micronesia", "Moldova Moldova – Republic of Moldova[32]", "Monaco Monaco – Principality of Monaco", "Mongolia Mongolia", "Montenegro Montenegro – Republic of Montenegro", "Montserrat Montserrat (UK overseas territory)", "Morocco Morocco – Kingdom of Morocco[33]", "Mozambique Mozambique – Republic of Mozambique", "Burma Myanmar – Union of Myanmar", "Nagorno-Karabakh Republic Nagorno-Karabakh – Nagorno-Karabakh Republic[6]", "Namibia Namibia – Republic of Namibia", "Nauru Nauru – Republic of Nauru", "Nepal Nepal – State of Nepal", "the Netherlands Netherlands – Kingdom of the Netherlands[34]", "the Netherlands Antilles Netherlands Antilles (Self-governing country in the King" &
                "dom of the Netherlands)", "New Caledonia New Caledonia – Territory of New Caledonia and Dependencies (French" &
                " community sui generis)", "New Zealand New Zealand", "Nicaragua Nicaragua – Republic of Nicaragua", "Niger Niger – Republic of Niger", "Nigeria Nigeria – Federal Republic of Nigeria", "Niue Niue (Associated state of New Zealand)", "Norfolk Island Norfolk Island – Territory of Norfolk Island (Australian overseas " &
                "territory)", "the Turkish Republic of Northern Cyprus Northern Cyprus – Turkish Republic of Nor" &
                "thern Cyprus[4]", "the Northern Mariana Islands Northern Mariana Islands – Commonwealth of the North" &
                "ern Mariana Islands (US commonwealth)", """North Korea"", see Korea, North", "Norway Norway – Kingdom of Norway", "Oman Oman – Sultanate of Oman", "Pakistan Pakistan – Islamic Republic of Pakistan", "Palau Palau – Republic of Palau", "Palestinian flag Palestine – Occupied Palestinian Territories[35]", "Panama Panama – Republic of Panama", "Papua New Guinea Papua New Guinea – Independent State of Papua New Guinea", "Paraguay Paraguay – Republic of Paraguay", """People's Republic of China"", see China, People's Republic of", "Peru Peru – Republic of Peru", "the Philippines Philippines – Republic of the Philippines", "the Pitcairn Islands Pitcairn Islands – Pitcairn, Henderson, Ducie, and Oeno Isla" &
                "nds (UK overseas territory)", "Poland Poland – Republic of Poland", "Portugal Portugal – Portuguese Republic", """Pridnestrovie"", see Transnistria", "Puerto Rico Puerto Rico – Commonwealth of Puerto Rico (US commonwealth)", "Qatar Qatar – State of Qatar", """Republic of China"", see China, Republic of", "Romania Romania", "Russia Russia – Russian Federation", "Rwanda Rwanda – Republic of Rwanda", "Saint Barthélemy Saint Barthélemy – Collectivity of Saint Barthélemy (French over" &
                "seas collectivity)", "Saint Helena Saint Helena (UK overseas territory)", "Saint Kitts and Nevis Saint Kitts and Nevis – Federation of Saint Christopher and" &
                " Nevis", "Saint Lucia Saint Lucia", "Saint Martin (France) Saint Martin – Collectivity of Saint Martin (French oversea" &
                "s collectivity)", "Saint Pierre and Miquelon Saint Pierre and Miquelon – Territorial Collectivity of" &
                " Saint Pierre and Miquelon (French overseas collectivity)", "Saint Vincent and the Grenadines Saint Vincent and the Grenadines", "Samoa Samoa – Independent State of Samoa", "San Marino San Marino – Most Serene Republic of San Marino", "São Tomé and Príncipe São Tomé and Príncipe – Democratic Republic of São Tomé and" &
                " Príncipe", "Saudi Arabia Saudi Arabia – Kingdom of Saudi Arabia", "Senegal Senegal – Republic of Senegal", "Serbia Serbia – Republic of Serbia[36]", "the Seychelles Seychelles – Republic of Seychelles", "Sierra Leone Sierra Leone – Republic of Sierra Leone", "Singapore Singapore – Republic of Singapore", "Slovakia Slovakia – Slovak Republic", "Slovenia Slovenia – Republic of Slovenia", "the Solomon Islands Solomon Islands", "Somalia Somalia[37]", "Somaliland Somaliland – Republic of Somaliland[8]", "South Africa South Africa – Republic of South Africa", """South Korea"", see Korea, South", "South Ossetia South Ossetia – Republic of South Ossetia[9]", "Spain Spain – Kingdom of Spain", "Sri Lanka Sri Lanka – Democratic Socialist Republic of Sri Lanka", "Sudan Sudan – Republic of the Sudan", "Suriname Suriname – Republic of Suriname", "Svalbard Svalbard (Territory of Norway)[38]", "Swaziland Swaziland – Kingdom of Swaziland", "Sweden Sweden – Kingdom of Sweden", "Switzerland Switzerland – Swiss Confederation", "Syria Syria – Syrian Arab Republic", """Taiwan"", see China, Republic of", "Tajikistan Tajikistan – Republic of Tajikistan", "Tanzania Tanzania – United Republic of Tanzania", "Thailand Thailand – Kingdom of Thailand", """Timor-Leste"", see East Timor", "Togo Togo – Togolese Republic", "Tokelau Tokelau (Overseas territory of New Zealand)", "Tonga Tonga – Kingdom of Tonga", "Transnistria Transnistria – Transnistrian Moldovan Republic[7]", "Trinidad and Tobago Trinidad and Tobago – Republic of Trinidad and Tobago", "Tristan da Cunha Tristan da Cunha (Dependency of the UK overseas territory of Sai" &
                "nt Helena)", "Tunisia Tunisia – Tunisian Republic", "Turkey Turkey – Republic of Turkey", "Turkmenistan Turkmenistan", "the Turks and Caicos Islands Turks and Caicos Islands (UK overseas territory)", "Tuvalu Tuvalu", "Uganda Uganda – Republic of Uganda", "Ukraine Ukraine", "the United Arab Emirates United Arab Emirates", "the United Kingdom United Kingdom – United Kingdom of Great Britain and Northern " &
                "Ireland", "the United States United States – United States of America", "Uruguay Uruguay – Eastern Republic of Uruguay", "Uzbekistan Uzbekistan – Republic of Uzbekistan", "Vanuatu Vanuatu – Republic of Vanuatu", "the Vatican City Vatican City – State of the Vatican City[39]", "Venezuela Venezuela – Bolivarian Republic of Venezuela", "Vietnam Vietnam – Socialist Republic of Vietnam", "the British Virgin Islands Virgin Islands, British – British Virgin Islands (UK o" &
                "verseas territory)", "the United States Virgin Islands Virgin Islands, United States – United States Vi" &
                "rgin Islands (US organized territory)", "Wallis and Futuna Wallis and Futuna – Territory of Wallis and Futuna Islands (Fre" &
                "nch overseas collectivity)", "Western Sahara Western Sahara[40]", "Yemen Yemen – Republic of Yemen", """Zaire"", see Democratic Republic of the Congo", "Zambia Zambia – Republic of Zambia", "Zimbabwe Zimbabwe – Republic of Zimbabwe"})
        Me.cbxOrigin.Location = New System.Drawing.Point(365, 24)
        Me.cbxOrigin.Name = "cbxOrigin"
        Me.cbxOrigin.Size = New System.Drawing.Size(121, 21)
        Me.cbxOrigin.TabIndex = 8
        '
        'txtSSN
        '
        Me.txtSSN.Location = New System.Drawing.Point(62, 106)
        Me.txtSSN.Name = "txtSSN"
        Me.txtSSN.Size = New System.Drawing.Size(71, 20)
        Me.txtSSN.TabIndex = 6
        '
        'txtBirthday1
        '
        Me.txtBirthday1.Location = New System.Drawing.Point(279, 53)
        Me.txtBirthday1.Name = "txtBirthday1"
        Me.txtBirthday1.Size = New System.Drawing.Size(71, 20)
        Me.txtBirthday1.TabIndex = 7
        '
        'txtCurrentPhone
        '
        Me.txtCurrentPhone.Location = New System.Drawing.Point(512, 321)
        Me.txtCurrentPhone.Mask = "(999) 000-0000"
        Me.txtCurrentPhone.Name = "txtCurrentPhone"
        Me.txtCurrentPhone.Size = New System.Drawing.Size(100, 20)
        Me.txtCurrentPhone.TabIndex = 27
        '
        'txtWorkPhone
        '
        Me.txtWorkPhone.Location = New System.Drawing.Point(512, 347)
        Me.txtWorkPhone.Mask = "(999) 000-0000"
        Me.txtWorkPhone.Name = "txtWorkPhone"
        Me.txtWorkPhone.Size = New System.Drawing.Size(100, 20)
        Me.txtWorkPhone.TabIndex = 28
        '
        'txtFZipCode
        '
        Me.txtFZipCode.Location = New System.Drawing.Point(51, 396)
        Me.txtFZipCode.Mask = "00000-0000"
        Me.txtFZipCode.Name = "txtFZipCode"
        Me.txtFZipCode.Size = New System.Drawing.Size(75, 20)
        Me.txtFZipCode.TabIndex = 24
        Me.txtFZipCode.ValidatingType = GetType(Integer)
        '
        'txtLZipCode
        '
        Me.txtLZipCode.Location = New System.Drawing.Point(370, 243)
        Me.txtLZipCode.Mask = "00000-0000"
        Me.txtLZipCode.Name = "txtLZipCode"
        Me.txtLZipCode.Size = New System.Drawing.Size(75, 20)
        Me.txtLZipCode.TabIndex = 20
        Me.txtLZipCode.ValidatingType = GetType(Integer)
        '
        'txtPZipCode
        '
        Me.txtPZipCode.Location = New System.Drawing.Point(47, 243)
        Me.txtPZipCode.Mask = "00000-0000"
        Me.txtPZipCode.Name = "txtPZipCode"
        Me.txtPZipCode.Size = New System.Drawing.Size(75, 20)
        Me.txtPZipCode.TabIndex = 15
        Me.txtPZipCode.ValidatingType = GetType(Integer)
        '
        'cbxPState
        '
        Me.cbxPState.FormattingEnabled = True
        Me.cbxPState.Items.AddRange(New Object() {"ALABAMA", "ALASKA", "AMERICAN SAMOA", "ARIZONA", "ARKANSAS", "CALIFORNIA", "COLORADO", "CONNECTICUT", "DELAWARE", "DISTRICT OF COLUMBIA", "FEDERATED STATES OF MICRONESIA", "FLORIDA", "GEORGIA", "GUAM", "HAWAII", "IDAHO", "ILLINOIS", "INDIANA", "IOWA", "KANSAS", "KENTUCKY", "LOUISIANA", "MAINE", "MARSHALL ISLANDS", "MARYLAND", "MASSACHUSETTS", "MICHIGAN", "MINNESOTA", "MISSISSIPPI", "MISSOURI", "MONTANA", "NEBRASKA", "NEVADA", "NEW HAMPSHIRE", "NEW JERSEY", "NEW MEXICO", "NEW YORK", "NORTH CAROLINA", "NORTH DAKOTA", "NORTHERN MARIANA ISLANDS", "OHIO", "OKLAHOMA", "OREGON", "PALAU", "PENNSYLVANIA", "PUERTO RICO", "RHODE ISLAND", "SOUTH CAROLINA", "SOUTH DAKOTA", "TENNESSEE", "TEXAS", "UTAH", "VERMONT", "VIRGIN ISLANDS", "VIRGINIA", "WASHINGTON", "WEST VIRGINIA", "WISCONSIN", "WYOMING"})
        Me.cbxPState.Location = New System.Drawing.Point(48, 216)
        Me.cbxPState.Name = "cbxPState"
        Me.cbxPState.Size = New System.Drawing.Size(121, 21)
        Me.cbxPState.TabIndex = 14
        '
        'cbxLState
        '
        Me.cbxLState.FormattingEnabled = True
        Me.cbxLState.Items.AddRange(New Object() {"ALABAMA", "ALASKA", "AMERICAN SAMOA", "ARIZONA", "ARKANSAS", "CALIFORNIA", "COLORADO", "CONNECTICUT", "DELAWARE", "DISTRICT OF COLUMBIA", "FEDERATED STATES OF MICRONESIA", "FLORIDA", "GEORGIA", "GUAM", "HAWAII", "IDAHO", "ILLINOIS", "INDIANA", "IOWA", "KANSAS", "KENTUCKY", "LOUISIANA", "MAINE", "MARSHALL ISLANDS", "MARYLAND", "MASSACHUSETTS", "MICHIGAN", "MINNESOTA", "MISSISSIPPI", "MISSOURI", "MONTANA", "NEBRASKA", "NEVADA", "NEW HAMPSHIRE", "NEW JERSEY", "NEW MEXICO", "NEW YORK", "NORTH CAROLINA", "NORTH DAKOTA", "NORTHERN MARIANA ISLANDS", "OHIO", "OKLAHOMA", "OREGON", "PALAU", "PENNSYLVANIA", "PUERTO RICO", "RHODE ISLAND", "SOUTH CAROLINA", "SOUTH DAKOTA", "TENNESSEE", "TEXAS", "UTAH", "VERMONT", "VIRGIN ISLANDS", "VIRGINIA", "WASHINGTON", "WEST VIRGINIA", "WISCONSIN", "WYOMING"})
        Me.cbxLState.Location = New System.Drawing.Point(369, 216)
        Me.cbxLState.Name = "cbxLState"
        Me.cbxLState.Size = New System.Drawing.Size(121, 21)
        Me.cbxLState.TabIndex = 19
        '
        'cbxFState
        '
        Me.cbxFState.FormattingEnabled = True
        Me.cbxFState.Items.AddRange(New Object() {"ALABAMA", "ALASKA", "AMERICAN SAMOA", "ARIZONA", "ARKANSAS", "CALIFORNIA", "COLORADO", "CONNECTICUT", "DELAWARE", "DISTRICT OF COLUMBIA", "FEDERATED STATES OF MICRONESIA", "FLORIDA", "GEORGIA", "GUAM", "HAWAII", "IDAHO", "ILLINOIS", "INDIANA", "IOWA", "KANSAS", "KENTUCKY", "LOUISIANA", "MAINE", "MARSHALL ISLANDS", "MARYLAND", "MASSACHUSETTS", "MICHIGAN", "MINNESOTA", "MISSISSIPPI", "MISSOURI", "MONTANA", "NEBRASKA", "NEVADA", "NEW HAMPSHIRE", "NEW JERSEY", "NEW MEXICO", "NEW YORK", "NORTH CAROLINA", "NORTH DAKOTA", "NORTHERN MARIANA ISLANDS", "OHIO", "OKLAHOMA", "OREGON", "PALAU", "PENNSYLVANIA", "PUERTO RICO", "RHODE ISLAND", "SOUTH CAROLINA", "SOUTH DAKOTA", "TENNESSEE", "TEXAS", "UTAH", "VERMONT", "VIRGIN ISLANDS", "VIRGINIA", "WASHINGTON", "WEST VIRGINIA", "WISCONSIN", "WYOMING"})
        Me.cbxFState.Location = New System.Drawing.Point(51, 369)
        Me.cbxFState.Name = "cbxFState"
        Me.cbxFState.Size = New System.Drawing.Size(121, 21)
        Me.cbxFState.TabIndex = 23
        '
        'lblBirthdayFormat
        '
        Me.lblBirthdayFormat.AutoSize = True
        Me.lblBirthdayFormat.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBirthdayFormat.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblBirthdayFormat.Location = New System.Drawing.Point(290, 84)
        Me.lblBirthdayFormat.Name = "lblBirthdayFormat"
        Me.lblBirthdayFormat.Size = New System.Drawing.Size(60, 10)
        Me.lblBirthdayFormat.TabIndex = 316
        Me.lblBirthdayFormat.Text = "YYYY-MM-DD"
        '
        'chbxHisorLatin
        '
        Me.chbxHisorLatin.AutoSize = True
        Me.chbxHisorLatin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chbxHisorLatin.Location = New System.Drawing.Point(512, 28)
        Me.chbxHisorLatin.Name = "chbxHisorLatin"
        Me.chbxHisorLatin.Size = New System.Drawing.Size(105, 17)
        Me.chbxHisorLatin.TabIndex = 320
        Me.chbxHisorLatin.Text = "Hispanic or Latin"
        Me.chbxHisorLatin.UseVisualStyleBackColor = True
        '
        'tabApplication
        '
        Me.tabApplication.Controls.Add(Me.tabPersonalInfo)
        Me.tabApplication.Controls.Add(Me.chbGraduated2)
        Me.tabApplication.Location = New System.Drawing.Point(24, 36)
        Me.tabApplication.Name = "tabApplication"
        Me.tabApplication.SelectedIndex = 0
        Me.tabApplication.Size = New System.Drawing.Size(872, 568)
        Me.tabApplication.TabIndex = 2
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label34.Location = New System.Drawing.Point(10, 285)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(60, 10)
        Me.Label34.TabIndex = 412
        Me.Label34.Text = "YYYY-MM-DD"
        '
        'txtTSEDate
        '
        Me.txtTSEDate.Location = New System.Drawing.Point(6, 250)
        Me.txtTSEDate.Name = "txtTSEDate"
        Me.txtTSEDate.Size = New System.Drawing.Size(70, 20)
        Me.txtTSEDate.TabIndex = 401
        '
        'txtTOEFLDate
        '
        Me.txtTOEFLDate.Location = New System.Drawing.Point(6, 217)
        Me.txtTOEFLDate.Name = "txtTOEFLDate"
        Me.txtTOEFLDate.Size = New System.Drawing.Size(70, 20)
        Me.txtTOEFLDate.TabIndex = 399
        '
        'txtGMATTotal
        '
        Me.txtGMATTotal.Location = New System.Drawing.Point(159, 183)
        Me.txtGMATTotal.Name = "txtGMATTotal"
        Me.txtGMATTotal.Size = New System.Drawing.Size(35, 20)
        Me.txtGMATTotal.TabIndex = 398
        '
        'txtTSETotal
        '
        Me.txtTSETotal.Location = New System.Drawing.Point(160, 250)
        Me.txtTSETotal.Name = "txtTSETotal"
        Me.txtTSETotal.Size = New System.Drawing.Size(34, 20)
        Me.txtTSETotal.TabIndex = 402
        '
        'txtTOEFLTotal
        '
        Me.txtTOEFLTotal.Location = New System.Drawing.Point(160, 217)
        Me.txtTOEFLTotal.Name = "txtTOEFLTotal"
        Me.txtTOEFLTotal.Size = New System.Drawing.Size(34, 20)
        Me.txtTOEFLTotal.TabIndex = 400
        '
        'txtGMATDate
        '
        Me.txtGMATDate.Location = New System.Drawing.Point(6, 182)
        Me.txtGMATDate.Name = "txtGMATDate"
        Me.txtGMATDate.Size = New System.Drawing.Size(70, 20)
        Me.txtGMATDate.TabIndex = 397
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(6, 162)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(120, 13)
        Me.Label24.TabIndex = 404
        Me.Label24.Text = "(Taken or to be Taken):"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(197, 253)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(55, 13)
        Me.Label41.TabIndex = 411
        Me.Label41.Text = "TSE Total"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(197, 221)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(68, 13)
        Me.Label40.TabIndex = 409
        Me.Label40.Text = "TOEFL Total"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(197, 186)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(65, 13)
        Me.Label35.TabIndex = 407
        Me.Label35.Text = "GMAT Total"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(156, 157)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(43, 13)
        Me.Label33.TabIndex = 405
        Me.Label33.Text = "Scores:"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(82, 253)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(30, 13)
        Me.Label30.TabIndex = 410
        Me.Label30.Text = "GRE"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(82, 220)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(41, 13)
        Me.Label29.TabIndex = 408
        Me.Label29.Text = "TOEFL"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(9, 149)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(59, 13)
        Me.Label32.TabIndex = 403
        Me.Label32.Text = "Test Dates"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(82, 186)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(38, 13)
        Me.Label28.TabIndex = 406
        Me.Label28.Text = "GMAT"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkAppForm)
        Me.GroupBox1.Controls.Add(Me.Label63)
        Me.GroupBox1.Controls.Add(Me.chkAppFeePaid)
        Me.GroupBox1.Controls.Add(Me.chkResume)
        Me.GroupBox1.Controls.Add(Me.chkLOR)
        Me.GroupBox1.Controls.Add(Me.chkTranscript)
        Me.GroupBox1.Controls.Add(Me.chkEssay)
        Me.GroupBox1.Controls.Add(Me.chkGMATScore)
        Me.GroupBox1.Controls.Add(Me.chkEducation)
        Me.GroupBox1.Controls.Add(Me.chkFinancial)
        Me.GroupBox1.Controls.Add(Me.chkTOEFL)
        Me.GroupBox1.Location = New System.Drawing.Point(380, 178)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(374, 219)
        Me.GroupBox1.TabIndex = 413
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Required Documents"
        '
        'chkAppForm
        '
        Me.chkAppForm.AutoSize = True
        Me.chkAppForm.Location = New System.Drawing.Point(9, 43)
        Me.chkAppForm.Name = "chkAppForm"
        Me.chkAppForm.Size = New System.Drawing.Size(176, 17)
        Me.chkAppForm.TabIndex = 269
        Me.chkAppForm.Text = "Walton College Applicaion Form"
        Me.chkAppForm.UseVisualStyleBackColor = True
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label63.Location = New System.Drawing.Point(6, 19)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(60, 13)
        Me.Label63.TabIndex = 265
        Me.Label63.Text = "Check List:"
        '
        'chkAppFeePaid
        '
        Me.chkAppFeePaid.AutoSize = True
        Me.chkAppFeePaid.Location = New System.Drawing.Point(9, 60)
        Me.chkAppFeePaid.Name = "chkAppFeePaid"
        Me.chkAppFeePaid.Size = New System.Drawing.Size(99, 17)
        Me.chkAppFeePaid.TabIndex = 266
        Me.chkAppFeePaid.Text = "Application Fee"
        Me.chkAppFeePaid.UseVisualStyleBackColor = True
        '
        'chkResume
        '
        Me.chkResume.AutoSize = True
        Me.chkResume.Location = New System.Drawing.Point(9, 77)
        Me.chkResume.Name = "chkResume"
        Me.chkResume.Size = New System.Drawing.Size(65, 17)
        Me.chkResume.TabIndex = 267
        Me.chkResume.Text = "Resume"
        Me.chkResume.UseVisualStyleBackColor = True
        '
        'chkLOR
        '
        Me.chkLOR.AutoSize = True
        Me.chkLOR.Location = New System.Drawing.Point(9, 94)
        Me.chkLOR.Name = "chkLOR"
        Me.chkLOR.Size = New System.Drawing.Size(187, 17)
        Me.chkLOR.TabIndex = 270
        Me.chkLOR.Text = "Three Letters of Recommendation"
        Me.chkLOR.UseVisualStyleBackColor = True
        '
        'chkTranscript
        '
        Me.chkTranscript.AutoSize = True
        Me.chkTranscript.Location = New System.Drawing.Point(9, 111)
        Me.chkTranscript.Name = "chkTranscript"
        Me.chkTranscript.Size = New System.Drawing.Size(257, 17)
        Me.chkTranscript.TabIndex = 271
        Me.chkTranscript.Text = "Official Transcripts from each University attended"
        Me.chkTranscript.UseVisualStyleBackColor = True
        '
        'chkEssay
        '
        Me.chkEssay.AutoSize = True
        Me.chkEssay.Location = New System.Drawing.Point(9, 128)
        Me.chkEssay.Name = "chkEssay"
        Me.chkEssay.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkEssay.Size = New System.Drawing.Size(104, 17)
        Me.chkEssay.TabIndex = 268
        Me.chkEssay.Text = "Essay Questions"
        Me.chkEssay.UseVisualStyleBackColor = True
        '
        'chkGMATScore
        '
        Me.chkGMATScore.AutoSize = True
        Me.chkGMATScore.Location = New System.Drawing.Point(9, 145)
        Me.chkGMATScore.Name = "chkGMATScore"
        Me.chkGMATScore.Size = New System.Drawing.Size(116, 17)
        Me.chkGMATScore.TabIndex = 276
        Me.chkGMATScore.Text = "GMAT/GRE Score"
        Me.chkGMATScore.UseVisualStyleBackColor = True
        '
        'chkEducation
        '
        Me.chkEducation.AutoSize = True
        Me.chkEducation.Location = New System.Drawing.Point(9, 162)
        Me.chkEducation.Name = "chkEducation"
        Me.chkEducation.Size = New System.Drawing.Size(328, 17)
        Me.chkEducation.TabIndex = 272
        Me.chkEducation.Text = "Summary of educational experience (International Students only)"
        Me.chkEducation.UseVisualStyleBackColor = True
        '
        'chkFinancial
        '
        Me.chkFinancial.AutoSize = True
        Me.chkFinancial.Location = New System.Drawing.Point(9, 179)
        Me.chkFinancial.Name = "chkFinancial"
        Me.chkFinancial.Size = New System.Drawing.Size(371, 17)
        Me.chkFinancial.TabIndex = 273
        Me.chkFinancial.Text = "Supplemental and Financial Information Form (International Students only)"
        Me.chkFinancial.UseVisualStyleBackColor = True
        '
        'chkTOEFL
        '
        Me.chkTOEFL.AutoSize = True
        Me.chkTOEFL.Location = New System.Drawing.Point(9, 196)
        Me.chkTOEFL.Name = "chkTOEFL"
        Me.chkTOEFL.Size = New System.Drawing.Size(194, 17)
        Me.chkTOEFL.TabIndex = 274
        Me.chkTOEFL.Text = "TOEFL (International Students only)"
        Me.chkTOEFL.UseVisualStyleBackColor = True
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(382, 162)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(123, 13)
        Me.Label36.TabIndex = 415
        Me.Label36.Text = "considered COMPLETE:"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(382, 149)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(336, 13)
        Me.Label43.TabIndex = 414
        Me.Label43.Text = "The following materials MUST be be submitted BEFORE application is"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(336, 400)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(55, 13)
        Me.Label42.TabIndex = 450
        Me.Label42.Text = "Education"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label39.Location = New System.Drawing.Point(284, 516)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(60, 10)
        Me.Label39.TabIndex = 448
        Me.Label39.Text = "YYYY-MM-DD"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label38.Location = New System.Drawing.Point(204, 516)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(60, 10)
        Me.Label38.TabIndex = 447
        Me.Label38.Text = "YYYY-MM-DD"
        '
        'txtCFrom1
        '
        Me.txtCFrom1.Location = New System.Drawing.Point(286, 467)
        Me.txtCFrom1.Name = "txtCFrom1"
        Me.txtCFrom1.Size = New System.Drawing.Size(70, 20)
        Me.txtCFrom1.TabIndex = 418
        '
        'txtCFrom2
        '
        Me.txtCFrom2.Location = New System.Drawing.Point(286, 493)
        Me.txtCFrom2.Name = "txtCFrom2"
        Me.txtCFrom2.Size = New System.Drawing.Size(70, 20)
        Me.txtCFrom2.TabIndex = 427
        '
        'txtCTo1
        '
        Me.txtCTo1.Location = New System.Drawing.Point(206, 467)
        Me.txtCTo1.Name = "txtCTo1"
        Me.txtCTo1.Size = New System.Drawing.Size(70, 20)
        Me.txtCTo1.TabIndex = 417
        '
        'txtCTo2
        '
        Me.txtCTo2.Location = New System.Drawing.Point(206, 493)
        Me.txtCTo2.Name = "txtCTo2"
        Me.txtCTo2.Size = New System.Drawing.Size(70, 20)
        Me.txtCTo2.TabIndex = 426
        '
        'txtCurrentHours2
        '
        Me.txtCurrentHours2.Location = New System.Drawing.Point(701, 493)
        Me.txtCurrentHours2.Name = "txtCurrentHours2"
        Me.txtCurrentHours2.Size = New System.Drawing.Size(50, 20)
        Me.txtCurrentHours2.TabIndex = 433
        '
        'txtCurrentHours1
        '
        Me.txtCurrentHours1.Location = New System.Drawing.Point(701, 467)
        Me.txtCurrentHours1.Name = "txtCurrentHours1"
        Me.txtCurrentHours1.Size = New System.Drawing.Size(50, 20)
        Me.txtCurrentHours1.TabIndex = 424
        '
        'txtDegree2
        '
        Me.txtDegree2.Location = New System.Drawing.Point(502, 492)
        Me.txtDegree2.Name = "txtDegree2"
        Me.txtDegree2.Size = New System.Drawing.Size(55, 20)
        Me.txtDegree2.TabIndex = 430
        '
        'txtDegree1
        '
        Me.txtDegree1.Location = New System.Drawing.Point(502, 467)
        Me.txtDegree1.Name = "txtDegree1"
        Me.txtDegree1.Size = New System.Drawing.Size(55, 20)
        Me.txtDegree1.TabIndex = 421
        '
        'txtHoursEarned2
        '
        Me.txtHoursEarned2.Location = New System.Drawing.Point(432, 492)
        Me.txtHoursEarned2.Name = "txtHoursEarned2"
        Me.txtHoursEarned2.Size = New System.Drawing.Size(50, 20)
        Me.txtHoursEarned2.TabIndex = 429
        '
        'txtHoursEarned1
        '
        Me.txtHoursEarned1.Location = New System.Drawing.Point(432, 466)
        Me.txtHoursEarned1.Name = "txtHoursEarned1"
        Me.txtHoursEarned1.Size = New System.Drawing.Size(50, 20)
        Me.txtHoursEarned1.TabIndex = 420
        '
        'txtCGPA2
        '
        Me.txtCGPA2.Location = New System.Drawing.Point(362, 492)
        Me.txtCGPA2.Name = "txtCGPA2"
        Me.txtCGPA2.Size = New System.Drawing.Size(50, 20)
        Me.txtCGPA2.TabIndex = 428
        '
        'txtCGPA1
        '
        Me.txtCGPA1.Location = New System.Drawing.Point(362, 467)
        Me.txtCGPA1.Name = "txtCGPA1"
        Me.txtCGPA1.Size = New System.Drawing.Size(50, 20)
        Me.txtCGPA1.TabIndex = 419
        '
        'txtCName2
        '
        Me.txtCName2.Location = New System.Drawing.Point(16, 493)
        Me.txtCName2.Name = "txtCName2"
        Me.txtCName2.Size = New System.Drawing.Size(182, 20)
        Me.txtCName2.TabIndex = 425
        '
        'txtCName1
        '
        Me.txtCName1.Location = New System.Drawing.Point(16, 467)
        Me.txtCName1.Name = "txtCName1"
        Me.txtCName1.Size = New System.Drawing.Size(182, 20)
        Me.txtCName1.TabIndex = 416
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Location = New System.Drawing.Point(698, 451)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(96, 13)
        Me.Label61.TabIndex = 446
        Me.Label61.Text = "Current Enrollment:"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(698, 438)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(47, 13)
        Me.Label62.TabIndex = 445
        Me.Label62.Text = "Hours of"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(499, 451)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(45, 13)
        Me.Label60.TabIndex = 441
        Me.Label60.Text = "Degree:"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(415, 451)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(75, 13)
        Me.Label59.TabIndex = 440
        Me.Label59.Text = "Hours Earned:"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(423, 438)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(51, 13)
        Me.Label58.TabIndex = 439
        Me.Label58.Text = "Semester"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(359, 451)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(32, 13)
        Me.Label57.TabIndex = 438
        Me.Label57.Text = "GPA:"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(203, 438)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(84, 13)
        Me.Label56.TabIndex = 435
        Me.Label56.Text = "Dates Attended:"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(283, 451)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(33, 13)
        Me.Label55.TabIndex = 437
        Me.Label55.Text = "From:"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(203, 451)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(23, 13)
        Me.Label54.TabIndex = 436
        Me.Label54.Text = "To:"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(13, 451)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(76, 13)
        Me.Label53.TabIndex = 434
        Me.Label53.Text = "College Name:"
        '
        'InsertButton
        '
        Me.InsertButton.Location = New System.Drawing.Point(657, 11)
        Me.InsertButton.Name = "InsertButton"
        Me.InsertButton.Size = New System.Drawing.Size(75, 23)
        Me.InsertButton.TabIndex = 451
        Me.InsertButton.Text = "Insert"
        Me.InsertButton.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(903, 24)
        Me.MenuStrip1.TabIndex = 3
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(35, 20)
        Me.ToolStripMenuItem1.Text = "File"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'ckbGraduated1
        '
        Me.ckbGraduated1.AutoSize = True
        Me.ckbGraduated1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ckbGraduated1.Location = New System.Drawing.Point(563, 470)
        Me.ckbGraduated1.Name = "ckbGraduated1"
        Me.ckbGraduated1.Size = New System.Drawing.Size(82, 17)
        Me.ckbGraduated1.TabIndex = 452
        Me.ckbGraduated1.Text = "Graduated?"
        Me.ckbGraduated1.UseVisualStyleBackColor = True
        '
        'ckbGraduated2
        '
        Me.ckbGraduated2.AutoSize = True
        Me.ckbGraduated2.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ckbGraduated2.Location = New System.Drawing.Point(564, 492)
        Me.ckbGraduated2.Name = "ckbGraduated2"
        Me.ckbGraduated2.Size = New System.Drawing.Size(82, 17)
        Me.ckbGraduated2.TabIndex = 453
        Me.ckbGraduated2.Text = "Graduated?"
        Me.ckbGraduated2.UseVisualStyleBackColor = True
        '
        'Advisors
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(903, 611)
        Me.Controls.Add(Me.tabApplication)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Advisors"
        Me.Text = "Advisors"
        Me.chbGraduated2.ResumeLayout(False)
        Me.chbGraduated2.PerformLayout()
        Me.tabPersonalInfo.ResumeLayout(False)
        Me.tabPersonalInfo.PerformLayout()
        Me.tabApplication.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents chbGraduated2 As TabPage
    Friend WithEvents Label2 As Label
    Friend WithEvents cbxReqProgram As ComboBox
    Friend WithEvents Label37 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label67 As Label
    Friend WithEvents cbxStanding As ComboBox
    Friend WithEvents lblSession As Label
    Friend WithEvents cbxSession As ComboBox
    Friend WithEvents txtEnrolled_When As TextBox
    Friend WithEvents txtBefore_when As TextBox
    Friend WithEvents txtRequestYear As TextBox
    Friend WithEvents Label27 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents chkEnrolled As CheckBox
    Friend WithEvents Label25 As Label
    Friend WithEvents chkBefore As CheckBox
    Friend WithEvents Label23 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents tabPersonalInfo As TabPage
    Friend WithEvents chbxHisorLatin As CheckBox
    Friend WithEvents lblBirthdayFormat As Label
    Friend WithEvents cbxFState As ComboBox
    Friend WithEvents cbxLState As ComboBox
    Friend WithEvents cbxPState As ComboBox
    Friend WithEvents txtPZipCode As MaskedTextBox
    Friend WithEvents txtLZipCode As MaskedTextBox
    Friend WithEvents txtFZipCode As MaskedTextBox
    Friend WithEvents txtWorkPhone As MaskedTextBox
    Friend WithEvents txtCurrentPhone As MaskedTextBox
    Friend WithEvents txtBirthday1 As MaskedTextBox
    Friend WithEvents txtSSN As MaskedTextBox
    Friend WithEvents cbxOrigin As ComboBox
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents txtStudentID As TextBox
    Friend WithEvents txtFYears As TextBox
    Friend WithEvents txtLCity As TextBox
    Friend WithEvents txtLAddress As TextBox
    Friend WithEvents txtFCity As TextBox
    Friend WithEvents txtFAddress As TextBox
    Friend WithEvents txtPYears As TextBox
    Friend WithEvents txtPCity As TextBox
    Friend WithEvents txtPAddress As TextBox
    Friend WithEvents txtFirstName As TextBox
    Friend WithEvents txtMiddleName As TextBox
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents Label72 As Label
    Friend WithEvents cbxCitizenship As ComboBox
    Friend WithEvents cbxGender As ComboBox
    Friend WithEvents Label71 As Label
    Friend WithEvents Label66 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label65 As Label
    Friend WithEvents Label50 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents chkResident As CheckBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents cbxEthnic As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblDOB As Label
    Friend WithEvents lblSSN As Label
    Friend WithEvents lblName As Label
    Friend WithEvents lblMiddleName As Label
    Friend WithEvents lblFirstName As Label
    Friend WithEvents lblLastName As Label
    Friend WithEvents tabApplication As TabControl
    Friend WithEvents Label42 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents txtCFrom1 As TextBox
    Friend WithEvents txtCFrom2 As TextBox
    Friend WithEvents txtCTo1 As TextBox
    Friend WithEvents txtCTo2 As TextBox
    Friend WithEvents txtCurrentHours2 As TextBox
    Friend WithEvents txtCurrentHours1 As TextBox
    Friend WithEvents txtDegree2 As TextBox
    Friend WithEvents txtDegree1 As TextBox
    Friend WithEvents txtHoursEarned2 As TextBox
    Friend WithEvents txtHoursEarned1 As TextBox
    Friend WithEvents txtCGPA2 As TextBox
    Friend WithEvents txtCGPA1 As TextBox
    Friend WithEvents txtCName2 As TextBox
    Friend WithEvents txtCName1 As TextBox
    Friend WithEvents Label61 As Label
    Friend WithEvents Label62 As Label
    Friend WithEvents Label60 As Label
    Friend WithEvents Label59 As Label
    Friend WithEvents Label58 As Label
    Friend WithEvents Label57 As Label
    Friend WithEvents Label56 As Label
    Friend WithEvents Label55 As Label
    Friend WithEvents Label54 As Label
    Friend WithEvents Label53 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents chkAppForm As CheckBox
    Friend WithEvents Label63 As Label
    Friend WithEvents chkAppFeePaid As CheckBox
    Friend WithEvents chkResume As CheckBox
    Friend WithEvents chkLOR As CheckBox
    Friend WithEvents chkTranscript As CheckBox
    Friend WithEvents chkEssay As CheckBox
    Friend WithEvents chkGMATScore As CheckBox
    Friend WithEvents chkEducation As CheckBox
    Friend WithEvents chkFinancial As CheckBox
    Friend WithEvents chkTOEFL As CheckBox
    Friend WithEvents Label34 As Label
    Friend WithEvents txtTSEDate As TextBox
    Friend WithEvents txtTOEFLDate As TextBox
    Friend WithEvents txtGMATTotal As TextBox
    Friend WithEvents txtTSETotal As TextBox
    Friend WithEvents txtTOEFLTotal As TextBox
    Friend WithEvents txtGMATDate As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents InsertButton As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ckbGraduated2 As CheckBox
    Friend WithEvents ckbGraduated1 As CheckBox
End Class
