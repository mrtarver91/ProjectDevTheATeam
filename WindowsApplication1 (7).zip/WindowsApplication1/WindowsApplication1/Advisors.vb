﻿
Imports System.Data.OleDb

Public Class Advisors
    'Declares variables for application
    Dim RowsInsertedInteger = 0
    'Declares variables for application
    Dim ssn As String = ""
    Dim ssnsearch As String = ""
    Dim LastName As String = ""
    Dim selectedStudent As String = ""
    Dim totalAppl As String = ""
    Dim avgGPA As String = ""
    Dim avgGMAT As String = ""
    Dim avgTOEFL As String = ""
    Dim avgGRE As String = ""
    Dim totalAdmis As String = ""
    Dim totalArRe As String = ""
    Dim totalBlack As String = ""
    Dim totalWhite As String = ""
    Dim totalAsian As String = ""
    Dim totalIndian As String = ""
    Dim totalHispanic As String = ""
    'Connection variables for the database
    Dim con As New OleDbConnection()
    'This goes to the connection class file and gets the connection string with username/password
    Dim ConnInfo As DBConnectionInfo = New DBConnectionInfo
    Dim ConnString As String = ConnInfo.GetConnString()
    'These are variables for the datagrid view
    Dim oledbAdapter As OleDbDataAdapter
    Dim sqlstring As String

    Private Sub PostToDB_Course()
        'This is where you would put all code to be executed
        Try
            'When students are admitted inserts a 0 into the Admitted column, to say the student hasn't be admitted yet
            Dim zero As String = "0"
            'Create a SQL command to insert the new student information
            Dim command As New OleDbCommand("INSERT INTO GRADSTUDENTS (SSN,LASTNAME, MIDDLENAME, FIRSTNAME,DOB, BIRTHPLACE, RACE, GENDER, CITIZENSHIP, PERMADDRESS, PERMCITY, PERMZIPCODE,PERMSTATE, YEARSATPERM,MAILADDRESS,MAILCITY, MAILSTATE,MAILZIPCODE, FORMERADDRESS, FORMERCITY, FORMERSTATE,FORMERZIPCODE,YEARSATFORMER,ARRESIDENT,HOMEPHONE,CELLPHONE,EMAIL,HISORLATIN, ADMITREQYEAR,ADMITREQTERM,major,APPLIEDWHEN,PREVENROLL,APPLIEDBEFORE,PREVENROLLWHEN,PREVENROLLLEVEL,COLLEGE1,COLLEGE2,COLLEGE1HOURS,COLLEGE2HOURS,COLLEGE1GPA,COLLEGE2GPA,COLLEGE1GRADUATED,COLLEGE2GRADUATED,COLLEGE1DEGREE,COLLEGE2DEGREE,COLLEGE1DATET,COLLEGE1DATEF,COLLEGE2DATET,COLLEGE2DATEF,GMATDATE,TOEFLDATE,GREDATE,GMAT,TOEFL,GRE,APPLICFORM,APPLICFEE,RESUME,LORS,TRANSCRIPTS,ESSAYQ,GMATGRE,EDUEXP,SUPPFINNFORM,TOEFLINCLU,ADMITTED,HONORS1,HONORS2,CONCENTRATION) VALUES (" & txtSSN.Text & ",'" & Me.txtLastName.Text & "','" & Me.txtMiddleName.Text & "','" & Me.txtFirstName.Text & "','" & Me.txtBirthday1.Text & "','" & Me.cbxOrigin.Text & "','" & Me.cbxEthnic.Text & "','" & Me.cbxGender.Text & "','" & Me.cbxCitizenship.Text & "','" & Me.txtPAddress.Text & "','" & Me.txtPCity.Text & "','" & Me.txtPZipCode.Text & "','" & Me.cbxPState.Text & "','" & Me.txtPYears.Text & "','" & Me.txtLAddress.Text & "','" & Me.txtLCity.Text & "','" & Me.cbxLState.Text & "','" & Me.txtLZipCode.Text & "','" & Me.txtFAddress.Text & "','" & Me.txtFCity.Text & "','" & Me.cbxFState.Text & "','" & Me.txtFZipCode.Text & "','" & Me.txtFYears.Text & "','" & Me.chkResident.Checked.ToString & "','" & Me.txtCurrentPhone.Text & "','" & Me.txtWorkPhone.Text & "','" & Me.txtEmail.Text & "','" & Me.chbxHisorLatin.Checked.ToString & "' ,'" & Me.txtRequestYear.Text & "','" & Me.cbxSession.Text & "','" & Me.cbxReqProgram.Text & "','" & Me.txtBefore_when.Text & "','" & Me.chkEnrolled.Checked.ToString & "' ,'" & Me.chkBefore.Checked.ToString & "' ,'" & Me.txtEnrolled_When.Text & "','" & Me.cbxStanding.Text & "','" & Me.txtCName1.Text & "','" & Me.txtCName2.Text & "','" & Me.txtHoursEarned1.Text & "','" & Me.txtHoursEarned2.Text & "','" & Me.txtCGPA1.Text & "','" & Me.txtCGPA2.Text & "','" & Me.ckbGraduated1.Checked.ToString & "' ,'" & Me.ckbGraduated2.Checked.ToString & "','" & Me.txtDegree1.Text & "' ,'" & Me.txtDegree2.Text & "' ,'" & Me.txtCTo1.Text & "','" & Me.txtCFrom1.Text & "','" & Me.txtCTo2.Text & "','" & Me.txtCFrom2.Text & "','" & Me.txtGMATDate.Text & "','" & Me.txtTOEFLDate.Text & "','" & Me.txtTSEDate.Text & "' ,'" & Me.txtGMATTotal.Text & "','" & Me.txtTOEFLTotal.Text & "','" & Me.txtTSETotal.Text & "' ,'" & Me.chkAppForm.Checked & "','" & Me.chkAppFeePaid.Checked & "','" & Me.chkResume.Checked & "','" & Me.chkLOR.Checked & "','" & Me.chkTranscript.Checked & "','" & Me.chkEssay.Checked & "','" & Me.chkGMATScore.Checked & "','" & Me.chkEducation.Checked & "','" & Me.chkFinancial.Checked & "','" & Me.chkTOEFL.Checked & "', '" & zero & "','" & Me.chbHonors1.Checked & "','" & Me.chbHonors2.Checked & "','" & Me.cbxConcentration.Text & "');", con)
            'MessageBox.Show(command.CommandText.ToString())
            'Opens connection to the database
            con.ConnectionString = ConnString
            con.Open()
            'Execute the Insert Statement in the command variable
            RowsInsertedInteger = command.ExecuteNonQuery()
            'Close the connection
            con.Close()
        Catch ex As Exception
            'This is what happens if there is an error
            MessageBox.Show("Error in saving information to the database: " & ex.Message)
            con.Close()
        Finally
            'If all else fails, this will run
            'Close DB Connection here
            con.Close()
        End Try
    End Sub
    Private Sub ClearFields()
        'Clearing all data fields on the form
        Me.txtLastName.Clear()
        Me.txtFirstName.Clear()
        Me.txtMiddleName.Clear()
        Me.txtSSN.Clear()
        Me.txtBirthday1.Clear()
        Me.cbxOrigin.ResetText()
        Me.cbxEthnic.ResetText()
        Me.cbxGender.ResetText()
        Me.cbxCitizenship.ResetText()
        Me.chbxHisorLatin.Checked = False
        Me.txtPAddress.Clear()
        Me.txtPCity.Clear()
        Me.cbxPState.ResetText()
        Me.txtPZipCode.Clear()
        Me.txtFAddress.Clear()
        Me.txtFCity.Clear()
        Me.cbxFState.ResetText()
        Me.txtFZipCode.Clear()
        Me.chkResident.Checked = False
        Me.txtLAddress.Clear()
        Me.txtLCity.Clear()
        Me.cbxLState.ResetText()
        Me.txtLZipCode.Clear()
        Me.txtPYears.Clear()
        Me.txtFYears.Clear()
        Me.txtCurrentPhone.Clear()
        Me.txtWorkPhone.Clear()
        Me.txtEmail.Clear()
        Me.txtGMATDate.Clear()
        Me.txtGMATTotal.Clear()
        Me.txtTOEFLDate.Clear()
        Me.txtTOEFLTotal.Clear()
        Me.txtTSEDate.Clear()
        Me.txtTSETotal.Clear()
        Me.txtCName1.Clear()
        Me.txtCTo1.Clear()
        Me.txtCFrom1.Clear()
        Me.txtHoursEarned1.Clear()
        Me.txtDegree1.Clear()
        Me.ckbGraduated1.Checked = False
        Me.ckbGraduated2.Checked = False
        Me.txtCGPA1.Clear()
        Me.txtCGPA2.Clear()
        Me.txtCName2.Clear()
        Me.txtCTo2.Clear()
        Me.txtCFrom2.Clear()
        Me.txtHoursEarned2.Clear()
        Me.txtDegree2.Clear()
        Me.txtRequestYear.Clear()
        Me.cbxSession.ResetText()
        Me.chkBefore.Checked = False
        Me.txtBefore_when.Clear()
        Me.chkEnrolled.Checked = False
        Me.txtEnrolled_When.Clear()
        Me.cbxStanding.ResetText()
        Me.cbxReqProgram.ResetText()
        Me.chkAppFeePaid.Checked = False
        Me.chkResume.Checked = False
        Me.chkEssay.Checked = False
        Me.chkAppForm.Checked = False
        Me.chkLOR.Checked = False
        Me.chkTranscript.Checked = False
        Me.chkEducation.Checked = False
        Me.chkFinancial.Checked = False
        Me.chkTOEFL.Checked = False
        Me.chkGMATScore.Checked = False

    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()

    End Sub

    Private Sub InsertButton_Click(sender As Object, e As EventArgs) Handles InsertButton.Click

        'Validating applicatino form fields
        If Me.txtLastName.Text.Length = 0 Then
            Me.ErrorProvider1.SetError(txtLastName, "Field required.")
        Else
            Me.ErrorProvider1.SetError(txtLastName, "")
        End If
        If Me.txtFirstName.Text.Length = 0 Then
            Me.ErrorProvider1.SetError(txtFirstName, "Field required.")
        Else
            Me.ErrorProvider1.SetError(txtFirstName, "")
        End If

        If Not (txtSSN.Text Like "#########") Then
            Me.ErrorProvider1.SetError(txtSSN, "SSN must be in ########## format.")
        Else
            Me.ErrorProvider1.SetError(txtSSN, "")
        End If
        If Me.txtBirthday1.Text.Length = 0 Then
            Me.ErrorProvider1.SetError(txtBirthday1, "Field required.")
        Else
            Me.ErrorProvider1.SetError(txtBirthday1, "")
        End If
        If Me.cbxOrigin.Text.Length = 0 Then
            Me.ErrorProvider1.SetError(cbxOrigin, "Field required.")
        Else
            Me.ErrorProvider1.SetError(cbxOrigin, "")
        End If
        If Me.txtSSN.Text.Length = 0 Then
            Me.ErrorProvider1.SetError(txtSSN, "Field required.")
        Else
            Me.ErrorProvider1.SetError(txtSSN, "")
        End If
        If Me.cbxEthnic.Text.Length = 0 Then
            Me.ErrorProvider1.SetError(cbxEthnic, "Field required.")
        Else
            Me.ErrorProvider1.SetError(cbxEthnic, "")
        End If
        If Me.cbxGender.Text.Length = 0 Then
            Me.ErrorProvider1.SetError(cbxGender, "Field required.")
        Else
            Me.ErrorProvider1.SetError(cbxGender, "")
        End If
        If Me.cbxCitizenship.Text.Length = 0 Then
            Me.ErrorProvider1.SetError(cbxCitizenship, "Field required.")
        Else
            Me.ErrorProvider1.SetError(cbxCitizenship, "")
        End If
        If Me.txtPAddress.Text.Length = 0 Then
            Me.ErrorProvider1.SetError(txtPAddress, "Field required.")
        Else
            Me.ErrorProvider1.SetError(txtPAddress, "")
        End If
        If Me.txtPCity.Text.Length = 0 Then
            Me.ErrorProvider1.SetError(txtPCity, "Field required.")
        Else
            Me.ErrorProvider1.SetError(txtPCity, "")
        End If
        If Me.cbxPState.Text.Length = 0 Then
            Me.ErrorProvider1.SetError(cbxPState, "Field required.")
        Else
            Me.ErrorProvider1.SetError(cbxPState, "")
        End If
        If Not (txtPZipCode.Text Like "#####-####") Then
            Me.ErrorProvider1.SetError(txtPZipCode, "Zip Code must be in #####-#### format.")
        Else
            Me.ErrorProvider1.SetError(txtPZipCode, "")
        End If
        If Me.txtLAddress.Text.Length = 0 Then
            Me.ErrorProvider1.SetError(txtLAddress, "Field required.")
        Else
            Me.ErrorProvider1.SetError(txtLAddress, "")
        End If
        If Me.txtLCity.Text.Length = 0 Then
            Me.ErrorProvider1.SetError(txtLCity, "Field required.")
        Else
            Me.ErrorProvider1.SetError(txtLCity, "")
        End If
        If Me.cbxLState.Text.Length = 0 Then
            Me.ErrorProvider1.SetError(cbxLState, "Field required.")
        Else
            Me.ErrorProvider1.SetError(cbxLState, "")
        End If
        If Not (txtLZipCode.Text Like "#####-####") Then
            Me.ErrorProvider1.SetError(txtLZipCode, "Zip Code must be in #####-#### format.")
        Else
            Me.ErrorProvider1.SetError(txtLZipCode, "")
        End If
        If Me.txtRequestYear.Text.Length = 0 Then
            Me.ErrorProvider1.SetError(txtRequestYear, "Field required.")
        Else
            Me.ErrorProvider1.SetError(txtRequestYear, "")
        End If
        If Me.txtGMATDate.Text.Length = 0 Then
            Me.ErrorProvider1.SetError(txtGMATDate, "Please enter students GMAT date.")
        Else
            Me.ErrorProvider1.SetError(txtGMATDate, "")
        End If

        If Me.txtGMATTotal.Text.Length = 0 Then
            Me.ErrorProvider1.SetError(txtGMATTotal, "Please enter students Total GMAT Score.")
        Else
            Me.ErrorProvider1.SetError(txtGMATTotal, "")
        End If
        PostToDB_Course()
    End Sub

    Private Sub ClearFieldsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClearFieldsToolStripMenuItem.Click
        ClearFields()
    End Sub

    Private Sub SearchButton_Click(sender As Object, e As EventArgs) Handles SearchButton.Click
        Try
            Dim ds As New DataSet
            ssn = txtSSN.Text
            LastName = txtLastName.Text
            'This example will load the DataGridView
            Dim sql As String = "SELECT SSN, LASTNAME,FIRSTNAME, STUDENTID,ADMITTED From GRADSTUDENTS WHERE (SSN ='" & ssn & "'  OR LASTNAME ='" & LastName & "' );"
            con.ConnectionString = ConnString
            con.Open()
            oledbAdapter = New OleDbDataAdapter(sql, con)
            oledbAdapter.Fill(ds)
            DataGridView1.DataSource = ds.Tables(0)
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error in retrieving instructor list from database" & ex.Message, "Database Error")
            con.Close()
        End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try
            selectedStudent = DataGridView1.CurrentCell.FormattedValue
            Dim command As New OleDbCommand("SELECT SSN,LASTNAME, MIDDLENAME,FIRSTNAME,CONVERT (nvarchar(50), DOB, 20),BIRTHPLACE, RACE, GENDER, CITIZENSHIP, PERMADDRESS, PERMCITY, PERMZIPCODE,PERMSTATE, YEARSATPERM,MAILADDRESS,MAILCITY, MAILSTATE,MAILZIPCODE, FORMERADDRESS, FORMERCITY, FORMERSTATE,FORMERZIPCODE,YEARSATFORMER,ARRESIDENT,HOMEPHONE, CELLPHONE,EMAIL,HISORLATIN, ADMITREQYEAR,ADMITREQTERM,major,CONVERT(nvarchar(50), APPLIEDWHEN, 20),APPLIEDBEFORE,PREVENROLL,PREVENROLLLEVEL,COLLEGE1, COLLEGE2,COLLEGE1HOURS, COLLEGE2HOURS,COLLEGE1GPA, COLLEGE2GPA,COLLEGE1GRADUATED, COLLEGE2GRADUATED,COLLEGE1DEGREE, COLLEGE2DEGREE, GMAT, TOEFL, GRE, APPLICFORM, APPLICFEE,RESUME, LORS, TRANSCRIPTS, ESSAYQ, GMATGRE, EDUEXP, SUPPFINNFORM, TOEFLINCLU,CONVERT (nvarchar(50), PREVENROLLWHEN, 20),CONVERT (nvarchar(50), COLLEGE1DATET, 20),CONVERT (nvarchar(50), COLLEGE1DATEF, 20),CONVERT (nvarchar(50),COLLEGE2DATET, 20),CONVERT (nvarchar(50), COLLEGE2DATEF, 20),CONVERT (nvarchar(50), GMATDATE, 20),CONVERT (nvarchar(50), TOEFLDATE, 20),CONVERT (nvarchar(50), GREDATE, 20) FROM GRADSTUDENTS WHERE LASTNAME = '" & selectedStudent & "' ;", con)
            'CONVERT ( data_type [ ( length ) ] , expression [ , style ] )
            Dim dr As OleDbDataReader
            con.ConnectionString = ConnString
            con.Open()
            dr = command.ExecuteReader()
            While dr.Read()

                'DBTYPE_DBDATE
                txtSSN.Text = dr.GetString(0)
                txtLastName.Text = dr.GetString(1)
                txtMiddleName.Text = dr.GetString(2)
                txtFirstName.Text = dr.GetString(3)
                txtBirthday1.Text = dr.GetString(4)
                cbxOrigin.Text = dr.GetString(5)
                cbxEthnic.Text = dr.GetString(6)
                cbxGender.Text = dr.GetString(7)
                cbxCitizenship.Text = dr.GetString(8)
                txtPAddress.Text = dr.GetString(9)
                txtPCity.Text = dr.GetString(10)
                txtPZipCode.Text = dr.GetString(11)
                cbxPState.Text = dr.GetString(12)
                txtPYears.Text = dr.GetInt32(13)
                txtLAddress.Text = dr.GetString(14)
                txtLCity.Text = dr.GetString(15)
                cbxLState.Text = dr.GetString(16)
                txtLZipCode.Text = dr.GetString(17)
                txtFAddress.Text = dr.GetString(18)
                txtFCity.Text = dr.GetString(19)
                cbxFState.Text = dr.GetString(20)
                txtFZipCode.Text = dr.GetString(21)
                txtFYears.Text = dr.GetInt32(22)
                chkResident.Checked = dr.GetBoolean(23)
                txtCurrentPhone.Text = dr.GetString(24)
                txtWorkPhone.Text = dr.GetString(25)
                txtEmail.Text = dr.GetString(26)
                chbxHisorLatin.Checked = dr.GetBoolean(27)
                txtRequestYear.Text = dr.GetString(28)
                cbxSession.Text = dr.GetString(29)
                cbxReqProgram.Text = dr.GetString(30)
                txtBefore_when.Text = dr.GetString(31)
                chkBefore.Checked = dr.GetBoolean(32)
                chkEnrolled.Checked = dr.GetBoolean(33)
                cbxStanding.Text = dr.GetString(34)
                txtCName1.Text = dr.GetString(35)
                txtCName2.Text = dr.GetString(36)
                txtHoursEarned1.Text = dr.GetValue(37)
                txtHoursEarned2.Text = dr.GetValue(38)
                txtCGPA1.Text = dr.GetValue(39)
                txtCGPA2.Text = dr.GetValue(40)
                ckbGraduated1.Checked = dr.GetBoolean(41)
                ckbGraduated2.Checked = dr.GetBoolean(42)
                txtDegree1.Text = dr.GetString(43)
                txtDegree2.Text = dr.GetString(44)
                txtGMATTotal.Text = dr.GetInt32(45)
                txtTOEFLTotal.Text = dr.GetInt32(46)
                txtTSETotal.Text = dr.GetInt32(47)
                chkAppForm.Checked = dr.GetBoolean(48)
                chkAppFeePaid.Checked = dr.GetBoolean(49)
                chkResume.Checked = dr.GetBoolean(50)
                chkLOR.Checked = dr.GetBoolean(51)
                chkTranscript.Checked = dr.GetBoolean(52)
                chkEssay.Checked = dr.GetBoolean(53)
                chkGMATScore.Checked = dr.GetBoolean(54)
                chkEducation.Checked = dr.GetBoolean(55)
                chkFinancial.Checked = dr.GetBoolean(56)
                chkTOEFL.Checked = dr.GetBoolean(57)
                '***Need to find correct datatype .drGet????? for date fields

                txtEnrolled_When.Text = dr.GetString(58)
                txtCTo1.Text = dr.GetString(59)
                txtCFrom1.Text = dr.GetString(60)
                txtCTo2.Text = dr.GetString(61)
                txtCFrom2.Text = dr.GetString(62)
                txtGMATDate.Text = dr.GetString(63)
                txtTOEFLDate.Text = dr.GetString(64)
                txtTSEDate.Text = dr.GetString(65)
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error in retrieving producer list from database" & ex.Message, "Database Error")
            con.Close()
        End Try
    End Sub

    Private Sub DeleteButton_Click(sender As Object, e As EventArgs) Handles DeleteButton.Click
        Try
            Dim ds As New DataSet
            ssn = txtSSN.Text
            Dim sql As String = "DELETE  FROM GRADSTUDENTS WHERE SSN ='" & ssn & "';"
            'Insert a new record into the database table
            'Opens connection to the database
            con.ConnectionString = ConnString
            con.Open()
            'Close the connection
            con.Close()
        Catch ex As Exception
            'This is what happens if there is an error
            MessageBox.Show("Error in saving information to the database: " & ex.Message)
            con.Close()
        Finally
            'If all else fails, this will run
            'Close DB Connection here
            con.Close()
        End Try
    End Sub
    Private Sub UpdateSTIDAdmit()
        Try
            Dim command As New OleDbCommand("UPDATE GRADSTUDENTS SET STUDENTID = '" & Me.txtStudentID.Text & "' WHERE SSN =  '" & Me.TxtSSNSearch.Text & "' ;", con)
            con.ConnectionString = ConnString
            con.Open()
            'Close the connection
            con.Close()
        Catch ex As Exception
            'This is what happens if there is an error
            MessageBox.Show("Error in saving information to the database: " & ex.Message)
            con.Close()
        Finally
            'If all else fails, this will run
            'Close DB Connection here
            con.Close()
        End Try
    End Sub
    Private Sub UpdateAdmitStatus()
        Try
            ssnsearch = txtSSN.Text
            Dim command As New OleDbCommand("UPDATE GRADSTUDENTS SET ADMITTED= '" & Me.CheckBox_admit.Checked & "' WHERE SSN =  '" & Me.TxtSSNSearch.Text & "' ;", con)
            con.ConnectionString = ConnString
            con.Open()
            'Close the connection
            con.Close()

        Catch ex As Exception
            'This is what happens if there is an error
            MessageBox.Show("Error in saving information to the database: " & ex.Message)
            con.Close()
        Finally
            'If all else fails, this will run
            'Close DB Connection here
            con.Close()
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'Validation of fields
        If Not (txtStudentID.Text Like "#########") Then
            Me.ErrorProvider1.SetError(txtStudentID, "Student ID must be 9 numbers.")
        Else
            Me.ErrorProvider1.SetError(txtStudentID, "")
        End If
        If Not (TxtSSNSearch.Text Like "#########") Then
            Me.ErrorProvider1.SetError(TxtSSNSearch, "SSN must be in ########## format.")
        Else
            Me.ErrorProvider1.SetError(TxtSSNSearch, "")
        End If
        UpdateAdmitStatus()
        UpdateSTIDAdmit()
    End Sub

    Private Sub PostToDB_UpdateStudent()
        'This is where you would put all code to be executed
        Try
            'Create a SQL command to update the new student information
            ssn = 430812235
            'Another method of inserting fields into the database
            Dim command As New OleDbCommand("UPDATE GRADSTUDENTS SET LASTNAME = '" & Me.txtLastName.Text & "', MIDDLENAME = '" & Me.txtMiddleName.Text & "', FIRSTNAME = '" & Me.txtFirstName.Text & "',DOB = '" & Me.txtBirthday1.Text & "', BIRTHPLACE = '" & Me.cbxOrigin.Text & "', RACE = '" & Me.cbxEthnic.Text & "', GENDER = '" & Me.cbxGender.Text & "', CITIZENSHIP = '" & Me.cbxCitizenship.Text & "', PERMADDRESS = '" & Me.txtPAddress.Text & "', PERMCITY = '" & Me.txtPCity.Text & "', PERMZIPCODE = '" & Me.txtPZipCode.Text & "',PERMSTATE = '" & Me.cbxPState.Text & "', YEARSATPERM = '" & Me.txtPYears.Text & "',MAILADDRESS = '" & Me.txtLAddress.Text & "',MAILCITY = '" & Me.txtLCity.Text & "', MAILSTATE = '" & Me.cbxLState.Text & "',MAILZIPCODE = '" & Me.txtLZipCode.Text & "', FORMERADDRESS = '" & Me.txtFAddress.Text & "', FORMERCITY = '" & Me.txtFCity.Text & "', FORMERSTATE = '" & Me.cbxFState.Text & "',FORMERZIPCODE = '" & Me.txtFZipCode.Text & "',YEARSATFORMER = '" & Me.txtFYears.Text & "',ARRESIDENT = '" & Me.chkResident.Checked & "',HOMEPHONE = '" & Me.txtCurrentPhone.Text & "',CELLPHONE = '" & Me.txtWorkPhone.Text & "',EMAIL = '" & Me.txtEmail.Text & "',HISORLATIN = '" & Me.chbxHisorLatin.Checked & "', ADMITREQYEAR = '" & Me.txtRequestYear.Text & "',ADMITREQTERM = '" & Me.cbxSession.Text & "',major = '" & Me.cbxReqProgram.Text & "',APPLIEDWHEN = '" & Me.txtBefore_when.Text & "',PREVENROLL = '" & Me.chkBefore.Checked & "',APPLIEDBEFORE = '" & Me.chkEnrolled.Checked & "',PREVENROLLWHEN = '" & Me.txtEnrolled_When.Text & "',PREVENROLLLEVEL = '" & Me.cbxStanding.Text & "',COLLEGE1 = '" & Me.txtCName1.Text & "',COLLEGE2 = '" & Me.txtCName2.Text & "',COLLEGE1HOURS = '" & Me.txtHoursEarned1.Text & "',COLLEGE2HOURS = '" & Me.txtHoursEarned2.Text & "',COLLEGE1GPA = '" & Me.txtCGPA1.Text & "',COLLEGE2GPA = '" & Me.txtCGPA1.Text & "',COLLEGE1GRADUATED = '" & Me.ckbGraduated1.Checked & "',COLLEGE2GRADUATED = '" & Me.ckbGraduated2.Checked & "',COLLEGE1DEGREE = '" & Me.txtDegree1.Text & "',COLLEGE2DEGREE = '" & Me.txtDegree2.Text & "',COLLEGE1DATET = '" & Me.txtCTo1.Text & "',COLLEGE1DATEF = '" & Me.txtCFrom1.Text & "',COLLEGE2DATET = '" & Me.txtCTo2.Text & "',COLLEGE2DATEF = '" & Me.txtCFrom2.Text & "',GMATDATE = '" & Me.txtGMATDate.Text & "',TOEFLDATE = '" & Me.txtTOEFLDate.Text & "',GREDATE = '" & Me.txtTSEDate.Text & "',GMAT = '" & Me.txtGMATTotal.Text & "',TOEFL = '" & Me.txtTOEFLTotal.Text & "',GRE = '" & Me.txtTSETotal.Text & "',APPLICFORM = '" & Me.chkAppForm.Checked & "',APPLICFEE = '" & Me.chkAppFeePaid.Checked & "',RESUME = '" & Me.chkResume.Checked & "',LORS = '" & Me.chkLOR.Checked & "',TRANSCRIPTS = '" & Me.chkTranscript.Checked & "',ESSAYQ = '" & Me.chkEssay.Checked & "',GMATGRE = '" & Me.chkGMATScore.Checked & "',EDUEXP = '" & Me.chkEducation.Checked & "',SUPPFINNFORM = '" & Me.chkFinancial.Checked & "',TOEFLINCLU = '" & Me.chkTOEFL.Checked & "' WHERE SSN =  " & ssn & " ;", con)
            'command.Parameters.AddWithValue("NAME", TE_NAME)
            'MessageBox.Show(command.CommandText.ToString())
            'Opens connection to the database
            con.ConnectionString = ConnString
            con.Open()
            'Execute the Insert Statement in the command variable
            RowsInsertedInteger = command.ExecuteNonQuery()
            'Close the connection
            con.Close()
        Catch ex As Exception
            'This is what happens if there is an error
            MessageBox.Show("Error in saving information to the database: " & ex.Message)
            con.Close()
        Finally
            'If all else fails, this will run
            'Close DB Connection here
            con.Close()
        End Try
    End Sub

    Private Sub UpdateButton_Click(sender As Object, e As EventArgs) Handles UpdateButton.Click
        PostToDB_UpdateStudent()

    End Sub
    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        'Format style of the generated report
        Dim HeadingFont As New Font("Arial", 14)
        Dim PrintFont As New Font("Arial", 12)
        Dim LineHeightSingle As Single = PrintFont.GetHeight + 2
        Dim HorizontalPrintLocationSingle As Single = e.MarginBounds.Left
        Dim VerticalPrintLocationSingle As Single = e.MarginBounds.Top
        e.Graphics.DrawString("Admissions Report", HeadingFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle * 2
        e.Graphics.DrawString("Total Applicants: " & totalAppl, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle * 2
        e.Graphics.DrawString("Total Admitted: " & totalAdmis, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle * 2
        e.Graphics.DrawString("Reside In Arkansas: " & totalArRe, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle
        e.Graphics.DrawString("Average GPA of Applicants: " & avgGPA, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle
        e.Graphics.DrawString("Average GMAT of Applicants: " & avgGMAT, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle
        e.Graphics.DrawString("Average TOEFL of Applicants: " & avgTOEFL, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle
        e.Graphics.DrawString("Average GRE of Applicants: " & avgGRE, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle * 2
        e.Graphics.DrawString("Applicant Diversity", PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle * 2
        e.Graphics.DrawString("Alaskan Native or American Indian: " & totalIndian, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle
        e.Graphics.DrawString("Black, Non-Hispanic: " & totalBlack, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle
        e.Graphics.DrawString("Asian or Pacific Islander: " & totalAsian, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle
        e.Graphics.DrawString("Hispanic: " & totalHispanic, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle
        e.Graphics.DrawString("White, Non-Hispanic: " & totalWhite, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle

    End Sub

    '++++++++++++++++++++++++++++++++++++++All working SQL code from SQL Server for the print feature++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    'Select COUNT(SSN) As Total_Applicants from gradstudents 

    'Select COUNT(SSN) As Addmitted_Applicants from gradstudents where Admitted='0'
    'Select AVG(GMAT) As AVG_Applicant_GMAT from gradstudents

    'Select AVG(TOEFL) As AVG_Applicant_GMAT from gradstudents
    'Select AVG(GRE) As AVG_Applicant_GMAT from gradstudents

    'Select AVG(COLLEGE1GPA) As AVG_Applicant_GPA from gradstudents

    'Select COUNT(arresident) As AR_Residents from GRADSTUDENTS where arresident='TRUE'

    'Select COUNT(Race) from gradstudents Where race='Alaskan Native or American Indian'

    'Select COUNT(Race) from gradstudents Where race='Black, Non-Hispanic'

    'Select COUNT(Race) from gradstudents Where race='Asian or Pacific Islander'

    'Select COUNT(Race) from gradstudents Where race='Hispanic'

    'Select COUNT(Race) from gradstudents Where race='White, Non-Hispanic'

    Private Sub PrintSQL()
        'Loads data from database to get calculated fields for Academic metrics
        Try
            Dim command As New OleDbCommand("SELECT COUNT(SSN), AVG(COLLEGE1GPA +COLLEGE2GPA)/2, AVG(GMAT),AVG(TOEFL),AVG(GRE)  FROM GRADSTUDENTS ;", con)
            Dim dr As OleDbDataReader
            con.ConnectionString = ConnString
            con.Open()
            dr = command.ExecuteReader()
            While dr.Read()
                'ListBox2.Items.Add(Trim(dr.GetString(0) & " " & dr.GetString(1) & " " & dr.GetString(2)))
                totalAppl = dr.GetInt32(0)
                avgGPA = dr.GetValue(1)
                avgGMAT = dr.GetValue(2)
                avgTOEFL = dr.GetValue(3)
                avgGRE = dr.GetValue(4)
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error in retrieving producer list from database" & ex.Message, "Database Error")
            con.Close()
        End Try
    End Sub
    Private Sub PrintSQL1()
        'Loads data from database to get calculated field for Total Admitted applicants
        Try
            Dim command As New OleDbCommand("SELECT COUNT(SSN) FROM GRADSTUDENTS WHERE ADMITTED= '1' ;", con)
            Dim dr As OleDbDataReader
            con.ConnectionString = ConnString
            con.Open()
            dr = command.ExecuteReader()
            While dr.Read()
                totalAdmis = dr.GetInt32(0)
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error in retrieving producer list from database" & ex.Message, "Database Error")
            con.Close()
        End Try
    End Sub
    Private Sub PrintSQL2()
        'Loads data from database to get calculated field for Arkansas Residents
        Try
            Dim command As New OleDbCommand("SELECT COUNT(ARRESIDENT) FROM GRADSTUDENTS where arresident='TRUE' ;", con)
            Dim dr As OleDbDataReader
            con.ConnectionString = ConnString
            con.Open()
            dr = command.ExecuteReader()
            While dr.Read()
                'ListBox2.Items.Add(Trim(dr.GetString(0) & " " & dr.GetString(1) & " " & dr.GetString(2)))
                totalArRe = dr.GetInt32(0)
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error in retrieving producer list from database" & ex.Message, "Database Error")
            con.Close()
        End Try
    End Sub
    Private Sub PrintSQL3()
        'Loads data from database to get calculated fields for diversity
        Try
            Dim command As New OleDbCommand("SELECT COUNT(Race) from gradstudents Where race='Alaskan Native or American Indian' ;", con)
            Dim dr As OleDbDataReader
            con.ConnectionString = ConnString
            con.Open()
            dr = command.ExecuteReader()
            While dr.Read()
                totalIndian = dr.GetInt32(0)
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error in retrieving producer list from database" & ex.Message, "Database Error")
            con.Close()
        End Try
    End Sub
    Private Sub PrintSQL4()
        'Loads data from database to get calculated fields for diversity
        Try
            Dim command As New OleDbCommand("SELECT COUNT(Race) from gradstudents Where race='Black, Non-Hispanic' ;", con)
            Dim dr As OleDbDataReader
            con.ConnectionString = ConnString
            con.Open()
            dr = command.ExecuteReader()

            While dr.Read()
                totalBlack = dr.GetInt32(0)
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error in retrieving producer list from database" & ex.Message, "Database Error")
            con.Close()
        End Try
    End Sub
    Private Sub PrintSQL5()
        'Loads data from database to get calculated fields for diversity
        Try
            Dim command As New OleDbCommand("SELECT COUNT(Race) from gradstudents Where race='Asian or Pacific Islander' ;", con)
            Dim dr As OleDbDataReader
            con.ConnectionString = ConnString
            con.Open()
            dr = command.ExecuteReader()
            While dr.Read()
                totalAsian = dr.GetInt32(0)
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error in retrieving producer list from database" & ex.Message, "Database Error")
            con.Close()
        End Try
    End Sub
    Private Sub PrintSQL6()
        'Loads data from database to get calculated fields for diversity
        Try
            Dim command As New OleDbCommand("SELECT COUNT(Race) from gradstudents Where race='Hispanic' ;", con)
            Dim dr As OleDbDataReader
            con.ConnectionString = ConnString
            con.Open()
            dr = command.ExecuteReader()
            While dr.Read()
                totalHispanic = dr.GetInt32(0)
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error in retrieving producer list from database" & ex.Message, "Database Error")
            con.Close()
        End Try
    End Sub
    Private Sub PrintSQL7()
        'Loads data from database to get calculated fields for diversity
        Try
            Dim command As New OleDbCommand("SELECT COUNT(Race) from gradstudents Where race='White, Non-Hispanic' ;", con)
            Dim dr As OleDbDataReader
            con.ConnectionString = ConnString
            con.Open()
            dr = command.ExecuteReader()
            While dr.Read()
                totalWhite = dr.GetInt32(0)
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error in retrieving producer list from database" & ex.Message, "Database Error")
            con.Close()
        End Try
    End Sub

    Private Sub ReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ReportToolStripMenuItem.Click
        'Loads data from below procedures to generate a report
        PrintSQL()
        PrintSQL1()
        PrintSQL2()
        PrintSQL2()
        PrintSQL3()
        PrintSQL4()
        PrintSQL5()
        PrintSQL6()
        PrintSQL7()
        PrintPreviewDialog1.Document = PrintDocument1
        PrintPreviewDialog1.ShowDialog()
        PrintSQL()
    End Sub

    Private Sub Advisors_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class