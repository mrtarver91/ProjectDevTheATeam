﻿
Imports System.Data.OleDb

Public Class Advisors
    'Declares variables for application

    Dim RowsInsertedInteger = 0

    'Declares variables for application
    Dim ssn As String = ""
    Dim ssnsearch As String = ""
    Dim LastName As String = ""
    Dim selectedStudent As String = ""
    Dim totalAppl As String = ""
    Dim avgGPA As String = ""
    Dim avgGMAT As String = ""
    Dim avgTOEFL As String = ""
    Dim avgGRE As String = ""
    Dim totalAdmis As String = ""
    Dim totalArRe As String = ""
    Dim totalBlack As String = ""
    Dim totalWhite As String = ""
    Dim totalAsian As String = ""
    Dim totalIndian As String = ""
    Dim totalHispanic As String = ""

    'Connection variables for the database
    Dim con As New OleDbConnection()

    'This goes to the connection class file and gets the connection string with username/password
    Dim ConnInfo As DBConnectionInfo = New DBConnectionInfo
    Dim ConnString As String = ConnInfo.GetConnString()

    'These are variables for the datagrid view

    Dim oledbAdapter As OleDbDataAdapter
    Dim sqlstring As String

    Private Sub PostToDB_Course()
        'This is where you would put all code to be executed
        Try

            Dim zero As String = "0"
            'Create a SQL command to insert the new student information
            Dim command As New OleDbCommand("INSERT INTO GRADSTUDENTS (SSN,LASTNAME, MIDDLENAME, FIRSTNAME,DOB, BIRTHPLACE, RACE, GENDER, CITIZENSHIP, PERMADDRESS, PERMCITY, PERMZIPCODE,PERMSTATE, YEARSATPERM,MAILADDRESS,MAILCITY, MAILSTATE,MAILZIPCODE, FORMERADDRESS, FORMERCITY, FORMERSTATE,FORMERZIPCODE,YEARSATFORMER,ARRESIDENT,HOMEPHONE,CELLPHONE,EMAIL,HISORLATIN, ADMITREQYEAR,ADMITREQTERM,ADMITREQPROGRAM,APPLIEDWHEN,PREVENROLL,APPLIEDBEFORE,PREVENROLLWHEN,PREVENROLLLEVEL,COLLEGE1,COLLEGE2,COLLEGE1HOURS,COLLEGE2HOURS,COLLEGE1GPA,COLLEGE2GPA,COLLEGE1GRADUATED,COLLEGE2GRADUATED,COLLEGE1DEGREE,COLLEGE2DEGREE,COLLEGE1DATET,COLLEGE1DATEF,COLLEGE2DATET,COLLEGE2DATEF,GMATDATE,TOEFLDATE,GREDATE,GMAT,TOEFL,GRE,APPLICFORM,APPLICFEE,RESUME,LORS,TRANSCRIPTS,ESSAYQ,GMATGRE,EDUEXP,SUPPFINNFORM,TOEFLINCLU,ADMITTED) VALUES (" & txtSSN.Text & ",'" & Me.txtLastName.Text & "','" & Me.txtMiddleName.Text & "','" & Me.txtFirstName.Text & "','" & Me.txtBirthday1.Text & "','" & Me.cbxOrigin.Text & "','" & Me.cbxEthnic.Text & "','" & Me.cbxGender.Text & "','" & Me.cbxCitizenship.Text & "','" & Me.txtPAddress.Text & "','" & Me.txtPCity.Text & "','" & Me.txtPZipCode.Text & "','" & Me.cbxPState.Text & "','" & Me.txtPYears.Text & "','" & Me.txtLAddress.Text & "','" & Me.txtLCity.Text & "','" & Me.cbxLState.Text & "','" & Me.txtLZipCode.Text & "','" & Me.txtFAddress.Text & "','" & Me.txtFCity.Text & "','" & Me.cbxFState.Text & "','" & Me.txtFZipCode.Text & "','" & Me.txtFYears.Text & "','" & Me.chkResident.Checked.ToString & "','" & Me.txtCurrentPhone.Text & "','" & Me.txtWorkPhone.Text & "','" & Me.txtEmail.Text & "','" & Me.chbxHisorLatin.Checked.ToString & "' ,'" & Me.txtRequestYear.Text & "','" & Me.cbxSession.Text & "','" & Me.cbxReqProgram.Text & "','" & Me.txtBefore_when.Text & "','" & Me.chkEnrolled.Checked.ToString & "' ,'" & Me.chkBefore.Checked.ToString & "' ,'" & Me.txtEnrolled_When.Text & "','" & Me.cbxStanding.Text & "','" & Me.txtCName1.Text & "','" & Me.txtCName2.Text & "','" & Me.txtHoursEarned1.Text & "','" & Me.txtHoursEarned2.Text & "','" & Me.txtCGPA1.Text & "','" & Me.txtCGPA2.Text & "','" & Me.ckbGraduated1.Checked.ToString & "' ,'" & Me.ckbGraduated2.Checked.ToString & "','" & Me.txtDegree1.Text & "' ,'" & Me.txtDegree2.Text & "' ,'" & Me.txtCTo1.Text & "','" & Me.txtCFrom1.Text & "','" & Me.txtCTo2.Text & "','" & Me.txtCFrom2.Text & "','" & Me.txtGMATDate.Text & "','" & Me.txtTOEFLDate.Text & "','" & Me.txtTSEDate.Text & "' ,'" & Me.txtGMATTotal.Text & "','" & Me.txtTOEFLTotal.Text & "','" & Me.txtTSETotal.Text & "' ,'" & Me.chkAppForm.Checked & "','" & Me.chkAppFeePaid.Checked & "','" & Me.chkResume.Checked & "','" & Me.chkLOR.Checked & "','" & Me.chkTranscript.Checked & "','" & Me.chkEssay.Checked & "','" & Me.chkGMATScore.Checked & "','" & Me.chkEducation.Checked & "','" & Me.chkFinancial.Checked & "','" & Me.chkTOEFL.Checked & "', '" & zero & "');", con)
            MessageBox.Show(command.CommandText.ToString())

            'Another method of inserting fields into the database
            'Dim command As New OleDbCommand("INSERT INTO COURSE (NA ME,CLSTIME,ROOM,TID)" & "VALUES(?, ?, ?, ?)", con)
            'command.Parameters.AddWithValue("NAME", NAME1)
            'command.Parameters.AddWithValue("CLSTIME", CLSTIME)
            'command.Parameters.AddWithValue("ROOM", ROOM)
            'command.Parameters.AddWithValue("TID", TID)



            'Insert a new record into the database table
            'Opens connection to the database
            con.ConnectionString = ConnString
            con.Open()

            'Execute the Insert Statement in the command variable
            RowsInsertedInteger = command.ExecuteNonQuery()

            'Close the connection
            con.Close()

        Catch ex As Exception
            'This is what happens if there is an error
            MessageBox.Show("Error in saving information to the database: " & ex.Message)
            con.Close()
        Finally
            'If all else fails, this will run
            'Close DB Connection here
            con.Close()
        End Try
    End Sub


    Private Sub ClearFields()
        'Student Personal

        'Me.txtStudentID.Clear()
        Me.txtLastName.Clear()
        Me.txtFirstName.Clear()
        Me.txtMiddleName.Clear()
        Me.txtSSN.Clear()
        Me.txtBirthday1.Clear()
        Me.cbxOrigin.ResetText()
        Me.cbxEthnic.ResetText()
        Me.cbxGender.ResetText()
        Me.cbxCitizenship.ResetText()
        Me.chbxHisorLatin.Checked = False


        'Student Address 
        Me.txtPAddress.Clear()
        Me.txtPCity.Clear()
        Me.cbxPState.ResetText()
        Me.txtPZipCode.Clear()
        Me.txtFAddress.Clear()
        Me.txtFCity.Clear()
        Me.cbxFState.ResetText()
        Me.txtFZipCode.Clear()
        Me.chkResident.Checked = False
        Me.txtLAddress.Clear()
        Me.txtLCity.Clear()
        Me.cbxLState.ResetText()
        Me.txtLZipCode.Clear()
        Me.txtPYears.Clear()
        Me.txtFYears.Clear()

        'Student Phone 
        Me.txtCurrentPhone.Clear()
        Me.txtWorkPhone.Clear()

        'Student Email 
        Me.txtEmail.Clear()

        'Student Test Score 
        Me.txtGMATDate.Clear()
        Me.txtGMATTotal.Clear()
        Me.txtTOEFLDate.Clear()
        Me.txtTOEFLTotal.Clear()
        Me.txtTSEDate.Clear()
        Me.txtTSETotal.Clear()

        'Student Academic Transcript
        Me.txtCName1.Clear()
        Me.txtCTo1.Clear()
        Me.txtCFrom1.Clear()
        Me.txtHoursEarned1.Clear()
        Me.txtDegree1.Clear()
        Me.ckbGraduated1.Checked = False
        Me.ckbGraduated2.Checked = False
        Me.txtCGPA1.Clear()
        Me.txtCGPA2.Clear()
        Me.txtCName2.Clear()
        Me.txtCTo2.Clear()
        Me.txtCFrom2.Clear()
        Me.txtHoursEarned2.Clear()
        Me.txtDegree2.Clear()
        Me.cbxConcen.ResetText()

        'Student Admission State
        Me.txtRequestYear.Clear()
        Me.cbxSession.ResetText()
        Me.chkBefore.Checked = False
        Me.txtBefore_when.Clear()
        Me.chkEnrolled.Checked = False
        Me.txtEnrolled_When.Clear()
        Me.cbxStanding.ResetText()
        Me.cbxReqProgram.ResetText()
        Me.chkAppFeePaid.Checked = False
        Me.chkResume.Checked = False
        Me.chkEssay.Checked = False
        Me.chkAppForm.Checked = False
        Me.chkLOR.Checked = False
        Me.chkTranscript.Checked = False
        Me.chkEducation.Checked = False
        Me.chkFinancial.Checked = False
        Me.chkTOEFL.Checked = False
        Me.chkGMATScore.Checked = False

    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()

    End Sub

    Private Sub InsertButton_Click(sender As Object, e As EventArgs) Handles InsertButton.Click
        PostToDB_Course()
        'ClearFields()
    End Sub

    Private Sub ClearFieldsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClearFieldsToolStripMenuItem.Click
        ClearFields()
    End Sub

    Private Sub SearchButton_Click(sender As Object, e As EventArgs) Handles SearchButton.Click
        Try

            Dim ds As New DataSet
            ssn = txtSSN.Text
            LastName = txtLastName.Text
            'selectedInstructor = ""
            'This example will load the DataGridView
            'Dim sql As String = "SELECT NAME FROM INSTRUCTOR;"
            Dim sql As String = "SELECT SSN, LASTNAME From GRADSTUDENTS WHERE (SSN ='" & ssn & "'  OR LASTNAME ='" & LastName & "' );"
            '"SELECT NAME,TID from INSTRUCTOR WHERE NAME ='" & selectedInstructor & "' ;"
            con.ConnectionString = ConnString
            con.Open()
            oledbAdapter = New OleDbDataAdapter(sql, con)
            oledbAdapter.Fill(ds)
            DataGridView1.DataSource = ds.Tables(0)
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error in retrieving instructor list from database" & ex.Message, "Database Error")
            con.Close()
        End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick


        Try
            selectedStudent = DataGridView1.CurrentCell.FormattedValue
            Dim command As New OleDbCommand("SELECT SSN,LASTNAME, MIDDLENAME,FIRSTNAME,DOB,BIRTHPLACE, RACE, GENDER, CITIZENSHIP, PERMADDRESS, PERMCITY, PERMZIPCODE,PERMSTATE, YEARSATPERM,MAILADDRESS,MAILCITY, MAILSTATE,MAILZIPCODE, FORMERADDRESS, FORMERCITY, FORMERSTATE,FORMERZIPCODE,YEARSATFORMER,ARRESIDENT,HOMEPHONE, CELLPHONE,EMAIL,HISORLATIN, ADMITREQYEAR,ADMITREQTERM,ADMITREQPROGRAM,APPLIEDWHEN,APPLIEDBEFORE,PREVENROLL,PREVENROLLLEVEL,COLLEGE1, COLLEGE2,COLLEGE1HOURS, COLLEGE2HOURS,COLLEGE1GPA, COLLEGE2GPA,COLLEGE1GRADUATED, COLLEGE2GRADUATED,COLLEGE1DEGREE, COLLEGE2DEGREE, GMAT, TOEFL, GRE, APPLICFORM, APPLICFEE,RESUME, LORS, TRANSCRIPTS, ESSAYQ, GMATGRE, EDUEXP, SUPPFINNFORM, TOEFLINCLU FROM GRADSTUDENTS WHERE LASTNAME = '" & selectedStudent & "' ;", con)

            Dim dr As OleDbDataReader

            con.ConnectionString = ConnString
            con.Open()





            dr = command.ExecuteReader()

            While dr.Read()
                'ListBox2.Items.Add(Trim(dr.GetString(0) & " " & dr.GetString(1) & " " & dr.GetString(2)))
                txtSSN.Text = dr.GetString(0)
                txtLastName.Text = dr.GetString(1)
                txtMiddleName.Text = dr.GetString(2)
                txtFirstName.Text = dr.GetString(3)
                txtBirthday1.Text = dr.ToString(4)
                cbxOrigin.Text = dr.GetString(5)
                cbxEthnic.Text = dr.GetString(6)
                cbxGender.Text = dr.GetString(7)
                cbxCitizenship.Text = dr.GetString(8)
                txtPAddress.Text = dr.GetString(9)
                txtPCity.Text = dr.GetString(10)
                txtPZipCode.Text = dr.GetString(11)
                cbxPState.Text = dr.GetString(12)
                txtPYears.Text = dr.GetInt32(13)
                txtLAddress.Text = dr.GetString(14)
                txtLCity.Text = dr.GetString(15)
                cbxLState.Text = dr.GetString(16)
                txtLZipCode.Text = dr.GetString(17)
                txtFAddress.Text = dr.GetString(18)
                txtFCity.Text = dr.GetString(19)
                cbxFState.Text = dr.GetString(20)
                txtFZipCode.Text = dr.GetString(21)
                txtFYears.Text = dr.GetInt32(22)
                chkResident.Checked = dr.GetBoolean(23)
                txtCurrentPhone.Text = dr.GetString(24)
                txtWorkPhone.Text = dr.GetString(25)
                txtEmail.Text = dr.GetString(26)
                chbxHisorLatin.Checked = dr.GetBoolean(27)
                txtRequestYear.Text = dr.GetString(28)
                cbxSession.Text = dr.GetString(29)
                cbxReqProgram.Text = dr.GetString(30)
                txtBefore_when.Text = dr.ToString(31)
                chkBefore.Checked = dr.GetBoolean(32)
                chkEnrolled.Checked = dr.GetBoolean(33)
                cbxStanding.Text = dr.GetString(34)
                txtCName1.Text = dr.GetString(35)
                txtCName2.Text = dr.GetString(36)
                txtHoursEarned1.Text = dr.GetValue(37)
                txtHoursEarned2.Text = dr.GetValue(38)
                txtCGPA1.Text = dr.GetValue(39)
                txtCGPA2.Text = dr.GetValue(40)
                ckbGraduated1.Checked = dr.GetBoolean(41)
                ckbGraduated2.Checked = dr.GetBoolean(42)
                txtDegree1.Text = dr.GetString(43)
                txtDegree2.Text = dr.GetString(44)
                txtGMATTotal.Text = dr.GetInt32(45)
                txtTOEFLTotal.Text = dr.GetInt32(46)
                txtTSETotal.Text = dr.GetInt32(47)
                chkAppForm.Checked = dr.GetBoolean(48)
                chkAppFeePaid.Checked = dr.GetBoolean(49)
                chkResume.Checked = dr.GetBoolean(50)
                chkLOR.Checked = dr.GetBoolean(51)
                chkTranscript.Checked = dr.GetBoolean(52)
                chkEssay.Checked = dr.GetBoolean(53)
                chkGMATScore.Checked = dr.GetBoolean(54)
                chkEducation.Checked = dr.GetBoolean(55)
                chkFinancial.Checked = dr.GetBoolean(56)
                chkTOEFL.Checked = dr.GetBoolean(57)



                '***Need to find correct datatype .drGet????? for date fields

                'txtEnrolled_When.Text = dr.ToString(34)
                'txtCTo1.Text = dr.GetString(46)
                'txtCFrom1.Text = dr.GetString(47)
                'txtCTo2.Text = dr.GetString(48)
                'txtCFrom2.Text = dr.GetString(49)
                'txtGMATDate.Text = dr.GetString(50)
                'txtTOEFLDate.Text = dr.GetString(51)
                'txtTSEDate.Text = dr.GetString(52)




            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error in retrieving producer list from database" & ex.Message, "Database Error")
            con.Close()
        End Try
    End Sub

    Private Sub DeleteButton_Click(sender As Object, e As EventArgs) Handles DeleteButton.Click
        Try

            Dim ds As New DataSet
            ssn = txtSSN.Text

            'selectedInstructor = ""
            'This example will load the DataGridView
            'Dim sql As String = "SELECT NAME FROM INSTRUCTOR;"
            Dim sql As String = "DELETE  FROM GRADSTUDENTS WHERE SSN ='" & ssn & "';"

            'Insert a new record into the database table
            'Opens connection to the database
            con.ConnectionString = ConnString
            con.Open()

            'Execute the Insert Statement in the command variable


            'Close the connection
            con.Close()

        Catch ex As Exception
            'This is what happens if there is an error
            MessageBox.Show("Error in saving information to the database: " & ex.Message)
            con.Close()
        Finally
            'If all else fails, this will run
            'Close DB Connection here
            con.Close()
        End Try
    End Sub
    'Private Sub SearchSSNAdmit()
    '    Try

    '        Dim ds As New DataSet
    '        ssnsearch = txtSSN.Text

    '        'selectedInstructor = ""
    '        'This example will load the DataGridView
    '        'Dim sql As String = "SELECT NAME FROM INSTRUCTOR;"
    '        Dim sql As String = "SELECT SSN From GRADSTUDENTS WHERE SSN ='" & ssn & "' ;"
    '        '"SELECT NAME,TID from INSTRUCTOR WHERE NAME ='" & selectedInstructor & "' ;"
    '        con.ConnectionString = ConnString
    '        con.Open()
    '        oledbAdapter = New OleDbDataAdapter(sql, con)
    '        oledbAdapter.Fill(ds)
    '        DataGridView1.DataSource = ds.Tables(0)
    '        con.Close()
    '    Catch ex As Exception
    '        MessageBox.Show("Error in retrieving instructor list from database" & ex.Message, "Database Error")
    '        con.Close()
    '    End Try
    'End Sub
    Private Sub UpdateSTIDAdmit()

        Try
            'selectedInstructor = ""
            'This example will load the DataGridView
            'Dim sql As String = "SELECT NAME FROM INSTRUCTOR;"
            Dim command As New OleDbCommand("UPDATE GRADSTUDENTS SET STUDENTID = '" & Me.txtStudentID.Text & "' WHERE SSN =  '" & Me.TxtSSNSearch.Text & "' ;", con)
            '"SELECT NAME,TID from INSTRUCTOR WHERE NAME ='" & selectedInstructor & "' ;"
            con.ConnectionString = ConnString
        con.Open()

            'Execute the Insert Statement in the command variable
            'RowsInsertedInteger = command.ExecuteNonQuery()

            'Close the connection
            con.Close()

        Catch ex As Exception
        'This is what happens if there is an error
        MessageBox.Show("Error in saving information to the database: " & ex.Message)
        con.Close()
        Finally
        'If all else fails, this will run
        'Close DB Connection here
        con.Close()
        End Try




    End Sub
    Private Sub UpdateAdmitStatus()
        Try


            ssnsearch = txtSSN.Text

            'selectedInstructor = ""
            'This example will load the DataGridView
            'Dim sql As String = "SELECT NAME FROM INSTRUCTOR;"
            Dim command As New OleDbCommand("UPDATE GRADSTUDENTS SET ADMITTED= '" & Me.CheckBox_admit.Checked & "' WHERE SSN =  '" & Me.TxtSSNSearch.Text & "' ;", con)
            '"SELECT NAME,TID from INSTRUCTOR WHERE NAME ='" & selectedInstructor & "' ;"
            con.ConnectionString = ConnString
            con.Open()

            'Execute the Insert Statement in the command variable
            'RowsInsertedInteger = command.ExecuteNonQuery()

            'Close the connection
            con.Close()

        Catch ex As Exception
            'This is what happens if there is an error
            MessageBox.Show("Error in saving information to the database: " & ex.Message)
            con.Close()
        Finally
            'If all else fails, this will run
            'Close DB Connection here
            con.Close()
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        UpdateAdmitStatus()
        UpdateSTIDAdmit()
    End Sub

    Private Sub PostToDB_UpdateStudent()
        'This is where you would put all code to be executed
        Try
            'Create a SQL command to insert the new student information
            'Dim command As New OleDbCommand("INSERT INTO Student (FirstName, LastName, Major, Gender) VALUES ('" & firstname & "','" & lastname & "','" & major & "','" & gender & "');", con)
            'MessageBox.Show(command.CommandText.ToString())
            ssn = txtSSN.Text
            'Another method of inserting fields into the database
            Dim command As New OleDbCommand("UPDATE GRADSTUDENTS SET LASTNAME = '" & Me.txtLastName.Text & "', MIDDLENAME = '" & Me.txtMiddleName.Text & "', FIRSTNAME = '" & Me.txtFirstName.Text & "',DOB = '" & Me.txtBirthday1.Text & "', BIRTHPLACE = '" & Me.cbxOrigin.Text & "', RACE = '" & Me.cbxEthnic.Text & "', GENDER = '" & Me.cbxGender.Text & "', CITIZENSHIP = '" & Me.cbxCitizenship.Text & "', PERMADDRESS = '" & Me.txtPAddress.Text & "', PERMCITY = '" & Me.txtPCity.Text & "', PERMZIPCODE = '" & Me.txtPZipCode.Text & "',PERMSTATE = '" & Me.cbxPState.Text & "', YEARSATPERM = '" & Me.txtPYears.Text & "',MAILADDRESS = '" & Me.txtLAddress.Text & "',MAILCITY = '" & Me.txtLCity.Text & "', MAILSTATE = '" & Me.cbxLState.Text & "',MAILZIPCODE = '" & Me.txtLZipCode.Text & "', FORMERADDRESS = '" & Me.txtFAddress.Text & "', FORMERCITY = '" & Me.txtFCity.Text & "', FORMERSTATE = '" & Me.cbxFState.Text & "',FORMERZIPCODE = '" & Me.txtFZipCode.Text & "',YEARSATFORMER = '" & Me.txtFYears.Text & "',ARRESIDENT = '" & Me.chkResident.Checked & "',HOMEPHONE = '" & Me.txtCurrentPhone.Text & "',CELLPHONE = '" & Me.txtWorkPhone.Text & "',EMAIL = '" & Me.txtEmail.Text & "',HISORLATIN = '" & Me.chbxHisorLatin.Text & "', ADMITREQYEAR = '" & Me.txtRequestYear.Text & "',ADMITREQTERM = '" & Me.cbxSession.Text & "',ADMITREQPROGRAM = '" & Me.cbxReqProgram.Text & "',APPLIEDWHEN = '" & Me.txtBefore_when.Text & "',PREVENROLL = '" & Me.chkBefore.Checked & "',APPLIEDBEFORE = '" & Me.chkEnrolled.Checked & "',PREVENROLLWHEN = '" & Me.txtEnrolled_When.Text & "',PREVENROLLLEVEL = '" & Me.cbxStanding.Text & "',COLLEGE1 = '" & Me.txtCName1.Text & "',COLLEGE2 = '" & Me.txtCName2.Text & "',COLLEGE1HOURS = '" & Me.txtHoursEarned1.Text & "',COLLEGE2HOURS = '" & Me.txtHoursEarned2.Text & "',COLLEGE1GPA = '" & Me.txtCGPA1.Text & "',COLLEGE2GPA = '" & Me.txtCGPA1.Text & "',COLLEGE1GRADUATED = '" & Me.ckbGraduated1.Checked & "',COLLEGE2GRADUATED = '" & Me.ckbGraduated2.Checked & "',COLLEGE1DEGREE = '" & Me.txtDegree1.Text & "',COLLEGE2DEGREE = '" & Me.txtDegree2.Text & "',COLLEGE1DATET = '" & Me.txtCTo1.Text & "',COLLEGE1DATEF = '" & Me.txtCFrom1.Text & "',COLLEGE2DATET = '" & Me.txtCTo2.Text & "',COLLEGE2DATEF = '" & Me.txtCFrom2.Text & "',GMATDATE = '" & Me.txtGMATDate.Text & "',TOEFLDATE = '" & Me.txtTOEFLDate.Text & "',GREDATE = '" & Me.txtTSEDate.Text & "',GMAT = '" & Me.txtGMATTotal.Text & "',TOEFL = '" & Me.txtTOEFLTotal.Text & "',GRE = '" & Me.txtTSETotal.Text & "',APPLICFORM = '" & Me.chkAppForm.Checked & "',APPLICFEE = '" & Me.chkAppFeePaid.Checked & "',RESUME = '" & Me.chkResume.Checked & "',LORS = '" & Me.chkLOR.Checked & "',TRANSCRIPTS = '" & Me.chkTranscript.Checked & "',ESSAYQ = '" & Me.chkEssay.Checked & "',GMATGRE = '" & Me.chkGMATScore.Checked & "',EDUEXP = '" & Me.chkEducation.Checked & "',SUPPFINNFORM = '" & Me.chkFinancial.Checked & "',TOEFLINCLU = '" & Me.chkTOEFL.Checked & "' WHERE SSN =  " & ssn & " ;", con)
            'command.Parameters.AddWithValue("NAME", TE_NAME)
            MessageBox.Show(command.CommandText.ToString())


            'Insert a new record into the database table
            'Opens connection to the database
            con.ConnectionString = ConnString
            con.Open()

            'Execute the Insert Statement in the command variable


            'Close the connection
            con.Close()

        Catch ex As Exception
            'This is what happens if there is an error
            MessageBox.Show("Error in saving inofrmation to the database: " & ex.Message)
            con.Close()
        Finally
            'If all else fails, this will run
            'Close DB Connection here
            con.Close()
        End Try
    End Sub

    Private Sub UpdateButton_Click(sender As Object, e As EventArgs) Handles UpdateButton.Click
        PostToDB_UpdateStudent()
    End Sub
    'All working SQL code from SQL Server for the print feature

    'Select COUNT(SSN) As Total_Applicants from gradstudents 

    'Select COUNT(SSN) As Addmitted_Applicants from gradstudents where Admitted='0'
    'Select AVG(GMAT) As AVG_Applicant_GMAT from gradstudents

    'Select AVG(TOEFL) As AVG_Applicant_GMAT from gradstudents
    'Select AVG(GRE) As AVG_Applicant_GMAT from gradstudents

    'Select AVG(COLLEGE1GPA) As AVG_Applicant_GPA from gradstudents

    'Select COUNT(arresident) As AR_Residents from GRADSTUDENTS where arresident='TRUE'

    'Select COUNT(Race) from gradstudents Where race='Alaskan Native or American Indian'

    'Select COUNT(Race) from gradstudents Where race='Black, Non-Hispanic'

    'Select COUNT(Race) from gradstudents Where race='Asian or Pacific Islander'

    'Select COUNT(Race) from gradstudents Where race='Hispanic'

    'Select COUNT(Race) from gradstudents Where race='White, Non-Hispanic'
    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage

        Dim HeadingFont As New Font("Arial", 14)
        Dim PrintFont As New Font("Arial", 12)
        Dim LineHeightSingle As Single = PrintFont.GetHeight + 2
        Dim HorizontalPrintLocationSingle As Single = e.MarginBounds.Left
        Dim VerticalPrintLocationSingle As Single = e.MarginBounds.Top



        ' TotalAmount = AmountTextBox.Text
        'OrderID = OrderIDTextBox.Text



        e.Graphics.DrawString("Admissions Report", HeadingFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle * 2


        e.Graphics.DrawString("Total Applicants: " & totalAppl, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle * 2

        e.Graphics.DrawString("Total Admitted: " & totalAdmis, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle * 2

        e.Graphics.DrawString("Reside In Arkansas: " & totalArRe, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle

        e.Graphics.DrawString("Average GPA of Applicants: " & avgGPA, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle

        e.Graphics.DrawString("Average GMAT of Applicants: " & avgGMAT, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle

        e.Graphics.DrawString("Average TOEFL of Applicants: " & avgTOEFL, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle

        e.Graphics.DrawString("Average GRE of Applicants: " & avgGRE, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle * 2


        e.Graphics.DrawString("Applicant Diversity", PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle * 2

        e.Graphics.DrawString("Alaskan Native or American Indian: " & totalIndian, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle
        e.Graphics.DrawString("Black, Non-Hispanic: " & totalBlack, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle
        e.Graphics.DrawString("Asian or Pacific Islander: " & totalAsian, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle
        e.Graphics.DrawString("Hispanic: " & totalHispanic, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle
        e.Graphics.DrawString("White, Non-Hispanic: " & totalWhite, PrintFont, Brushes.Black, HorizontalPrintLocationSingle, VerticalPrintLocationSingle)
        VerticalPrintLocationSingle += LineHeightSingle

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        PrintSQL()
        PrintSQL1()
        PrintSQL2()
        PrintSQL2()
        PrintSQL3()
        PrintSQL4()
        PrintSQL5()
        PrintSQL6()
        PrintSQL7()
        PrintPreviewDialog1.Document = PrintDocument1
        PrintPreviewDialog1.ShowDialog()
        PrintSQL()
    End Sub

    Private Sub PrintSQL()
        Try

            Dim command As New OleDbCommand("SELECT COUNT(SSN), AVG(COLLEGE1GPA +COLLEGE2GPA)/2, AVG(GMAT),AVG(TOEFL),AVG(GRE)  FROM GRADSTUDENTS ;", con)

            Dim dr As OleDbDataReader

            con.ConnectionString = ConnString
            con.Open()
            dr = command.ExecuteReader()

            While dr.Read()
                'ListBox2.Items.Add(Trim(dr.GetString(0) & " " & dr.GetString(1) & " " & dr.GetString(2)))
                totalAppl = dr.GetInt32(0)
                avgGPA = dr.GetValue(1)
                avgGMAT = dr.GetValue(2)
                avgTOEFL = dr.GetValue(3)
                avgGRE = dr.GetValue(4)
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error in retrieving producer list from database" & ex.Message, "Database Error")
            con.Close()
        End Try
    End Sub
    Private Sub PrintSQL1()


        Try

            Dim command As New OleDbCommand("SELECT COUNT(SSN) FROM GRADSTUDENTS WHERE ADMITTED= '1' ;", con)

            Dim dr As OleDbDataReader

            con.ConnectionString = ConnString
            con.Open()
            dr = command.ExecuteReader()

            While dr.Read()
                'ListBox2.Items.Add(Trim(dr.GetString(0) & " " & dr.GetString(1) & " " & dr.GetString(2)))
                totalAdmis = dr.GetInt32(0)
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error in retrieving producer list from database" & ex.Message, "Database Error")
            con.Close()
        End Try
    End Sub
    Private Sub PrintSQL2()


        Try

            Dim command As New OleDbCommand("SELECT COUNT(ARRESIDENT) FROM GRADSTUDENTS where arresident='TRUE' ;", con)

            Dim dr As OleDbDataReader

            con.ConnectionString = ConnString
            con.Open()
            dr = command.ExecuteReader()

            While dr.Read()
                'ListBox2.Items.Add(Trim(dr.GetString(0) & " " & dr.GetString(1) & " " & dr.GetString(2)))
                totalArRe = dr.GetInt32(0)
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error in retrieving producer list from database" & ex.Message, "Database Error")
            con.Close()
        End Try
    End Sub
    Private Sub PrintSQL3()


        Try

            Dim command As New OleDbCommand("SELECT COUNT(Race) from gradstudents Where race='Alaskan Native or American Indian' ;", con)

            Dim dr As OleDbDataReader

            con.ConnectionString = ConnString
            con.Open()
            dr = command.ExecuteReader()

            While dr.Read()
                'ListBox2.Items.Add(Trim(dr.GetString(0) & " " & dr.GetString(1) & " " & dr.GetString(2)))
                totalIndian = dr.GetInt32(0)
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error in retrieving producer list from database" & ex.Message, "Database Error")
            con.Close()
        End Try
    End Sub
    Private Sub PrintSQL4()


        Try

            Dim command As New OleDbCommand("SELECT COUNT(Race) from gradstudents Where race='Black, Non-Hispanic' ;", con)

            Dim dr As OleDbDataReader

            con.ConnectionString = ConnString
            con.Open()
            dr = command.ExecuteReader()

            While dr.Read()
                'ListBox2.Items.Add(Trim(dr.GetString(0) & " " & dr.GetString(1) & " " & dr.GetString(2)))
                totalBlack = dr.GetInt32(0)
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error in retrieving producer list from database" & ex.Message, "Database Error")
            con.Close()
        End Try
    End Sub
    Private Sub PrintSQL5()


        Try

            Dim command As New OleDbCommand("SELECT COUNT(Race) from gradstudents Where race='Asian or Pacific Islander' ;", con)

            Dim dr As OleDbDataReader

            con.ConnectionString = ConnString
            con.Open()
            dr = command.ExecuteReader()

            While dr.Read()
                'ListBox2.Items.Add(Trim(dr.GetString(0) & " " & dr.GetString(1) & " " & dr.GetString(2)))
                totalAsian = dr.GetInt32(0)
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error in retrieving producer list from database" & ex.Message, "Database Error")
            con.Close()
        End Try
    End Sub
    Private Sub PrintSQL6()


        Try

            Dim command As New OleDbCommand("SELECT COUNT(Race) from gradstudents Where race='Hispanic' ;", con)

            Dim dr As OleDbDataReader

            con.ConnectionString = ConnString
            con.Open()
            dr = command.ExecuteReader()

            While dr.Read()
                'ListBox2.Items.Add(Trim(dr.GetString(0) & " " & dr.GetString(1) & " " & dr.GetString(2)))
                totalHispanic = dr.GetInt32(0)
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error in retrieving producer list from database" & ex.Message, "Database Error")
            con.Close()
        End Try
    End Sub
    Private Sub PrintSQL7()


        Try

            Dim command As New OleDbCommand("SELECT COUNT(Race) from gradstudents Where race='White, Non-Hispanic' ;", con)

            Dim dr As OleDbDataReader

            con.ConnectionString = ConnString
            con.Open()
            dr = command.ExecuteReader()

            While dr.Read()
                'ListBox2.Items.Add(Trim(dr.GetString(0) & " " & dr.GetString(1) & " " & dr.GetString(2)))
                totalWhite = dr.GetInt32(0)
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error in retrieving producer list from database" & ex.Message, "Database Error")
            con.Close()
        End Try
    End Sub
End Class