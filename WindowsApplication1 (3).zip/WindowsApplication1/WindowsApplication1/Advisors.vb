﻿
Imports System.Data.OleDb

Public Class Advisors
    'Declares variables for application

    Dim RowsInsertedInteger = 0

    'Declares variables for application
    Dim ssn As String = ""
    Dim LastName As String = ""
    Dim selectedStudent As String = ""

    'Connection variables for the database
    Dim con As New OleDbConnection()

    'This goes to the connection class file and gets the connection string with username/password
    Dim ConnInfo As DBConnectionInfo = New DBConnectionInfo
    Dim ConnString As String = ConnInfo.GetConnString()

    'These are variables for the datagrid view

    Dim oledbAdapter As OleDbDataAdapter
    Dim sqlstring As String

    Private Sub PostToDB_Course()
        'This is where you would put all code to be executed
        Try
            'Create a SQL command to insert the new student information
            Dim command As New OleDbCommand("INSERT INTO GRADSTUDENTS (SSN,LASTNAME, MIDDLENAME, FIRSTNAME,DOB, BIRTHPLACE, RACE, GENDER, CITIZENSHIP, PERMADDRESS, PERMCITY, PERMZIPCODE,PERMSTATE, YEARSATPERM,MAILADDRESS,MAILCITY, MAILSTATE,MAILZIPCODE, FORMERADDRESS, FORMERCITY, FORMERSTATE,FORMERZIPCODE,YEARSATFORMER,ARRESIDENT,HOMEPHONE,CELLPHONE,EMAIL,HISORLATIN, ADMITREQYEAR,ADMITREQTERM,ADMITREQPROGRAM,APPLIEDWHEN,PREVENROLL,APPLIEDBEFORE,PREVENROLLWHEN,PREVENROLLLEVEL,COLLEGE1,COLLEGE2,COLLEGE1HOURS,COLLEGE2HOURS,COLLEGE1GPA,COLLEGE2GPA,COLLEGE1GRADUATED,COLLEGE2GRADUATED,COLLEGE1DEGREE,COLLEGE2DEGREE,COLLEGE1DATET,COLLEGE1DATEF,COLLEGE2DATET,COLLEGE2DATEF,GMATDATE,TOEFLDATE,GREDATE,GMAT,TOEFL,GRE,APPLICFORM,APPLICFEE,RESUME,LORS,TRANSCRIPTS,ESSAYQ,GMATGRE,EDUEXP,SUPPFINNFORM,TOEFLINCLU) VALUES (" & txtSSN.Text & ",'" & Me.txtLastName.Text & "','" & Me.txtMiddleName.Text & "','" & Me.txtFirstName.Text & "','" & Me.txtBirthday1.Text & "','" & Me.cbxOrigin.Text & "','" & Me.cbxEthnic.Text & "','" & Me.cbxGender.Text & "','" & Me.cbxCitizenship.Text & "','" & Me.txtPAddress.Text & "','" & Me.txtPCity.Text & "','" & Me.txtPZipCode.Text & "','" & Me.cbxPState.Text & "','" & Me.txtPYears.Text & "','" & Me.txtLAddress.Text & "','" & Me.txtLCity.Text & "','" & Me.cbxLState.Text & "','" & Me.txtLZipCode.Text & "','" & Me.txtFAddress.Text & "','" & Me.txtFCity.Text & "','" & Me.cbxFState.Text & "','" & Me.txtFZipCode.Text & "','" & Me.txtFYears.Text & "','" & Me.chkResident.Checked.ToString & "','" & Me.txtCurrentPhone.Text & "','" & Me.txtWorkPhone.Text & "','" & Me.txtEmail.Text & "','" & Me.chbxHisorLatin.Checked.ToString & "' ,'" & Me.txtRequestYear.Text & "','" & Me.cbxSession.Text & "','" & Me.cbxReqProgram.Text & "','" & Me.txtBefore_when.Text & "','" & Me.chkEnrolled.Checked.ToString & "' ,'" & Me.chkBefore.Checked.ToString & "' ,'" & Me.txtEnrolled_When.Text & "','" & Me.cbxStanding.Text & "','" & Me.txtCName1.Text & "','" & Me.txtCName2.Text & "','" & Me.txtHoursEarned1.Text & "','" & Me.txtHoursEarned2.Text & "','" & Me.txtCGPA1.Text & "','" & Me.txtCGPA2.Text & "','" & Me.ckbGraduated1.Checked.ToString & "' ,'" & Me.ckbGraduated2.Checked.ToString & "','" & Me.txtDegree1.Text & "' ,'" & Me.txtDegree2.Text & "' ,'" & Me.txtCTo1.Text & "','" & Me.txtCFrom1.Text & "','" & Me.txtCTo2.Text & "','" & Me.txtCFrom2.Text & "','" & Me.txtGMATDate.Text & "','" & Me.txtTOEFLDate.Text & "','" & Me.txtTSEDate.Text & "' ,'" & Me.txtGMATTotal.Text & "','" & Me.txtTOEFLTotal.Text & "','" & Me.txtTSETotal.Text & "' ,'" & Me.chkAppForm.Checked.ToString & "','" & Me.chkAppFeePaid.Checked.ToString & "','" & Me.chkResume.Checked.ToString & "','" & Me.chkLOR.Checked.ToString & "','" & Me.chkTranscript.Checked.ToString & "','" & Me.chkEssay.Checked.ToString & "','" & Me.chkGMATScore.Checked.ToString & "','" & Me.chkEducation.Checked.ToString & "','" & Me.chkFinancial.Checked.ToString & "','" & Me.chkTOEFL.Checked.ToString & "');", con)
            MessageBox.Show(command.CommandText.ToString())

            'Another method of inserting fields into the database
            'Dim command As New OleDbCommand("INSERT INTO COURSE (NA ME,CLSTIME,ROOM,TID)" & "VALUES(?, ?, ?, ?)", con)
            'command.Parameters.AddWithValue("NAME", NAME1)
            'command.Parameters.AddWithValue("CLSTIME", CLSTIME)
            'command.Parameters.AddWithValue("ROOM", ROOM)
            'command.Parameters.AddWithValue("TID", TID)



            'Insert a new record into the database table
            'Opens connection to the database
            con.ConnectionString = ConnString
            con.Open()

            'Execute the Insert Statement in the command variable
            RowsInsertedInteger = command.ExecuteNonQuery()

            'Close the connection
            con.Close()

        Catch ex As Exception
            'This is what happens if there is an error
            MessageBox.Show("Error in saving information to the database: " & ex.Message)
            con.Close()
        Finally
            'If all else fails, this will run
            'Close DB Connection here
            con.Close()
        End Try
    End Sub


    Private Sub ClearFields()
        'Student Personal

        'Me.txtStudentID.Clear()
        Me.txtLastName.Clear()
        Me.txtFirstName.Clear()
        Me.txtMiddleName.Clear()
        Me.txtSSN.Clear()
        Me.txtBirthday1.Clear()
        Me.cbxOrigin.ResetText()
        Me.cbxEthnic.ResetText()
        Me.cbxGender.ResetText()
        Me.cbxCitizenship.ResetText()
        Me.chbxHisorLatin.Checked = False


        'Student Address 
        Me.txtPAddress.Clear()
        Me.txtPCity.Clear()
        Me.cbxPState.ResetText()
        Me.txtPZipCode.Clear()
        Me.txtFAddress.Clear()
        Me.txtFCity.Clear()
        Me.cbxFState.ResetText()
        Me.txtFZipCode.Clear()
        Me.chkResident.Checked = False
        Me.txtLAddress.Clear()
        Me.txtLCity.Clear()
        Me.cbxLState.ResetText()
        Me.txtLZipCode.Clear()
        Me.txtPYears.Clear()
        Me.txtFYears.Clear()

        'Student Phone 
        Me.txtCurrentPhone.Clear()
        Me.txtWorkPhone.Clear()

        'Student Email 
        Me.txtEmail.Clear()

        'Student Test Score 
        Me.txtGMATDate.Clear()
        Me.txtGMATTotal.Clear()
        Me.txtTOEFLDate.Clear()
        Me.txtTOEFLTotal.Clear()
        Me.txtTSEDate.Clear()
        Me.txtTSETotal.Clear()

        'Student Academic Transcript
        Me.txtCName1.Clear()
        Me.txtCTo1.Clear()
        Me.txtCFrom1.Clear()
        Me.txtHoursEarned1.Clear()
        Me.txtDegree1.Clear()
        Me.ckbGraduated1.Checked = False
        Me.ckbGraduated2.Checked = False
        Me.txtCGPA1.Clear()
        Me.txtCGPA2.Clear()
        Me.txtCName2.Clear()
        Me.txtCTo2.Clear()
        Me.txtCFrom2.Clear()
        Me.txtHoursEarned2.Clear()
        Me.txtDegree2.Clear()
        Me.cbxConcen.ResetText()

        'Student Admission State
        Me.txtRequestYear.Clear()
        Me.cbxSession.ResetText()
        Me.chkBefore.Checked = False
        Me.txtBefore_when.Clear()
        Me.chkEnrolled.Checked = False
        Me.txtEnrolled_When.Clear()
        Me.cbxStanding.ResetText()
        Me.cbxReqProgram.ResetText()
        Me.chkAppFeePaid.Checked = False
        Me.chkResume.Checked = False
        Me.chkEssay.Checked = False
        Me.chkAppForm.Checked = False
        Me.chkLOR.Checked = False
        Me.chkTranscript.Checked = False
        Me.chkEducation.Checked = False
        Me.chkFinancial.Checked = False
        Me.chkTOEFL.Checked = False
        Me.chkGMATScore.Checked = False

    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()

    End Sub

    Private Sub InsertButton_Click(sender As Object, e As EventArgs) Handles InsertButton.Click
        PostToDB_Course()
        ClearFields()
    End Sub

    Private Sub ClearFieldsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClearFieldsToolStripMenuItem.Click
        ClearFields()
    End Sub

    Private Sub SearchButton_Click(sender As Object, e As EventArgs) Handles SearchButton.Click
        Try

            Dim ds As New DataSet
            ssn = txtSSN.Text
            LastName = txtLastName.Text
            'selectedInstructor = ""
            'This example will load the DataGridView
            'Dim sql As String = "SELECT NAME FROM INSTRUCTOR;"
            Dim sql As String = "SELECT SSN, LASTNAME From GRADSTUDENTS WHERE (SSN ='" & ssn & "'  OR LASTNAME ='" & LastName & "' );"
            '"SELECT NAME,TID from INSTRUCTOR WHERE NAME ='" & selectedInstructor & "' ;"
            con.ConnectionString = ConnString
            con.Open()
            oledbAdapter = New OleDbDataAdapter(sql, con)
            oledbAdapter.Fill(ds)
            DataGridView1.DataSource = ds.Tables(0)
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error in retrieving instructor list from database" & ex.Message, "Database Error")
            con.Close()
        End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        '*********Partially working the datatype for enrolled_when textbox might be wrong


        Try
            selectedStudent = DataGridView1.CurrentCell.FormattedValue
            Dim command As New OleDbCommand("SELECT SSN,LASTNAME, MIDDLENAME,FIRSTNAME,DOB,BIRTHPLACE, RACE, GENDER, CITIZENSHIP, PERMADDRESS, PERMCITY, PERMZIPCODE,PERMSTATE, YEARSATPERM,MAILADDRESS,MAILCITY, MAILSTATE,MAILZIPCODE, FORMERADDRESS, FORMERCITY, FORMERSTATE,FORMERZIPCODE,YEARSATFORMER,ARRESIDENT,HOMEPHONE, CELLPHONE,EMAIL,HISORLATIN, ADMITREQYEAR,ADMITREQTERM,ADMITREQPROGRAM,APPLIEDWHEN,PREVENROLL,APPLIEDBEFORE,PREVENROLLWHEN,PREVENROLLLEVEL,COLLEGE1,COLLEGE2 FROM GRADSTUDENTS WHERE LASTNAME = '" & selectedStudent & "' ;", con)
            '(SELECT EmployeeID FROM Employee WHERE Name ='" & selectedEmployee & "') ;", con)
            Dim dr As OleDbDataReader

            con.ConnectionString = ConnString
            con.Open()





            dr = command.ExecuteReader()

            While dr.Read()
                'ListBox2.Items.Add(Trim(dr.GetString(0) & " " & dr.GetString(1) & " " & dr.GetString(2)))
                txtSSN.Text = dr.GetString(0)
                txtLastName.Text = dr.GetString(1)
                txtMiddleName.Text = dr.GetString(2)
                txtFirstName.Text = dr.GetString(3)
                txtBirthday1.Text = dr.ToString(4)
                cbxOrigin.Text = dr.GetString(5)
                cbxEthnic.Text = dr.GetString(6)
                cbxGender.Text = dr.GetString(7)
                cbxCitizenship.Text = dr.GetString(8)
                txtPAddress.Text = dr.GetString(9)
                txtPCity.Text = dr.GetString(10)
                txtPZipCode.Text = dr.GetString(11)
                cbxPState.Text = dr.GetString(12)
                txtPYears.Text = dr.GetInt32(13)
                txtLAddress.Text = dr.GetString(14)
                txtLCity.Text = dr.GetString(15)
                cbxLState.Text = dr.GetString(16)
                txtLZipCode.Text = dr.GetString(17)
                txtFAddress.Text = dr.GetString(18)
                txtFCity.Text = dr.GetString(19)
                cbxFState.Text = dr.GetString(20)
                txtFZipCode.Text = dr.GetString(21)
                txtFYears.Text = dr.GetInt32(22)
                chkResident.Checked = dr.GetBoolean(23)
                txtCurrentPhone.Text = dr.GetString(24)
                txtWorkPhone.Text = dr.GetString(25)
                txtEmail.Text = dr.GetString(26)
                chbxHisorLatin.Checked = dr.GetBoolean(27)
                txtRequestYear.Text = dr.GetString(28)
                cbxSession.Text = dr.GetString(29)
                cbxReqProgram.Text = dr.GetString(30)
                txtBefore_when.Text = dr.ToString(31)
                chkEnrolled.Checked = dr.GetBoolean(32)
                chkBefore.Checked = dr.GetBoolean(33)
                txtEnrolled_When.Text = dr.ToString(34)
                cbxStanding.Text = dr.GetString(35)
                txtCName1.Text = dr.GetString(36)
                txtCName2.Text = dr.GetString(37)
                'txtHoursEarned1.Text = dr.GetString(35)
                'txtHoursEarned2.Text = dr.GetString(36)
                'txtCGPA1.Text = dr.GetString(37)
                'txtCGPA2.Text = dr.GetString(38)
                'txtCName1.Text = dr.GetString(39)
                'txtCName1.Text = dr.GetString(40)
                'txtCName1.Text = dr.GetString(41)
                'ckbGraduated1.Checked = dr.GetBoolean(42)
                'ckbGraduated2.Checked = dr.GetBoolean(43)
                'txtDegree1.Text = dr.GetString(44)
                'txtDegree2.Text = dr.GetString(45)
                'txtCTo1.Text = dr.GetString(46)
                'txtCFrom1.Text = dr.GetString(47)
                'txtCTo2.Text = dr.GetString(48)
                'txtCFrom2.Text = dr.GetString(49)
                'txtGMATDate.Text = dr.GetString(50)
                'txtTOEFLDate.Text = dr.GetString(51)
                'txtTSEDate.Text = dr.GetString(52)
                'txtGMATTotal.Text = dr.GetString(53)
                'txtTOEFLTotal.Text = dr.GetString(54)
                'txtTSETotal.Text = dr.GetString(55)
                'chkAppForm.Checked = dr.GetBoolean(56)
                'chkAppFeePaid.Checked = dr.GetBoolean(57)
                'chkResume.Checked = dr.GetBoolean(58)
                'chkLOR.Checked = dr.GetBoolean(59)
                'chkTranscript.Checked = dr.GetBoolean(60)
                'chkEssay.Checked = dr.GetBoolean(61)
                'chkGMATScore.Checked = dr.GetBoolean(62)
                'chkEducation.Checked = dr.GetBoolean(63)
                'chkFinancial.Checked = dr.GetBoolean(64)
                'chkTOEFL.Checked = dr.GetBoolean(65)


                'Student Personal


                'UpdateST_Ma_textbox.Text = dr.GetString(1)
                'UpdateST_Gr_textbox.Text = dr.GetString(2)
                'UpdateST_Ag_textbox.Text = dr.GetInt16(3)
                'UpdateST_NUM_TextBox.Text = dr.GetInt16(4)

            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error in retrieving producer list from database" & ex.Message, "Database Error")
            con.Close()
        End Try
    End Sub

    Private Sub DeleteButton_Click(sender As Object, e As EventArgs) Handles DeleteButton.Click
        Try

            Dim ds As New DataSet
            ssn = txtSSN.Text

            'selectedInstructor = ""
            'This example will load the DataGridView
            'Dim sql As String = "SELECT NAME FROM INSTRUCTOR;"
            Dim sql As String = "DELETE  FROM GRADSTUDENTS WHERE SSN ='" & ssn & "';"

            'Insert a new record into the database table
            'Opens connection to the database
            con.ConnectionString = ConnString
            con.Open()

            'Execute the Insert Statement in the command variable


            'Close the connection
            con.Close()

        Catch ex As Exception
            'This is what happens if there is an error
            MessageBox.Show("Error in saving information to the database: " & ex.Message)
            con.Close()
        Finally
            'If all else fails, this will run
            'Close DB Connection here
            con.Close()
        End Try
    End Sub
End Class