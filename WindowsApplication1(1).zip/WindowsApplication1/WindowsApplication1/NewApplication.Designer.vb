﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NewApplication
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.SearchButton = New System.Windows.Forms.Button()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtCName1 = New System.Windows.Forms.TextBox()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.txtCFrom1 = New System.Windows.Forms.TextBox()
        Me.txtCName2 = New System.Windows.Forms.TextBox()
        Me.txtCTo2 = New System.Windows.Forms.TextBox()
        Me.txtCTo1 = New System.Windows.Forms.TextBox()
        Me.txtCFrom2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.FirstNameL = New System.Windows.Forms.Label()
        Me.LastNameL = New System.Windows.Forms.Label()
        Me.IDL = New System.Windows.Forms.Label()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(676, 24)
        Me.MenuStrip1.TabIndex = 19
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(41, 20)
        Me.FileToolStripMenuItem.Text = "Back"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(31, 46)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(118, 20)
        Me.txtLastName.TabIndex = 20
        '
        'lblLastName
        '
        Me.lblLastName.AutoSize = True
        Me.lblLastName.Location = New System.Drawing.Point(31, 30)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(96, 13)
        Me.lblLastName.TabIndex = 202
        Me.lblLastName.Text = "Student ID number"
        '
        'SearchButton
        '
        Me.SearchButton.Location = New System.Drawing.Point(202, 43)
        Me.SearchButton.Name = "SearchButton"
        Me.SearchButton.Size = New System.Drawing.Size(75, 23)
        Me.SearchButton.TabIndex = 455
        Me.SearchButton.Text = "Search"
        Me.SearchButton.UseVisualStyleBackColor = True
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(3, 69)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(769, 13)
        Me.Label65.TabIndex = 456
        Me.Label65.Text = "_________________________________________________________________________________" &
    "______________________________________________"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(23, 99)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(126, 16)
        Me.Label23.TabIndex = 457
        Me.Label23.Text = "Work Experience"
        Me.Label23.Visible = False
        '
        'txtCName1
        '
        Me.txtCName1.Location = New System.Drawing.Point(23, 142)
        Me.txtCName1.Name = "txtCName1"
        Me.txtCName1.Size = New System.Drawing.Size(182, 20)
        Me.txtCName1.TabIndex = 458
        Me.txtCName1.Visible = False
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(208, 126)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(23, 13)
        Me.Label54.TabIndex = 465
        Me.Label54.Text = "To:"
        Me.Label54.Visible = False
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(284, 126)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(33, 13)
        Me.Label55.TabIndex = 466
        Me.Label55.Text = "From:"
        Me.Label55.Visible = False
        '
        'txtCFrom1
        '
        Me.txtCFrom1.Location = New System.Drawing.Point(287, 142)
        Me.txtCFrom1.Name = "txtCFrom1"
        Me.txtCFrom1.Size = New System.Drawing.Size(70, 20)
        Me.txtCFrom1.TabIndex = 460
        Me.txtCFrom1.Visible = False
        '
        'txtCName2
        '
        Me.txtCName2.Location = New System.Drawing.Point(23, 168)
        Me.txtCName2.Name = "txtCName2"
        Me.txtCName2.Size = New System.Drawing.Size(182, 20)
        Me.txtCName2.TabIndex = 461
        Me.txtCName2.Visible = False
        '
        'txtCTo2
        '
        Me.txtCTo2.Location = New System.Drawing.Point(211, 168)
        Me.txtCTo2.Name = "txtCTo2"
        Me.txtCTo2.Size = New System.Drawing.Size(70, 20)
        Me.txtCTo2.TabIndex = 462
        Me.txtCTo2.Visible = False
        '
        'txtCTo1
        '
        Me.txtCTo1.Location = New System.Drawing.Point(211, 142)
        Me.txtCTo1.Name = "txtCTo1"
        Me.txtCTo1.Size = New System.Drawing.Size(70, 20)
        Me.txtCTo1.TabIndex = 459
        Me.txtCTo1.Visible = False
        '
        'txtCFrom2
        '
        Me.txtCFrom2.Location = New System.Drawing.Point(287, 168)
        Me.txtCFrom2.Name = "txtCFrom2"
        Me.txtCFrom2.Size = New System.Drawing.Size(70, 20)
        Me.txtCFrom2.TabIndex = 463
        Me.txtCFrom2.Visible = False
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(363, 168)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(182, 20)
        Me.TextBox1.TabIndex = 468
        Me.TextBox1.Visible = False
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(363, 142)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(182, 20)
        Me.TextBox2.TabIndex = 467
        Me.TextBox2.Visible = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(360, 126)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 13)
        Me.Label1.TabIndex = 469
        Me.Label1.Text = "Position"
        Me.Label1.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(23, 121)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(50, 13)
        Me.Label2.TabIndex = 470
        Me.Label2.Text = "Employer"
        Me.Label2.Visible = False
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.Location = New System.Drawing.Point(23, 207)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(165, 16)
        Me.Label53.TabIndex = 471
        Me.Label53.Text = "Certifications/Licenses"
        Me.Label53.Visible = False
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(213, 246)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(70, 20)
        Me.TextBox3.TabIndex = 473
        Me.TextBox3.Visible = False
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(213, 272)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(70, 20)
        Me.TextBox4.TabIndex = 475
        Me.TextBox4.Visible = False
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(23, 272)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(182, 20)
        Me.TextBox5.TabIndex = 474
        Me.TextBox5.Visible = False
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(23, 246)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(182, 20)
        Me.TextBox6.TabIndex = 472
        Me.TextBox6.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(210, 230)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(30, 13)
        Me.Label3.TabIndex = 477
        Me.Label3.Text = "Date"
        Me.Label3.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(23, 230)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(62, 13)
        Me.Label4.TabIndex = 476
        Me.Label4.Text = "Certification"
        Me.Label4.Visible = False
        '
        'FirstNameL
        '
        Me.FirstNameL.AutoSize = True
        Me.FirstNameL.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.FirstNameL.Location = New System.Drawing.Point(224, 82)
        Me.FirstNameL.Name = "FirstNameL"
        Me.FirstNameL.Size = New System.Drawing.Size(13, 13)
        Me.FirstNameL.TabIndex = 478
        Me.FirstNameL.Text = "_"
        Me.FirstNameL.Visible = False
        '
        'LastNameL
        '
        Me.LastNameL.AutoSize = True
        Me.LastNameL.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.LastNameL.Location = New System.Drawing.Point(296, 82)
        Me.LastNameL.Name = "LastNameL"
        Me.LastNameL.Size = New System.Drawing.Size(13, 13)
        Me.LastNameL.TabIndex = 479
        Me.LastNameL.Text = "_"
        Me.LastNameL.Visible = False
        '
        'IDL
        '
        Me.IDL.AutoSize = True
        Me.IDL.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IDL.Location = New System.Drawing.Point(402, 82)
        Me.IDL.Name = "IDL"
        Me.IDL.Size = New System.Drawing.Size(13, 13)
        Me.IDL.TabIndex = 480
        Me.IDL.Text = "_"
        Me.IDL.Visible = False
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(23, 333)
        Me.TextBox7.Multiline = True
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(573, 241)
        Me.TextBox7.TabIndex = 481
        Me.TextBox7.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(23, 295)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(151, 13)
        Me.Label5.TabIndex = 482
        Me.Label5.Text = "________________________"
        Me.Label5.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(23, 314)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(65, 16)
        Me.Label6.TabIndex = 483
        Me.Label6.Text = "Resume"
        Me.Label6.Visible = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(472, 86)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 484
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        Me.Button1.Visible = False
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(573, 86)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 485
        Me.Button2.Text = "Button2"
        Me.Button2.UseVisualStyleBackColor = True
        Me.Button2.Visible = False
        '
        'NewApplication
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(676, 582)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.IDL)
        Me.Controls.Add(Me.LastNameL)
        Me.Controls.Add(Me.FirstNameL)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label53)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.txtCFrom1)
        Me.Controls.Add(Me.txtCFrom2)
        Me.Controls.Add(Me.txtCTo1)
        Me.Controls.Add(Me.txtCTo2)
        Me.Controls.Add(Me.txtCName2)
        Me.Controls.Add(Me.txtCName1)
        Me.Controls.Add(Me.Label55)
        Me.Controls.Add(Me.Label54)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label65)
        Me.Controls.Add(Me.SearchButton)
        Me.Controls.Add(Me.lblLastName)
        Me.Controls.Add(Me.txtLastName)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "NewApplication"
        Me.Text = "NewApplication"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents lblLastName As Label
    Friend WithEvents SearchButton As Button
    Friend WithEvents Label65 As Label
    Friend WithEvents txtCName1 As TextBox
    Friend WithEvents Label54 As Label
    Friend WithEvents Label55 As Label
    Friend WithEvents txtCFrom1 As TextBox
    Friend WithEvents txtCName2 As TextBox
    Friend WithEvents txtCTo2 As TextBox
    Friend WithEvents txtCTo1 As TextBox
    Friend WithEvents txtCFrom2 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label53 As Label
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents FirstNameL As Label
    Friend WithEvents LastNameL As Label
    Friend WithEvents IDL As Label
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
End Class
