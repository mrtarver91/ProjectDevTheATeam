CREATE Table  COMPANY (
CompanyID	INT IDENTITY(1,1) NOT NULL,
CompanyName	VARCHAR(10) NOT NULL,
POC			VARCHAR(30),
Phone		VARCHAR(15),
City		VARCHAR(15),
State		VARCHAR(15),

CONSTRAINT Student_PK PRIMARY KEY (CompanyID)
);


Create Table RECRUITMENT (
RID			INT IDENTITY(1,1) NOT NULL,
CompanyName	VARCHAR(30),
StudentID	NVARCHAR(50),
JobNameR	VARCHAR(30),
JobDescriptionR	TEXT,
HourlyR		Bit,
SalaryR		Bit,
PayR		INT,
CityR		VARCHAR(30),
StateR		VARCHAR(15),
UGPAR		VARCHAR(5),
GGPAR		VARCHAR(5),
UDegreeR	VARCHAR(15),
GDegreeR	VARCHAR(15),
HonorsR		BIT,
MoveR		BIT,
Employer1A	VARCHAR(30),
FromDate1A	DATE,
ToDate1A	DATE,
Postition1A	VARCHAR(20),
Employer2A	VARCHAR(30),
FromDate2A	DATE,
ToDate2A	DATE,
Position2A	VARCHAR(20),
Certificaiton1A	VARCHAR(30),
Date1A		DATE,
Certification2A	VARCHAR(30),
Date2A		DATE,
ResumeA		TEXT,
TYPE		CHAR(1),
CONSTRAINT Recruitment_PK PRIMARY KEY (RID),
CONSTRAINT Company_FK1 FOREIGN KEY (CompanyName) REFERENCES Company (PantryID),
CONSTRAINT Gradstudents_FK2 FOREIGN KEY (StudentID) REFERENCES Gradstudents (StoreID)
);


INSERT INTO Recruitment(StudentID, FirstName, LastName, Employee1, Employee2, 
From1, From2, To1, To2, Pos1, Pos2, Cert1, Cert2, Resume1, Type) 
VALUES('" & StudentID & "','" & FirstName & "','" & LastName & "','" & Employee1 & "',
'" & Employee2 & "','" & From1 & "',
'" & From2 & "', '" & To1 & "','" & To2 & "',
'" & Pos1 & "','" & Pos2 & "','" & Cert1 & "',
'" & Cert2 & "','" & Resume1 & "','A')


INSERT INTO Company(CompanName, POC, Phone, City, State) VALUES('" & CompanyTB.Text & "','" & POCTB.Text & "','" & PhoneTB.Text & "','" & CityTB.Text & "','" & State & "')


INSERT INTO Recruitment(CompanyName, JobNameR, JobDescriptionR, HourlyR, SalaryR, PayR, CityR, StateR, 
UGPAR, GGPAR, UDegreeR, GDegreeR, HonorsR, MoveR) VALUES('" & CompanyName & "','" & JobName & "',
'" & JobDescription & "','" & Hourly & "','" & Salary & "','" & Pay & "','" & City & "',
 '" & State & "','" & UGPA & "','" & GGPA & "','" & UStrict & "','" & MScrict & "','" & Degree & "','" & Resume1 & "','A');


INSERT INTO Recruitment(StudentID, FirstName, LastName, Employee1, Employee2, From1, From2, To1, To2, Pos1, Pos2, Cert1, Cert2, Resume1, Type) VALUES('" & IDL.Text & "','" & FNameL.Text & "','" & LastNameL.Text & "','" & Employee1 & "','" & Employee2 & "','" & From1 & "','" & From2 & "', '" & To1 & "','" & To2 & "','" & Pos1 & "','" & Pos2 & "','" & Cert1 & "','" & Cert2 & "','" & Resume1 & "','A')













