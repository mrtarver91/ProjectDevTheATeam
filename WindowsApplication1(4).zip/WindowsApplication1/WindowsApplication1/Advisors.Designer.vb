﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Advisors
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Advisors))
        Me.txtPAddress = New System.Windows.Forms.TextBox()
        Me.txtMiddleName = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.cbxCitizenship = New System.Windows.Forms.ComboBox()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.cbxConcentration = New System.Windows.Forms.ComboBox()
        Me.chbHonors2 = New System.Windows.Forms.CheckBox()
        Me.chbHonors1 = New System.Windows.Forms.CheckBox()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.cbxGender = New System.Windows.Forms.ComboBox()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.ckbGraduated2 = New System.Windows.Forms.CheckBox()
        Me.ckbGraduated1 = New System.Windows.Forms.CheckBox()
        Me.InsertButton = New System.Windows.Forms.Button()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.txtCFrom1 = New System.Windows.Forms.TextBox()
        Me.txtCFrom2 = New System.Windows.Forms.TextBox()
        Me.txtCTo1 = New System.Windows.Forms.TextBox()
        Me.chbxHisorLatin = New System.Windows.Forms.CheckBox()
        Me.cbxFState = New System.Windows.Forms.ComboBox()
        Me.cbxLState = New System.Windows.Forms.ComboBox()
        Me.cbxPState = New System.Windows.Forms.ComboBox()
        Me.txtPZipCode = New System.Windows.Forms.MaskedTextBox()
        Me.txtLZipCode = New System.Windows.Forms.MaskedTextBox()
        Me.txtFZipCode = New System.Windows.Forms.MaskedTextBox()
        Me.txtWorkPhone = New System.Windows.Forms.MaskedTextBox()
        Me.txtPCity = New System.Windows.Forms.TextBox()
        Me.txtCTo2 = New System.Windows.Forms.TextBox()
        Me.txtFAddress = New System.Windows.Forms.TextBox()
        Me.txtPYears = New System.Windows.Forms.TextBox()
        Me.txtDegree2 = New System.Windows.Forms.TextBox()
        Me.txtDegree1 = New System.Windows.Forms.TextBox()
        Me.txtHoursEarned2 = New System.Windows.Forms.TextBox()
        Me.txtHoursEarned1 = New System.Windows.Forms.TextBox()
        Me.txtCGPA2 = New System.Windows.Forms.TextBox()
        Me.txtCGPA1 = New System.Windows.Forms.TextBox()
        Me.txtCName2 = New System.Windows.Forms.TextBox()
        Me.txtCName1 = New System.Windows.Forms.TextBox()
        Me.txtTSEDate = New System.Windows.Forms.TextBox()
        Me.txtFYears = New System.Windows.Forms.TextBox()
        Me.txtLCity = New System.Windows.Forms.TextBox()
        Me.txtLAddress = New System.Windows.Forms.TextBox()
        Me.txtFCity = New System.Windows.Forms.TextBox()
        Me.txtTOEFLDate = New System.Windows.Forms.TextBox()
        Me.cbxOrigin = New System.Windows.Forms.ComboBox()
        Me.txtGMATTotal = New System.Windows.Forms.TextBox()
        Me.txtTSETotal = New System.Windows.Forms.TextBox()
        Me.txtCurrentPhone = New System.Windows.Forms.MaskedTextBox()
        Me.txtBirthday1 = New System.Windows.Forms.MaskedTextBox()
        Me.txtSSN = New System.Windows.Forms.MaskedTextBox()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.txtTOEFLTotal = New System.Windows.Forms.TextBox()
        Me.tabApplication = New System.Windows.Forms.TabControl()
        Me.tabPersonalInfo = New System.Windows.Forms.TabPage()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.DeleteButton = New System.Windows.Forms.Button()
        Me.UpdateButton = New System.Windows.Forms.Button()
        Me.SearchButton = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.lblBirthdayFormat = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.chkResident = New System.Windows.Forms.CheckBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.cbxEthnic = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblDOB = New System.Windows.Forms.Label()
        Me.lblSSN = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblMiddleName = New System.Windows.Forms.Label()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.chbGraduated2 = New System.Windows.Forms.TabPage()
        Me.txtGMATDate = New System.Windows.Forms.TextBox()
        Me.txtEnrolled_When = New System.Windows.Forms.TextBox()
        Me.txtBefore_when = New System.Windows.Forms.TextBox()
        Me.txtRequestYear = New System.Windows.Forms.TextBox()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chkAppForm = New System.Windows.Forms.CheckBox()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.chkAppFeePaid = New System.Windows.Forms.CheckBox()
        Me.chkResume = New System.Windows.Forms.CheckBox()
        Me.chkLOR = New System.Windows.Forms.CheckBox()
        Me.chkTranscript = New System.Windows.Forms.CheckBox()
        Me.chkEssay = New System.Windows.Forms.CheckBox()
        Me.chkGMATScore = New System.Windows.Forms.CheckBox()
        Me.chkEducation = New System.Windows.Forms.CheckBox()
        Me.chkFinancial = New System.Windows.Forms.CheckBox()
        Me.chkTOEFL = New System.Windows.Forms.CheckBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cbxReqProgram = New System.Windows.Forms.ComboBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.cbxStanding = New System.Windows.Forms.ComboBox()
        Me.lblSession = New System.Windows.Forms.Label()
        Me.cbxSession = New System.Windows.Forms.ComboBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.chkEnrolled = New System.Windows.Forms.CheckBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.chkBefore = New System.Windows.Forms.CheckBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.txtStudentID = New System.Windows.Forms.TextBox()
        Me.TxtSSNSearch = New System.Windows.Forms.TextBox()
        Me.CheckBox_admit = New System.Windows.Forms.CheckBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearFieldsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.BackToWelcomeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.tabApplication.SuspendLayout()
        Me.tabPersonalInfo.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.chbGraduated2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtPAddress
        '
        Me.txtPAddress.Location = New System.Drawing.Point(48, 164)
        Me.txtPAddress.Name = "txtPAddress"
        Me.txtPAddress.Size = New System.Drawing.Size(273, 20)
        Me.txtPAddress.TabIndex = 12
        '
        'txtMiddleName
        '
        Me.txtMiddleName.Location = New System.Drawing.Point(62, 77)
        Me.txtMiddleName.Name = "txtMiddleName"
        Me.txtMiddleName.Size = New System.Drawing.Size(100, 20)
        Me.txtMiddleName.TabIndex = 3
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(62, 25)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(145, 20)
        Me.txtLastName.TabIndex = 1
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.Location = New System.Drawing.Point(660, 243)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(80, 13)
        Me.Label72.TabIndex = 235
        Me.Label72.Text = "Email Address*:"
        '
        'cbxCitizenship
        '
        Me.cbxCitizenship.FormattingEnabled = True
        Me.cbxCitizenship.Items.AddRange(New Object() {"U.S. Citizen", "Resident Alien", "Non-Resident Alien"})
        Me.cbxCitizenship.Location = New System.Drawing.Point(229, 105)
        Me.cbxCitizenship.Name = "cbxCitizenship"
        Me.cbxCitizenship.Size = New System.Drawing.Size(121, 21)
        Me.cbxCitizenship.TabIndex = 11
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(157, 88)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(76, 13)
        Me.Label52.TabIndex = 466
        Me.Label52.Text = "Concentration:"
        '
        'cbxConcentration
        '
        Me.cbxConcentration.FormattingEnabled = True
        Me.cbxConcentration.Items.AddRange(New Object() {"Enterprise Resource Planning (ERP) Management", "Enterprise Systems (ES) Management", "Information Technology Management", "Software Engineering Management"})
        Me.cbxConcentration.Location = New System.Drawing.Point(160, 104)
        Me.cbxConcentration.Name = "cbxConcentration"
        Me.cbxConcentration.Size = New System.Drawing.Size(133, 21)
        Me.cbxConcentration.TabIndex = 465
        '
        'chbHonors2
        '
        Me.chbHonors2.AutoSize = True
        Me.chbHonors2.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chbHonors2.Location = New System.Drawing.Point(694, 491)
        Me.chbHonors2.Name = "chbHonors2"
        Me.chbHonors2.Size = New System.Drawing.Size(60, 17)
        Me.chbHonors2.TabIndex = 464
        Me.chbHonors2.Text = "Honors"
        Me.chbHonors2.UseVisualStyleBackColor = True
        '
        'chbHonors1
        '
        Me.chbHonors1.AutoSize = True
        Me.chbHonors1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chbHonors1.Location = New System.Drawing.Point(694, 468)
        Me.chbHonors1.Name = "chbHonors1"
        Me.chbHonors1.Size = New System.Drawing.Size(60, 17)
        Me.chbHonors1.TabIndex = 463
        Me.chbHonors1.Text = "Honors"
        Me.chbHonors1.UseVisualStyleBackColor = True
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label64.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label64.Location = New System.Drawing.Point(4, 237)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(60, 10)
        Me.Label64.TabIndex = 458
        Me.Label64.Text = "YYYY-MM-DD"
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(62, 51)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(145, 20)
        Me.txtFirstName.TabIndex = 2
        '
        'cbxGender
        '
        Me.cbxGender.FormattingEnabled = True
        Me.cbxGender.Items.AddRange(New Object() {"Male", "Female"})
        Me.cbxGender.Location = New System.Drawing.Point(365, 105)
        Me.cbxGender.Name = "cbxGender"
        Me.cbxGender.Size = New System.Drawing.Size(121, 21)
        Me.cbxGender.TabIndex = 10
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Location = New System.Drawing.Point(331, 275)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(439, 13)
        Me.Label66.TabIndex = 315
        Me.Label66.Text = "________________________________________________________________________"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(660, 209)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(61, 13)
        Me.Label3.TabIndex = 232
        Me.Label3.Text = "Cell Phone:"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(660, 171)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(92, 13)
        Me.Label21.TabIndex = 231
        Me.Label21.Text = "Home Telephone:"
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(5, 129)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(769, 13)
        Me.Label65.TabIndex = 314
        Me.Label65.Text = "_________________________________________________________________________________" &
    "______________________________________________"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(13, 424)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(137, 13)
        Me.Label50.TabIndex = 228
        Me.Label50.Text = "Years at the above address"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(650, 142)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(102, 13)
        Me.Label46.TabIndex = 230
        Me.Label46.Text = "Contact Information:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(331, 246)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(22, 13)
        Me.Label16.TabIndex = 222
        Me.Label16.Text = "Zip"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(329, 219)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(32, 13)
        Me.Label17.TabIndex = 221
        Me.Label17.Text = "State"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label62.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label62.Location = New System.Drawing.Point(5, 204)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(60, 10)
        Me.Label62.TabIndex = 457
        Me.Label62.Text = "YYYY-MM-DD"
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label61.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label61.Location = New System.Drawing.Point(485, 37)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(60, 10)
        Me.Label61.TabIndex = 456
        Me.Label61.Text = "YYYY-MM-DD"
        '
        'ckbGraduated2
        '
        Me.ckbGraduated2.AutoSize = True
        Me.ckbGraduated2.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ckbGraduated2.Location = New System.Drawing.Point(564, 492)
        Me.ckbGraduated2.Name = "ckbGraduated2"
        Me.ckbGraduated2.Size = New System.Drawing.Size(82, 17)
        Me.ckbGraduated2.TabIndex = 453
        Me.ckbGraduated2.Text = "Graduated?"
        Me.ckbGraduated2.UseVisualStyleBackColor = True
        '
        'ckbGraduated1
        '
        Me.ckbGraduated1.AutoSize = True
        Me.ckbGraduated1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ckbGraduated1.Location = New System.Drawing.Point(563, 470)
        Me.ckbGraduated1.Name = "ckbGraduated1"
        Me.ckbGraduated1.Size = New System.Drawing.Size(82, 17)
        Me.ckbGraduated1.TabIndex = 452
        Me.ckbGraduated1.Text = "Graduated?"
        Me.ckbGraduated1.UseVisualStyleBackColor = True
        '
        'InsertButton
        '
        Me.InsertButton.Location = New System.Drawing.Point(657, 11)
        Me.InsertButton.Name = "InsertButton"
        Me.InsertButton.Size = New System.Drawing.Size(75, 23)
        Me.InsertButton.TabIndex = 451
        Me.InsertButton.Text = "Insert"
        Me.InsertButton.UseVisualStyleBackColor = True
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(336, 400)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(55, 13)
        Me.Label42.TabIndex = 450
        Me.Label42.Text = "Education"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label39.Location = New System.Drawing.Point(284, 516)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(60, 10)
        Me.Label39.TabIndex = 448
        Me.Label39.Text = "YYYY-MM-DD"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label38.Location = New System.Drawing.Point(204, 516)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(60, 10)
        Me.Label38.TabIndex = 447
        Me.Label38.Text = "YYYY-MM-DD"
        '
        'txtCFrom1
        '
        Me.txtCFrom1.Location = New System.Drawing.Point(286, 467)
        Me.txtCFrom1.Name = "txtCFrom1"
        Me.txtCFrom1.Size = New System.Drawing.Size(70, 20)
        Me.txtCFrom1.TabIndex = 418
        '
        'txtCFrom2
        '
        Me.txtCFrom2.Location = New System.Drawing.Point(286, 493)
        Me.txtCFrom2.Name = "txtCFrom2"
        Me.txtCFrom2.Size = New System.Drawing.Size(70, 20)
        Me.txtCFrom2.TabIndex = 427
        '
        'txtCTo1
        '
        Me.txtCTo1.Location = New System.Drawing.Point(206, 467)
        Me.txtCTo1.Name = "txtCTo1"
        Me.txtCTo1.Size = New System.Drawing.Size(70, 20)
        Me.txtCTo1.TabIndex = 417
        '
        'chbxHisorLatin
        '
        Me.chbxHisorLatin.AutoSize = True
        Me.chbxHisorLatin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chbxHisorLatin.Location = New System.Drawing.Point(512, 28)
        Me.chbxHisorLatin.Name = "chbxHisorLatin"
        Me.chbxHisorLatin.Size = New System.Drawing.Size(105, 17)
        Me.chbxHisorLatin.TabIndex = 320
        Me.chbxHisorLatin.Text = "Hispanic or Latin"
        Me.chbxHisorLatin.UseVisualStyleBackColor = True
        '
        'cbxFState
        '
        Me.cbxFState.FormattingEnabled = True
        Me.cbxFState.Items.AddRange(New Object() {"ALABAMA", "ALASKA", "AMERICAN SAMOA", "ARIZONA", "ARKANSAS", "CALIFORNIA", "COLORADO", "CONNECTICUT", "DELAWARE", "DISTRICT OF COLUMBIA", "FEDERATED STATES OF MICRONESIA", "FLORIDA", "GEORGIA", "GUAM", "HAWAII", "IDAHO", "ILLINOIS", "INDIANA", "IOWA", "KANSAS", "KENTUCKY", "LOUISIANA", "MAINE", "MARSHALL ISLANDS", "MARYLAND", "MASSACHUSETTS", "MICHIGAN", "MINNESOTA", "MISSISSIPPI", "MISSOURI", "MONTANA", "NEBRASKA", "NEVADA", "NEW HAMPSHIRE", "NEW JERSEY", "NEW MEXICO", "NEW YORK", "NORTH CAROLINA", "NORTH DAKOTA", "NORTHERN MARIANA ISLANDS", "OHIO", "OKLAHOMA", "OREGON", "PALAU", "PENNSYLVANIA", "PUERTO RICO", "RHODE ISLAND", "SOUTH CAROLINA", "SOUTH DAKOTA", "TENNESSEE", "TEXAS", "UTAH", "VERMONT", "VIRGIN ISLANDS", "VIRGINIA", "WASHINGTON", "WEST VIRGINIA", "WISCONSIN", "WYOMING"})
        Me.cbxFState.Location = New System.Drawing.Point(51, 369)
        Me.cbxFState.Name = "cbxFState"
        Me.cbxFState.Size = New System.Drawing.Size(121, 21)
        Me.cbxFState.TabIndex = 23
        '
        'cbxLState
        '
        Me.cbxLState.FormattingEnabled = True
        Me.cbxLState.Items.AddRange(New Object() {"ALABAMA", "ALASKA", "AMERICAN SAMOA", "ARIZONA", "ARKANSAS", "CALIFORNIA", "COLORADO", "CONNECTICUT", "DELAWARE", "DISTRICT OF COLUMBIA", "FEDERATED STATES OF MICRONESIA", "FLORIDA", "GEORGIA", "GUAM", "HAWAII", "IDAHO", "ILLINOIS", "INDIANA", "IOWA", "KANSAS", "KENTUCKY", "LOUISIANA", "MAINE", "MARSHALL ISLANDS", "MARYLAND", "MASSACHUSETTS", "MICHIGAN", "MINNESOTA", "MISSISSIPPI", "MISSOURI", "MONTANA", "NEBRASKA", "NEVADA", "NEW HAMPSHIRE", "NEW JERSEY", "NEW MEXICO", "NEW YORK", "NORTH CAROLINA", "NORTH DAKOTA", "NORTHERN MARIANA ISLANDS", "OHIO", "OKLAHOMA", "OREGON", "PALAU", "PENNSYLVANIA", "PUERTO RICO", "RHODE ISLAND", "SOUTH CAROLINA", "SOUTH DAKOTA", "TENNESSEE", "TEXAS", "UTAH", "VERMONT", "VIRGIN ISLANDS", "VIRGINIA", "WASHINGTON", "WEST VIRGINIA", "WISCONSIN", "WYOMING"})
        Me.cbxLState.Location = New System.Drawing.Point(369, 216)
        Me.cbxLState.Name = "cbxLState"
        Me.cbxLState.Size = New System.Drawing.Size(121, 21)
        Me.cbxLState.TabIndex = 19
        '
        'cbxPState
        '
        Me.cbxPState.FormattingEnabled = True
        Me.cbxPState.Items.AddRange(New Object() {"Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "District Of Columbia", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"})
        Me.cbxPState.Location = New System.Drawing.Point(48, 216)
        Me.cbxPState.Name = "cbxPState"
        Me.cbxPState.Size = New System.Drawing.Size(121, 21)
        Me.cbxPState.TabIndex = 14
        '
        'txtPZipCode
        '
        Me.txtPZipCode.Location = New System.Drawing.Point(47, 243)
        Me.txtPZipCode.Mask = "00000-0000"
        Me.txtPZipCode.Name = "txtPZipCode"
        Me.txtPZipCode.Size = New System.Drawing.Size(75, 20)
        Me.txtPZipCode.TabIndex = 15
        Me.txtPZipCode.ValidatingType = GetType(Integer)
        '
        'txtLZipCode
        '
        Me.txtLZipCode.Location = New System.Drawing.Point(370, 243)
        Me.txtLZipCode.Mask = "00000-0000"
        Me.txtLZipCode.Name = "txtLZipCode"
        Me.txtLZipCode.Size = New System.Drawing.Size(75, 20)
        Me.txtLZipCode.TabIndex = 20
        Me.txtLZipCode.ValidatingType = GetType(Integer)
        '
        'txtFZipCode
        '
        Me.txtFZipCode.Location = New System.Drawing.Point(51, 396)
        Me.txtFZipCode.Mask = "00000-0000"
        Me.txtFZipCode.Name = "txtFZipCode"
        Me.txtFZipCode.Size = New System.Drawing.Size(75, 20)
        Me.txtFZipCode.TabIndex = 24
        Me.txtFZipCode.ValidatingType = GetType(Integer)
        '
        'txtWorkPhone
        '
        Me.txtWorkPhone.Location = New System.Drawing.Point(758, 202)
        Me.txtWorkPhone.Mask = "(999) 000-0000"
        Me.txtWorkPhone.Name = "txtWorkPhone"
        Me.txtWorkPhone.Size = New System.Drawing.Size(100, 20)
        Me.txtWorkPhone.TabIndex = 28
        '
        'txtPCity
        '
        Me.txtPCity.Location = New System.Drawing.Point(48, 190)
        Me.txtPCity.Name = "txtPCity"
        Me.txtPCity.Size = New System.Drawing.Size(273, 20)
        Me.txtPCity.TabIndex = 13
        '
        'txtCTo2
        '
        Me.txtCTo2.Location = New System.Drawing.Point(206, 493)
        Me.txtCTo2.Name = "txtCTo2"
        Me.txtCTo2.Size = New System.Drawing.Size(70, 20)
        Me.txtCTo2.TabIndex = 426
        '
        'txtFAddress
        '
        Me.txtFAddress.Location = New System.Drawing.Point(51, 317)
        Me.txtFAddress.Name = "txtFAddress"
        Me.txtFAddress.Size = New System.Drawing.Size(273, 20)
        Me.txtFAddress.TabIndex = 21
        '
        'txtPYears
        '
        Me.txtPYears.Location = New System.Drawing.Point(153, 272)
        Me.txtPYears.Name = "txtPYears"
        Me.txtPYears.Size = New System.Drawing.Size(22, 20)
        Me.txtPYears.TabIndex = 16
        '
        'txtDegree2
        '
        Me.txtDegree2.Location = New System.Drawing.Point(502, 492)
        Me.txtDegree2.Name = "txtDegree2"
        Me.txtDegree2.Size = New System.Drawing.Size(55, 20)
        Me.txtDegree2.TabIndex = 430
        '
        'txtDegree1
        '
        Me.txtDegree1.Location = New System.Drawing.Point(502, 467)
        Me.txtDegree1.Name = "txtDegree1"
        Me.txtDegree1.Size = New System.Drawing.Size(55, 20)
        Me.txtDegree1.TabIndex = 421
        '
        'txtHoursEarned2
        '
        Me.txtHoursEarned2.Location = New System.Drawing.Point(432, 492)
        Me.txtHoursEarned2.Name = "txtHoursEarned2"
        Me.txtHoursEarned2.Size = New System.Drawing.Size(50, 20)
        Me.txtHoursEarned2.TabIndex = 429
        '
        'txtHoursEarned1
        '
        Me.txtHoursEarned1.Location = New System.Drawing.Point(432, 466)
        Me.txtHoursEarned1.Name = "txtHoursEarned1"
        Me.txtHoursEarned1.Size = New System.Drawing.Size(50, 20)
        Me.txtHoursEarned1.TabIndex = 420
        '
        'txtCGPA2
        '
        Me.txtCGPA2.Location = New System.Drawing.Point(362, 492)
        Me.txtCGPA2.Name = "txtCGPA2"
        Me.txtCGPA2.Size = New System.Drawing.Size(50, 20)
        Me.txtCGPA2.TabIndex = 428
        '
        'txtCGPA1
        '
        Me.txtCGPA1.Location = New System.Drawing.Point(362, 467)
        Me.txtCGPA1.Name = "txtCGPA1"
        Me.txtCGPA1.Size = New System.Drawing.Size(50, 20)
        Me.txtCGPA1.TabIndex = 419
        '
        'txtCName2
        '
        Me.txtCName2.Location = New System.Drawing.Point(16, 493)
        Me.txtCName2.Name = "txtCName2"
        Me.txtCName2.Size = New System.Drawing.Size(182, 20)
        Me.txtCName2.TabIndex = 425
        '
        'txtCName1
        '
        Me.txtCName1.Location = New System.Drawing.Point(16, 467)
        Me.txtCName1.Name = "txtCName1"
        Me.txtCName1.Size = New System.Drawing.Size(182, 20)
        Me.txtCName1.TabIndex = 416
        '
        'txtTSEDate
        '
        Me.txtTSEDate.Location = New System.Drawing.Point(6, 250)
        Me.txtTSEDate.Name = "txtTSEDate"
        Me.txtTSEDate.Size = New System.Drawing.Size(70, 20)
        Me.txtTSEDate.TabIndex = 401
        '
        'txtFYears
        '
        Me.txtFYears.Location = New System.Drawing.Point(156, 421)
        Me.txtFYears.Name = "txtFYears"
        Me.txtFYears.Size = New System.Drawing.Size(22, 20)
        Me.txtFYears.TabIndex = 25
        '
        'txtLCity
        '
        Me.txtLCity.Location = New System.Drawing.Point(369, 190)
        Me.txtLCity.Name = "txtLCity"
        Me.txtLCity.Size = New System.Drawing.Size(273, 20)
        Me.txtLCity.TabIndex = 18
        '
        'txtLAddress
        '
        Me.txtLAddress.Location = New System.Drawing.Point(369, 164)
        Me.txtLAddress.Name = "txtLAddress"
        Me.txtLAddress.Size = New System.Drawing.Size(273, 20)
        Me.txtLAddress.TabIndex = 17
        '
        'txtFCity
        '
        Me.txtFCity.Location = New System.Drawing.Point(51, 343)
        Me.txtFCity.Name = "txtFCity"
        Me.txtFCity.Size = New System.Drawing.Size(273, 20)
        Me.txtFCity.TabIndex = 22
        '
        'txtTOEFLDate
        '
        Me.txtTOEFLDate.Location = New System.Drawing.Point(6, 217)
        Me.txtTOEFLDate.Name = "txtTOEFLDate"
        Me.txtTOEFLDate.Size = New System.Drawing.Size(70, 20)
        Me.txtTOEFLDate.TabIndex = 399
        '
        'cbxOrigin
        '
        Me.cbxOrigin.FormattingEnabled = True
        Me.cbxOrigin.Items.AddRange(New Object() {"Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas, The", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Brazil", "Brunei ", "Bulgaria", "Burkina Faso", "Burma", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Central African Republic", "Chad", "Chile", "China", "Colombia", "Comoros", "Congo, Democratic Republic of the", "Congo, Republic of the", "Costa Rica", "Cote d'Ivoire", "Croatia", "Cuba", "Curacao", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Fiji", "Finland", "France", "Gabon", "Gambia, The", "Georgia", "Germany", "Ghana", "Greece", "Grenada", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Holy See", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, North", "Korea, South", "Kosovo", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Mauritania", "Mauritius", "Mexico", "Micronesia", "Moldova", "Monaco", "Mongolia", "Montenegro", "Morocco", "Mozambique", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Zealand", "Nicaragua", "Niger", "Nigeria", "North Korea", "Norway", "Oman", "Pakistan", "Palau", "Palestinian Territories", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Poland", "Portugal", "Qatar", "Romania", "Russia", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa ", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone", "Singapore", "Sint Maarten", "Slovakia", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Korea", "South Sudan", "Spain ", "Sri Lanka", "Sudan", "Suriname", "Swaziland ", "Sweden", "Switzerland", "Syria", "Taiwan", "Tajikistan", "Tanzania", "Thailand ", "Timor-Leste", "Togo", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "Uruguay", "Uzbekistan", "Vanuatu", "Venezuela", "Vietnam", "Yemen", "Zambia", "Zimbabwe "})
        Me.cbxOrigin.Location = New System.Drawing.Point(365, 24)
        Me.cbxOrigin.Name = "cbxOrigin"
        Me.cbxOrigin.Size = New System.Drawing.Size(121, 21)
        Me.cbxOrigin.TabIndex = 8
        '
        'txtGMATTotal
        '
        Me.txtGMATTotal.Location = New System.Drawing.Point(159, 183)
        Me.txtGMATTotal.Name = "txtGMATTotal"
        Me.txtGMATTotal.Size = New System.Drawing.Size(35, 20)
        Me.txtGMATTotal.TabIndex = 398
        '
        'txtTSETotal
        '
        Me.txtTSETotal.Location = New System.Drawing.Point(160, 250)
        Me.txtTSETotal.Name = "txtTSETotal"
        Me.txtTSETotal.Size = New System.Drawing.Size(34, 20)
        Me.txtTSETotal.TabIndex = 402
        '
        'txtCurrentPhone
        '
        Me.txtCurrentPhone.Location = New System.Drawing.Point(758, 163)
        Me.txtCurrentPhone.Mask = "(999) 000-0000"
        Me.txtCurrentPhone.Name = "txtCurrentPhone"
        Me.txtCurrentPhone.Size = New System.Drawing.Size(100, 20)
        Me.txtCurrentPhone.TabIndex = 27
        '
        'txtBirthday1
        '
        Me.txtBirthday1.Location = New System.Drawing.Point(62, 110)
        Me.txtBirthday1.Name = "txtBirthday1"
        Me.txtBirthday1.Size = New System.Drawing.Size(71, 20)
        Me.txtBirthday1.TabIndex = 7
        '
        'txtSSN
        '
        Me.txtSSN.Location = New System.Drawing.Point(279, 23)
        Me.txtSSN.Name = "txtSSN"
        Me.txtSSN.Size = New System.Drawing.Size(71, 20)
        Me.txtSSN.TabIndex = 6
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(758, 236)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(100, 20)
        Me.txtEmail.TabIndex = 31
        '
        'txtTOEFLTotal
        '
        Me.txtTOEFLTotal.Location = New System.Drawing.Point(160, 217)
        Me.txtTOEFLTotal.Name = "txtTOEFLTotal"
        Me.txtTOEFLTotal.Size = New System.Drawing.Size(34, 20)
        Me.txtTOEFLTotal.TabIndex = 400
        '
        'tabApplication
        '
        Me.tabApplication.Controls.Add(Me.tabPersonalInfo)
        Me.tabApplication.Controls.Add(Me.chbGraduated2)
        Me.tabApplication.Controls.Add(Me.TabPage1)
        Me.tabApplication.Location = New System.Drawing.Point(21, 27)
        Me.tabApplication.Name = "tabApplication"
        Me.tabApplication.SelectedIndex = 0
        Me.tabApplication.Size = New System.Drawing.Size(872, 568)
        Me.tabApplication.TabIndex = 4
        '
        'tabPersonalInfo
        '
        Me.tabPersonalInfo.Controls.Add(Me.Label78)
        Me.tabPersonalInfo.Controls.Add(Me.DeleteButton)
        Me.tabPersonalInfo.Controls.Add(Me.UpdateButton)
        Me.tabPersonalInfo.Controls.Add(Me.SearchButton)
        Me.tabPersonalInfo.Controls.Add(Me.DataGridView1)
        Me.tabPersonalInfo.Controls.Add(Me.Label51)
        Me.tabPersonalInfo.Controls.Add(Me.Label47)
        Me.tabPersonalInfo.Controls.Add(Me.chbxHisorLatin)
        Me.tabPersonalInfo.Controls.Add(Me.lblBirthdayFormat)
        Me.tabPersonalInfo.Controls.Add(Me.cbxFState)
        Me.tabPersonalInfo.Controls.Add(Me.cbxLState)
        Me.tabPersonalInfo.Controls.Add(Me.cbxPState)
        Me.tabPersonalInfo.Controls.Add(Me.txtPZipCode)
        Me.tabPersonalInfo.Controls.Add(Me.txtLZipCode)
        Me.tabPersonalInfo.Controls.Add(Me.txtFZipCode)
        Me.tabPersonalInfo.Controls.Add(Me.txtWorkPhone)
        Me.tabPersonalInfo.Controls.Add(Me.txtCurrentPhone)
        Me.tabPersonalInfo.Controls.Add(Me.txtBirthday1)
        Me.tabPersonalInfo.Controls.Add(Me.txtSSN)
        Me.tabPersonalInfo.Controls.Add(Me.cbxOrigin)
        Me.tabPersonalInfo.Controls.Add(Me.txtEmail)
        Me.tabPersonalInfo.Controls.Add(Me.txtFYears)
        Me.tabPersonalInfo.Controls.Add(Me.txtLCity)
        Me.tabPersonalInfo.Controls.Add(Me.txtLAddress)
        Me.tabPersonalInfo.Controls.Add(Me.txtFCity)
        Me.tabPersonalInfo.Controls.Add(Me.txtFAddress)
        Me.tabPersonalInfo.Controls.Add(Me.txtPYears)
        Me.tabPersonalInfo.Controls.Add(Me.txtPCity)
        Me.tabPersonalInfo.Controls.Add(Me.txtPAddress)
        Me.tabPersonalInfo.Controls.Add(Me.txtFirstName)
        Me.tabPersonalInfo.Controls.Add(Me.txtMiddleName)
        Me.tabPersonalInfo.Controls.Add(Me.txtLastName)
        Me.tabPersonalInfo.Controls.Add(Me.Label72)
        Me.tabPersonalInfo.Controls.Add(Me.cbxCitizenship)
        Me.tabPersonalInfo.Controls.Add(Me.cbxGender)
        Me.tabPersonalInfo.Controls.Add(Me.Label66)
        Me.tabPersonalInfo.Controls.Add(Me.Label3)
        Me.tabPersonalInfo.Controls.Add(Me.Label21)
        Me.tabPersonalInfo.Controls.Add(Me.Label65)
        Me.tabPersonalInfo.Controls.Add(Me.Label50)
        Me.tabPersonalInfo.Controls.Add(Me.Label46)
        Me.tabPersonalInfo.Controls.Add(Me.Label16)
        Me.tabPersonalInfo.Controls.Add(Me.Label17)
        Me.tabPersonalInfo.Controls.Add(Me.Label18)
        Me.tabPersonalInfo.Controls.Add(Me.Label19)
        Me.tabPersonalInfo.Controls.Add(Me.Label20)
        Me.tabPersonalInfo.Controls.Add(Me.chkResident)
        Me.tabPersonalInfo.Controls.Add(Me.Label12)
        Me.tabPersonalInfo.Controls.Add(Me.Label13)
        Me.tabPersonalInfo.Controls.Add(Me.Label14)
        Me.tabPersonalInfo.Controls.Add(Me.Label15)
        Me.tabPersonalInfo.Controls.Add(Me.Label11)
        Me.tabPersonalInfo.Controls.Add(Me.Label10)
        Me.tabPersonalInfo.Controls.Add(Me.Label9)
        Me.tabPersonalInfo.Controls.Add(Me.Label8)
        Me.tabPersonalInfo.Controls.Add(Me.Label7)
        Me.tabPersonalInfo.Controls.Add(Me.Label6)
        Me.tabPersonalInfo.Controls.Add(Me.Label5)
        Me.tabPersonalInfo.Controls.Add(Me.Label49)
        Me.tabPersonalInfo.Controls.Add(Me.Label48)
        Me.tabPersonalInfo.Controls.Add(Me.cbxEthnic)
        Me.tabPersonalInfo.Controls.Add(Me.Label1)
        Me.tabPersonalInfo.Controls.Add(Me.Label4)
        Me.tabPersonalInfo.Controls.Add(Me.lblDOB)
        Me.tabPersonalInfo.Controls.Add(Me.lblSSN)
        Me.tabPersonalInfo.Controls.Add(Me.lblName)
        Me.tabPersonalInfo.Controls.Add(Me.lblMiddleName)
        Me.tabPersonalInfo.Controls.Add(Me.lblFirstName)
        Me.tabPersonalInfo.Controls.Add(Me.lblLastName)
        Me.tabPersonalInfo.Location = New System.Drawing.Point(4, 22)
        Me.tabPersonalInfo.Name = "tabPersonalInfo"
        Me.tabPersonalInfo.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPersonalInfo.Size = New System.Drawing.Size(864, 542)
        Me.tabPersonalInfo.TabIndex = 0
        Me.tabPersonalInfo.Text = "Admission"
        Me.tabPersonalInfo.UseVisualStyleBackColor = True
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Location = New System.Drawing.Point(129, 511)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(0, 13)
        Me.Label78.TabIndex = 461
        '
        'DeleteButton
        '
        Me.DeleteButton.Location = New System.Drawing.Point(18, 506)
        Me.DeleteButton.Name = "DeleteButton"
        Me.DeleteButton.Size = New System.Drawing.Size(75, 23)
        Me.DeleteButton.TabIndex = 456
        Me.DeleteButton.Text = "Delete"
        Me.ToolTip1.SetToolTip(Me.DeleteButton, "Enter Student SSN in SSN textbox then press Delete")
        Me.DeleteButton.UseVisualStyleBackColor = True
        '
        'UpdateButton
        '
        Me.UpdateButton.Location = New System.Drawing.Point(260, 506)
        Me.UpdateButton.Name = "UpdateButton"
        Me.UpdateButton.Size = New System.Drawing.Size(75, 23)
        Me.UpdateButton.TabIndex = 455
        Me.UpdateButton.Text = "Update"
        Me.ToolTip1.SetToolTip(Me.UpdateButton, "Search for Student first than update appropriate fields after press Update")
        Me.UpdateButton.UseVisualStyleBackColor = True
        '
        'SearchButton
        '
        Me.SearchButton.Location = New System.Drawing.Point(135, 506)
        Me.SearchButton.Name = "SearchButton"
        Me.SearchButton.Size = New System.Drawing.Size(75, 23)
        Me.SearchButton.TabIndex = 454
        Me.SearchButton.Text = "Search"
        Me.ToolTip1.SetToolTip(Me.SearchButton, "Enter Last Name or SSN into appropriate textbox, to search the database")
        Me.SearchButton.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(349, 301)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(509, 235)
        Me.DataGridView1.TabIndex = 453
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(257, 73)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(96, 13)
        Me.Label51.TabIndex = 322
        Me.Label51.Text = "enter in Passport #"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(215, 53)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(148, 13)
        Me.Label47.TabIndex = 321
        Me.Label47.Text = "**If student is an International "
        '
        'lblBirthdayFormat
        '
        Me.lblBirthdayFormat.AutoSize = True
        Me.lblBirthdayFormat.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBirthdayFormat.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblBirthdayFormat.Location = New System.Drawing.Point(62, 129)
        Me.lblBirthdayFormat.Name = "lblBirthdayFormat"
        Me.lblBirthdayFormat.Size = New System.Drawing.Size(60, 10)
        Me.lblBirthdayFormat.TabIndex = 316
        Me.lblBirthdayFormat.Text = "YYYY-MM-DD"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(329, 191)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(24, 13)
        Me.Label18.TabIndex = 220
        Me.Label18.Text = "City"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(328, 166)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(35, 13)
        Me.Label19.TabIndex = 219
        Me.Label19.Text = "Street"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(328, 149)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(84, 13)
        Me.Label20.TabIndex = 218
        Me.Label20.Text = "Mailing Address:"
        '
        'chkResident
        '
        Me.chkResident.AutoSize = True
        Me.chkResident.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkResident.Location = New System.Drawing.Point(208, 424)
        Me.chkResident.Name = "chkResident"
        Me.chkResident.Size = New System.Drawing.Size(115, 17)
        Me.chkResident.TabIndex = 26
        Me.chkResident.Text = "Arkansas Resident"
        Me.chkResident.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(13, 399)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(22, 13)
        Me.Label12.TabIndex = 227
        Me.Label12.Text = "Zip"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(11, 372)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(32, 13)
        Me.Label13.TabIndex = 226
        Me.Label13.Text = "State"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(11, 344)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(24, 13)
        Me.Label14.TabIndex = 225
        Me.Label14.Text = "City"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(10, 319)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(35, 13)
        Me.Label15.TabIndex = 224
        Me.Label15.Text = "Street"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(10, 301)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(83, 13)
        Me.Label11.TabIndex = 223
        Me.Label11.Text = "Former Address:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(10, 275)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(137, 13)
        Me.Label10.TabIndex = 217
        Me.Label10.Text = "Years at the above address"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(10, 246)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(22, 13)
        Me.Label9.TabIndex = 216
        Me.Label9.Text = "Zip"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(8, 219)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(32, 13)
        Me.Label8.TabIndex = 215
        Me.Label8.Text = "State"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(8, 191)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(24, 13)
        Me.Label7.TabIndex = 214
        Me.Label7.Text = "City"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(7, 166)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(35, 13)
        Me.Label6.TabIndex = 213
        Me.Label6.Text = "Street"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 149)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(102, 13)
        Me.Label5.TabIndex = 212
        Me.Label5.Text = "Permanent Address:"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(163, 113)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(60, 13)
        Me.Label49.TabIndex = 211
        Me.Label49.Text = "Citizenship:"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(362, 89)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(45, 13)
        Me.Label48.TabIndex = 210
        Me.Label48.Text = "Gender:"
        '
        'cbxEthnic
        '
        Me.cbxEthnic.FormattingEnabled = True
        Me.cbxEthnic.Items.AddRange(New Object() {"Alaskan Native or American Indian", "Black, Non-Hispanic", "Asian or Pacific Islander", "White, Non-Hispanic", "Hispanic"})
        Me.cbxEthnic.Location = New System.Drawing.Point(365, 65)
        Me.cbxEthnic.Name = "cbxEthnic"
        Me.cbxEthnic.Size = New System.Drawing.Size(121, 21)
        Me.cbxEthnic.TabIndex = 9
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(362, 49)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(84, 13)
        Me.Label1.TabIndex = 209
        Me.Label1.Text = "Race / Ethnicity"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(362, 7)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(70, 13)
        Me.Label4.TabIndex = 208
        Me.Label4.Text = "Place of Birth"
        '
        'lblDOB
        '
        Me.lblDOB.AutoSize = True
        Me.lblDOB.Location = New System.Drawing.Point(11, 116)
        Me.lblDOB.Name = "lblDOB"
        Me.lblDOB.Size = New System.Drawing.Size(30, 13)
        Me.lblDOB.TabIndex = 207
        Me.lblDOB.Text = "DOB"
        '
        'lblSSN
        '
        Me.lblSSN.AutoSize = True
        Me.lblSSN.Location = New System.Drawing.Point(240, 32)
        Me.lblSSN.Name = "lblSSN"
        Me.lblSSN.Size = New System.Drawing.Size(33, 13)
        Me.lblSSN.TabIndex = 206
        Me.lblSSN.Text = "SSN*"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(6, 7)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(38, 13)
        Me.lblName.TabIndex = 200
        Me.lblName.Text = "Name:"
        '
        'lblMiddleName
        '
        Me.lblMiddleName.AutoSize = True
        Me.lblMiddleName.Location = New System.Drawing.Point(6, 79)
        Me.lblMiddleName.Name = "lblMiddleName"
        Me.lblMiddleName.Size = New System.Drawing.Size(38, 13)
        Me.lblMiddleName.TabIndex = 203
        Me.lblMiddleName.Text = "Middle"
        '
        'lblFirstName
        '
        Me.lblFirstName.AutoSize = True
        Me.lblFirstName.Location = New System.Drawing.Point(6, 53)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(26, 13)
        Me.lblFirstName.TabIndex = 202
        Me.lblFirstName.Text = "First"
        '
        'lblLastName
        '
        Me.lblLastName.AutoSize = True
        Me.lblLastName.Location = New System.Drawing.Point(7, 26)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(31, 13)
        Me.lblLastName.TabIndex = 201
        Me.lblLastName.Text = "Last*"
        '
        'chbGraduated2
        '
        Me.chbGraduated2.Controls.Add(Me.Label52)
        Me.chbGraduated2.Controls.Add(Me.cbxConcentration)
        Me.chbGraduated2.Controls.Add(Me.chbHonors2)
        Me.chbGraduated2.Controls.Add(Me.chbHonors1)
        Me.chbGraduated2.Controls.Add(Me.Label64)
        Me.chbGraduated2.Controls.Add(Me.Label62)
        Me.chbGraduated2.Controls.Add(Me.Label61)
        Me.chbGraduated2.Controls.Add(Me.ckbGraduated2)
        Me.chbGraduated2.Controls.Add(Me.ckbGraduated1)
        Me.chbGraduated2.Controls.Add(Me.InsertButton)
        Me.chbGraduated2.Controls.Add(Me.Label42)
        Me.chbGraduated2.Controls.Add(Me.Label39)
        Me.chbGraduated2.Controls.Add(Me.Label38)
        Me.chbGraduated2.Controls.Add(Me.txtCFrom1)
        Me.chbGraduated2.Controls.Add(Me.txtCFrom2)
        Me.chbGraduated2.Controls.Add(Me.txtCTo1)
        Me.chbGraduated2.Controls.Add(Me.txtCTo2)
        Me.chbGraduated2.Controls.Add(Me.txtDegree2)
        Me.chbGraduated2.Controls.Add(Me.txtDegree1)
        Me.chbGraduated2.Controls.Add(Me.txtHoursEarned2)
        Me.chbGraduated2.Controls.Add(Me.txtHoursEarned1)
        Me.chbGraduated2.Controls.Add(Me.txtCGPA2)
        Me.chbGraduated2.Controls.Add(Me.txtCGPA1)
        Me.chbGraduated2.Controls.Add(Me.txtCName2)
        Me.chbGraduated2.Controls.Add(Me.txtCName1)
        Me.chbGraduated2.Controls.Add(Me.txtTSEDate)
        Me.chbGraduated2.Controls.Add(Me.txtTOEFLDate)
        Me.chbGraduated2.Controls.Add(Me.txtGMATTotal)
        Me.chbGraduated2.Controls.Add(Me.txtTSETotal)
        Me.chbGraduated2.Controls.Add(Me.txtTOEFLTotal)
        Me.chbGraduated2.Controls.Add(Me.txtGMATDate)
        Me.chbGraduated2.Controls.Add(Me.txtEnrolled_When)
        Me.chbGraduated2.Controls.Add(Me.txtBefore_when)
        Me.chbGraduated2.Controls.Add(Me.txtRequestYear)
        Me.chbGraduated2.Controls.Add(Me.Label60)
        Me.chbGraduated2.Controls.Add(Me.Label59)
        Me.chbGraduated2.Controls.Add(Me.Label58)
        Me.chbGraduated2.Controls.Add(Me.Label57)
        Me.chbGraduated2.Controls.Add(Me.Label56)
        Me.chbGraduated2.Controls.Add(Me.Label55)
        Me.chbGraduated2.Controls.Add(Me.Label54)
        Me.chbGraduated2.Controls.Add(Me.Label53)
        Me.chbGraduated2.Controls.Add(Me.Label36)
        Me.chbGraduated2.Controls.Add(Me.Label43)
        Me.chbGraduated2.Controls.Add(Me.GroupBox1)
        Me.chbGraduated2.Controls.Add(Me.Label34)
        Me.chbGraduated2.Controls.Add(Me.Label24)
        Me.chbGraduated2.Controls.Add(Me.Label41)
        Me.chbGraduated2.Controls.Add(Me.Label40)
        Me.chbGraduated2.Controls.Add(Me.Label35)
        Me.chbGraduated2.Controls.Add(Me.Label33)
        Me.chbGraduated2.Controls.Add(Me.Label30)
        Me.chbGraduated2.Controls.Add(Me.Label29)
        Me.chbGraduated2.Controls.Add(Me.Label32)
        Me.chbGraduated2.Controls.Add(Me.Label28)
        Me.chbGraduated2.Controls.Add(Me.Label2)
        Me.chbGraduated2.Controls.Add(Me.cbxReqProgram)
        Me.chbGraduated2.Controls.Add(Me.Label31)
        Me.chbGraduated2.Controls.Add(Me.Label67)
        Me.chbGraduated2.Controls.Add(Me.cbxStanding)
        Me.chbGraduated2.Controls.Add(Me.lblSession)
        Me.chbGraduated2.Controls.Add(Me.cbxSession)
        Me.chbGraduated2.Controls.Add(Me.Label27)
        Me.chbGraduated2.Controls.Add(Me.Label26)
        Me.chbGraduated2.Controls.Add(Me.chkEnrolled)
        Me.chbGraduated2.Controls.Add(Me.Label25)
        Me.chbGraduated2.Controls.Add(Me.chkBefore)
        Me.chbGraduated2.Controls.Add(Me.Label23)
        Me.chbGraduated2.Controls.Add(Me.Label22)
        Me.chbGraduated2.Location = New System.Drawing.Point(4, 22)
        Me.chbGraduated2.Name = "chbGraduated2"
        Me.chbGraduated2.Padding = New System.Windows.Forms.Padding(3)
        Me.chbGraduated2.Size = New System.Drawing.Size(864, 542)
        Me.chbGraduated2.TabIndex = 1
        Me.chbGraduated2.Text = "Education & Credentials"
        Me.chbGraduated2.UseVisualStyleBackColor = True
        '
        'txtGMATDate
        '
        Me.txtGMATDate.Location = New System.Drawing.Point(6, 182)
        Me.txtGMATDate.Name = "txtGMATDate"
        Me.txtGMATDate.Size = New System.Drawing.Size(70, 20)
        Me.txtGMATDate.TabIndex = 397
        '
        'txtEnrolled_When
        '
        Me.txtEnrolled_When.Location = New System.Drawing.Point(487, 59)
        Me.txtEnrolled_When.Name = "txtEnrolled_When"
        Me.txtEnrolled_When.Size = New System.Drawing.Size(70, 20)
        Me.txtEnrolled_When.TabIndex = 38
        '
        'txtBefore_when
        '
        Me.txtBefore_when.Location = New System.Drawing.Point(487, 14)
        Me.txtBefore_when.Name = "txtBefore_when"
        Me.txtBefore_when.Size = New System.Drawing.Size(70, 20)
        Me.txtBefore_when.TabIndex = 36
        '
        'txtRequestYear
        '
        Me.txtRequestYear.Location = New System.Drawing.Point(94, 23)
        Me.txtRequestYear.Name = "txtRequestYear"
        Me.txtRequestYear.Size = New System.Drawing.Size(48, 20)
        Me.txtRequestYear.TabIndex = 33
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(499, 451)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(45, 13)
        Me.Label60.TabIndex = 441
        Me.Label60.Text = "Degree:"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(415, 451)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(75, 13)
        Me.Label59.TabIndex = 440
        Me.Label59.Text = "Hours Earned:"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(423, 438)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(51, 13)
        Me.Label58.TabIndex = 439
        Me.Label58.Text = "Semester"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(359, 451)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(32, 13)
        Me.Label57.TabIndex = 438
        Me.Label57.Text = "GPA:"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(203, 438)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(84, 13)
        Me.Label56.TabIndex = 435
        Me.Label56.Text = "Dates Attended:"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(283, 451)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(33, 13)
        Me.Label55.TabIndex = 437
        Me.Label55.Text = "From:"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(203, 451)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(23, 13)
        Me.Label54.TabIndex = 436
        Me.Label54.Text = "To:"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(13, 451)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(76, 13)
        Me.Label53.TabIndex = 434
        Me.Label53.Text = "College Name:"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(382, 162)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(123, 13)
        Me.Label36.TabIndex = 415
        Me.Label36.Text = "considered COMPLETE:"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(382, 149)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(336, 13)
        Me.Label43.TabIndex = 414
        Me.Label43.Text = "The following materials MUST be be submitted BEFORE application is"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkAppForm)
        Me.GroupBox1.Controls.Add(Me.Label63)
        Me.GroupBox1.Controls.Add(Me.chkAppFeePaid)
        Me.GroupBox1.Controls.Add(Me.chkResume)
        Me.GroupBox1.Controls.Add(Me.chkLOR)
        Me.GroupBox1.Controls.Add(Me.chkTranscript)
        Me.GroupBox1.Controls.Add(Me.chkEssay)
        Me.GroupBox1.Controls.Add(Me.chkGMATScore)
        Me.GroupBox1.Controls.Add(Me.chkEducation)
        Me.GroupBox1.Controls.Add(Me.chkFinancial)
        Me.GroupBox1.Controls.Add(Me.chkTOEFL)
        Me.GroupBox1.Location = New System.Drawing.Point(380, 178)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(374, 219)
        Me.GroupBox1.TabIndex = 413
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Required Documents"
        '
        'chkAppForm
        '
        Me.chkAppForm.AutoSize = True
        Me.chkAppForm.Location = New System.Drawing.Point(9, 43)
        Me.chkAppForm.Name = "chkAppForm"
        Me.chkAppForm.Size = New System.Drawing.Size(176, 17)
        Me.chkAppForm.TabIndex = 269
        Me.chkAppForm.Text = "Walton College Applicaion Form"
        Me.chkAppForm.UseVisualStyleBackColor = True
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label63.Location = New System.Drawing.Point(6, 19)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(60, 13)
        Me.Label63.TabIndex = 265
        Me.Label63.Text = "Check List:"
        '
        'chkAppFeePaid
        '
        Me.chkAppFeePaid.AutoSize = True
        Me.chkAppFeePaid.Location = New System.Drawing.Point(9, 60)
        Me.chkAppFeePaid.Name = "chkAppFeePaid"
        Me.chkAppFeePaid.Size = New System.Drawing.Size(99, 17)
        Me.chkAppFeePaid.TabIndex = 266
        Me.chkAppFeePaid.Text = "Application Fee"
        Me.chkAppFeePaid.UseVisualStyleBackColor = True
        '
        'chkResume
        '
        Me.chkResume.AutoSize = True
        Me.chkResume.Location = New System.Drawing.Point(9, 77)
        Me.chkResume.Name = "chkResume"
        Me.chkResume.Size = New System.Drawing.Size(65, 17)
        Me.chkResume.TabIndex = 267
        Me.chkResume.Text = "Resume"
        Me.chkResume.UseVisualStyleBackColor = True
        '
        'chkLOR
        '
        Me.chkLOR.AutoSize = True
        Me.chkLOR.Location = New System.Drawing.Point(9, 94)
        Me.chkLOR.Name = "chkLOR"
        Me.chkLOR.Size = New System.Drawing.Size(187, 17)
        Me.chkLOR.TabIndex = 270
        Me.chkLOR.Text = "Three Letters of Recommendation"
        Me.chkLOR.UseVisualStyleBackColor = True
        '
        'chkTranscript
        '
        Me.chkTranscript.AutoSize = True
        Me.chkTranscript.Location = New System.Drawing.Point(9, 111)
        Me.chkTranscript.Name = "chkTranscript"
        Me.chkTranscript.Size = New System.Drawing.Size(257, 17)
        Me.chkTranscript.TabIndex = 271
        Me.chkTranscript.Text = "Official Transcripts from each University attended"
        Me.chkTranscript.UseVisualStyleBackColor = True
        '
        'chkEssay
        '
        Me.chkEssay.AutoSize = True
        Me.chkEssay.Location = New System.Drawing.Point(9, 128)
        Me.chkEssay.Name = "chkEssay"
        Me.chkEssay.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkEssay.Size = New System.Drawing.Size(104, 17)
        Me.chkEssay.TabIndex = 268
        Me.chkEssay.Text = "Essay Questions"
        Me.chkEssay.UseVisualStyleBackColor = True
        '
        'chkGMATScore
        '
        Me.chkGMATScore.AutoSize = True
        Me.chkGMATScore.Location = New System.Drawing.Point(9, 145)
        Me.chkGMATScore.Name = "chkGMATScore"
        Me.chkGMATScore.Size = New System.Drawing.Size(116, 17)
        Me.chkGMATScore.TabIndex = 276
        Me.chkGMATScore.Text = "GMAT/GRE Score"
        Me.chkGMATScore.UseVisualStyleBackColor = True
        '
        'chkEducation
        '
        Me.chkEducation.AutoSize = True
        Me.chkEducation.Location = New System.Drawing.Point(9, 162)
        Me.chkEducation.Name = "chkEducation"
        Me.chkEducation.Size = New System.Drawing.Size(328, 17)
        Me.chkEducation.TabIndex = 272
        Me.chkEducation.Text = "Summary of educational experience (International Students only)"
        Me.chkEducation.UseVisualStyleBackColor = True
        '
        'chkFinancial
        '
        Me.chkFinancial.AutoSize = True
        Me.chkFinancial.Location = New System.Drawing.Point(9, 179)
        Me.chkFinancial.Name = "chkFinancial"
        Me.chkFinancial.Size = New System.Drawing.Size(371, 17)
        Me.chkFinancial.TabIndex = 273
        Me.chkFinancial.Text = "Supplemental and Financial Information Form (International Students only)"
        Me.chkFinancial.UseVisualStyleBackColor = True
        '
        'chkTOEFL
        '
        Me.chkTOEFL.AutoSize = True
        Me.chkTOEFL.Location = New System.Drawing.Point(9, 196)
        Me.chkTOEFL.Name = "chkTOEFL"
        Me.chkTOEFL.Size = New System.Drawing.Size(194, 17)
        Me.chkTOEFL.TabIndex = 274
        Me.chkTOEFL.Text = "TOEFL (International Students only)"
        Me.chkTOEFL.UseVisualStyleBackColor = True
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label34.Location = New System.Drawing.Point(4, 273)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(60, 10)
        Me.Label34.TabIndex = 412
        Me.Label34.Text = "YYYY-MM-DD"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(6, 162)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(120, 13)
        Me.Label24.TabIndex = 404
        Me.Label24.Text = "(Taken or to be Taken):"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(197, 253)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(55, 13)
        Me.Label41.TabIndex = 411
        Me.Label41.Text = "TSE Total"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(197, 221)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(68, 13)
        Me.Label40.TabIndex = 409
        Me.Label40.Text = "TOEFL Total"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(197, 186)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(65, 13)
        Me.Label35.TabIndex = 407
        Me.Label35.Text = "GMAT Total"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(156, 157)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(43, 13)
        Me.Label33.TabIndex = 405
        Me.Label33.Text = "Scores:"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(82, 253)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(30, 13)
        Me.Label30.TabIndex = 410
        Me.Label30.Text = "GRE"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(82, 220)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(41, 13)
        Me.Label29.TabIndex = 408
        Me.Label29.Text = "TOEFL"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(9, 149)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(59, 13)
        Me.Label32.TabIndex = 403
        Me.Label32.Text = "Test Dates"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(82, 186)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(38, 13)
        Me.Label28.TabIndex = 406
        Me.Label28.Text = "GMAT"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 88)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 13)
        Me.Label2.TabIndex = 324
        Me.Label2.Text = "Program:"
        '
        'cbxReqProgram
        '
        Me.cbxReqProgram.FormattingEnabled = True
        Me.cbxReqProgram.Items.AddRange(New Object() {"MIS", "PMIS", "ERP", "BI"})
        Me.cbxReqProgram.Location = New System.Drawing.Point(9, 104)
        Me.cbxReqProgram.Name = "cbxReqProgram"
        Me.cbxReqProgram.Size = New System.Drawing.Size(133, 21)
        Me.cbxReqProgram.TabIndex = 323
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label31.Location = New System.Drawing.Point(485, 84)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(60, 10)
        Me.Label31.TabIndex = 317
        Me.Label31.Text = "YYYY-MM-DD"
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Location = New System.Drawing.Point(6, 128)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(775, 13)
        Me.Label67.TabIndex = 313
        Me.Label67.Text = "_________________________________________________________________________________" &
    "_______________________________________________"
        '
        'cbxStanding
        '
        Me.cbxStanding.FormattingEnabled = True
        Me.cbxStanding.Items.AddRange(New Object() {"Graduate", "Undergraduate", "Other"})
        Me.cbxStanding.Location = New System.Drawing.Point(424, 109)
        Me.cbxStanding.Name = "cbxStanding"
        Me.cbxStanding.Size = New System.Drawing.Size(133, 21)
        Me.cbxStanding.TabIndex = 39
        '
        'lblSession
        '
        Me.lblSession.AutoSize = True
        Me.lblSession.Location = New System.Drawing.Point(6, 43)
        Me.lblSession.Name = "lblSession"
        Me.lblSession.Size = New System.Drawing.Size(47, 13)
        Me.lblSession.TabIndex = 238
        Me.lblSession.Text = "Session:"
        '
        'cbxSession
        '
        Me.cbxSession.FormattingEnabled = True
        Me.cbxSession.Items.AddRange(New Object() {"Spring", "Fall"})
        Me.cbxSession.Location = New System.Drawing.Point(9, 59)
        Me.cbxSession.Name = "cbxSession"
        Me.cbxSession.Size = New System.Drawing.Size(133, 21)
        Me.cbxSession.TabIndex = 34
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(442, 62)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(42, 13)
        Me.Label27.TabIndex = 242
        Me.Label27.Text = "When?"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(356, 112)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(56, 13)
        Me.Label26.TabIndex = 243
        Me.Label26.Text = "If enrolled:"
        '
        'chkEnrolled
        '
        Me.chkEnrolled.AutoSize = True
        Me.chkEnrolled.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkEnrolled.Location = New System.Drawing.Point(363, 61)
        Me.chkEnrolled.Name = "chkEnrolled"
        Me.chkEnrolled.Size = New System.Drawing.Size(70, 17)
        Me.chkEnrolled.TabIndex = 241
        Me.chkEnrolled.Text = "Enrolled?"
        Me.chkEnrolled.UseVisualStyleBackColor = True
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(441, 19)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(42, 13)
        Me.Label25.TabIndex = 240
        Me.Label25.Text = "When?"
        '
        'chkBefore
        '
        Me.chkBefore.AutoSize = True
        Me.chkBefore.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkBefore.Location = New System.Drawing.Point(270, 17)
        Me.chkBefore.Name = "chkBefore"
        Me.chkBefore.Size = New System.Drawing.Size(163, 17)
        Me.chkBefore.TabIndex = 239
        Me.chkBefore.Text = "Applied to the U of A before?"
        Me.chkBefore.UseVisualStyleBackColor = True
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(6, 23)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(32, 13)
        Me.Label23.TabIndex = 237
        Me.Label23.Text = "Year:"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(4, 4)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(126, 13)
        Me.Label22.TabIndex = 236
        Me.Label22.Text = "Adminission Request For:"
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Label75)
        Me.TabPage1.Controls.Add(Me.Label74)
        Me.TabPage1.Controls.Add(Me.Label71)
        Me.TabPage1.Controls.Add(Me.Button1)
        Me.TabPage1.Controls.Add(Me.Label37)
        Me.TabPage1.Controls.Add(Me.Label45)
        Me.TabPage1.Controls.Add(Me.txtStudentID)
        Me.TabPage1.Controls.Add(Me.TxtSSNSearch)
        Me.TabPage1.Controls.Add(Me.CheckBox_admit)
        Me.TabPage1.Controls.Add(Me.Label44)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(864, 542)
        Me.TabPage1.TabIndex = 2
        Me.TabPage1.Text = "Committee Review"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Location = New System.Drawing.Point(36, 181)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(19, 13)
        Me.Label75.TabIndex = 459
        Me.Label75.Text = "2.)"
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Location = New System.Drawing.Point(36, 74)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(19, 13)
        Me.Label74.TabIndex = 458
        Me.Label74.Text = "1.)"
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Location = New System.Drawing.Point(69, 51)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(97, 13)
        Me.Label71.TabIndex = 456
        Me.Label71.Text = "Enter Student SSN"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(72, 277)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 455
        Me.Button1.Text = "Submit"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(69, 117)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(219, 13)
        Me.Label37.TabIndex = 411
        Me.Label37.Text = "Assign student a StudentID before submitting"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(69, 146)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(62, 13)
        Me.Label45.TabIndex = 410
        Me.Label45.Text = "Student ID*"
        '
        'txtStudentID
        '
        Me.txtStudentID.Location = New System.Drawing.Point(72, 174)
        Me.txtStudentID.Name = "txtStudentID"
        Me.txtStudentID.Size = New System.Drawing.Size(128, 20)
        Me.txtStudentID.TabIndex = 409
        '
        'TxtSSNSearch
        '
        Me.TxtSSNSearch.Location = New System.Drawing.Point(72, 67)
        Me.TxtSSNSearch.Name = "TxtSSNSearch"
        Me.TxtSSNSearch.Size = New System.Drawing.Size(128, 20)
        Me.TxtSSNSearch.TabIndex = 408
        '
        'CheckBox_admit
        '
        Me.CheckBox_admit.AutoSize = True
        Me.CheckBox_admit.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox_admit.Location = New System.Drawing.Point(72, 219)
        Me.CheckBox_admit.Name = "CheckBox_admit"
        Me.CheckBox_admit.Size = New System.Drawing.Size(92, 17)
        Me.CheckBox_admit.TabIndex = 407
        Me.CheckBox_admit.Text = "Admit Student"
        Me.CheckBox_admit.UseVisualStyleBackColor = True
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(69, 24)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(361, 13)
        Me.Label44.TabIndex = 406
        Me.Label44.Text = "Determine if students meets school standards then admit them as students. "
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'PrintDocument1
        '
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'ClearFieldsToolStripMenuItem
        '
        Me.ClearFieldsToolStripMenuItem.Name = "ClearFieldsToolStripMenuItem"
        Me.ClearFieldsToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.ClearFieldsToolStripMenuItem.Text = "Clear Fields"
        '
        'ReportToolStripMenuItem
        '
        Me.ReportToolStripMenuItem.Name = "ReportToolStripMenuItem"
        Me.ReportToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.ReportToolStripMenuItem.Text = "Report"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ReportToolStripMenuItem, Me.ClearFieldsToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(35, 20)
        Me.ToolStripMenuItem1.Text = "File"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.HelpToolStripMenuItem, Me.BackToWelcomeToolStripMenuItem, Me.ExitToolStripMenuItem1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(907, 24)
        Me.MenuStrip1.TabIndex = 5
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'BackToWelcomeToolStripMenuItem
        '
        Me.BackToWelcomeToolStripMenuItem.Name = "BackToWelcomeToolStripMenuItem"
        Me.BackToWelcomeToolStripMenuItem.Size = New System.Drawing.Size(102, 20)
        Me.BackToWelcomeToolStripMenuItem.Text = "Back To Welcome"
        '
        'ExitToolStripMenuItem1
        '
        Me.ExitToolStripMenuItem1.Name = "ExitToolStripMenuItem1"
        Me.ExitToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ExitToolStripMenuItem1.Text = "Exit"
        '
        'Advisors
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(907, 608)
        Me.Controls.Add(Me.tabApplication)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "Advisors"
        Me.Text = "Advisors"
        Me.tabApplication.ResumeLayout(False)
        Me.tabPersonalInfo.ResumeLayout(False)
        Me.tabPersonalInfo.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.chbGraduated2.ResumeLayout(False)
        Me.chbGraduated2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtPAddress As TextBox
    Friend WithEvents txtMiddleName As TextBox
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents Label72 As Label
    Friend WithEvents cbxCitizenship As ComboBox
    Friend WithEvents Label52 As Label
    Friend WithEvents cbxConcentration As ComboBox
    Friend WithEvents chbHonors2 As CheckBox
    Friend WithEvents chbHonors1 As CheckBox
    Friend WithEvents Label64 As Label
    Friend WithEvents txtFirstName As TextBox
    Friend WithEvents cbxGender As ComboBox
    Friend WithEvents Label66 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label65 As Label
    Friend WithEvents Label50 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label62 As Label
    Friend WithEvents Label61 As Label
    Friend WithEvents ckbGraduated2 As CheckBox
    Friend WithEvents ckbGraduated1 As CheckBox
    Friend WithEvents InsertButton As Button
    Friend WithEvents Label42 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents txtCFrom1 As TextBox
    Friend WithEvents txtCFrom2 As TextBox
    Friend WithEvents txtCTo1 As TextBox
    Friend WithEvents chbxHisorLatin As CheckBox
    Friend WithEvents cbxFState As ComboBox
    Friend WithEvents cbxLState As ComboBox
    Friend WithEvents cbxPState As ComboBox
    Friend WithEvents txtPZipCode As MaskedTextBox
    Friend WithEvents txtLZipCode As MaskedTextBox
    Friend WithEvents txtFZipCode As MaskedTextBox
    Friend WithEvents txtWorkPhone As MaskedTextBox
    Friend WithEvents txtPCity As TextBox
    Friend WithEvents txtCTo2 As TextBox
    Friend WithEvents txtFAddress As TextBox
    Friend WithEvents txtPYears As TextBox
    Friend WithEvents txtDegree2 As TextBox
    Friend WithEvents txtDegree1 As TextBox
    Friend WithEvents txtHoursEarned2 As TextBox
    Friend WithEvents txtHoursEarned1 As TextBox
    Friend WithEvents txtCGPA2 As TextBox
    Friend WithEvents txtCGPA1 As TextBox
    Friend WithEvents txtCName2 As TextBox
    Friend WithEvents txtCName1 As TextBox
    Friend WithEvents txtTSEDate As TextBox
    Friend WithEvents txtFYears As TextBox
    Friend WithEvents txtLCity As TextBox
    Friend WithEvents txtLAddress As TextBox
    Friend WithEvents txtFCity As TextBox
    Friend WithEvents txtTOEFLDate As TextBox
    Friend WithEvents cbxOrigin As ComboBox
    Friend WithEvents txtGMATTotal As TextBox
    Friend WithEvents txtTSETotal As TextBox
    Friend WithEvents txtCurrentPhone As MaskedTextBox
    Friend WithEvents txtBirthday1 As MaskedTextBox
    Friend WithEvents txtSSN As MaskedTextBox
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents txtTOEFLTotal As TextBox
    Friend WithEvents tabApplication As TabControl
    Friend WithEvents tabPersonalInfo As TabPage
    Friend WithEvents Label78 As Label
    Friend WithEvents DeleteButton As Button
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents UpdateButton As Button
    Friend WithEvents SearchButton As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label51 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents lblBirthdayFormat As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents chkResident As CheckBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents cbxEthnic As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblDOB As Label
    Friend WithEvents lblSSN As Label
    Friend WithEvents lblName As Label
    Friend WithEvents lblMiddleName As Label
    Friend WithEvents lblFirstName As Label
    Friend WithEvents lblLastName As Label
    Friend WithEvents chbGraduated2 As TabPage
    Friend WithEvents txtGMATDate As TextBox
    Friend WithEvents txtEnrolled_When As TextBox
    Friend WithEvents txtBefore_when As TextBox
    Friend WithEvents txtRequestYear As TextBox
    Friend WithEvents Label60 As Label
    Friend WithEvents Label59 As Label
    Friend WithEvents Label58 As Label
    Friend WithEvents Label57 As Label
    Friend WithEvents Label56 As Label
    Friend WithEvents Label55 As Label
    Friend WithEvents Label54 As Label
    Friend WithEvents Label53 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents chkAppForm As CheckBox
    Friend WithEvents Label63 As Label
    Friend WithEvents chkAppFeePaid As CheckBox
    Friend WithEvents chkResume As CheckBox
    Friend WithEvents chkLOR As CheckBox
    Friend WithEvents chkTranscript As CheckBox
    Friend WithEvents chkEssay As CheckBox
    Friend WithEvents chkGMATScore As CheckBox
    Friend WithEvents chkEducation As CheckBox
    Friend WithEvents chkFinancial As CheckBox
    Friend WithEvents chkTOEFL As CheckBox
    Friend WithEvents Label34 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents cbxReqProgram As ComboBox
    Friend WithEvents Label31 As Label
    Friend WithEvents Label67 As Label
    Friend WithEvents cbxStanding As ComboBox
    Friend WithEvents lblSession As Label
    Friend WithEvents cbxSession As ComboBox
    Friend WithEvents Label27 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents chkEnrolled As CheckBox
    Friend WithEvents Label25 As Label
    Friend WithEvents chkBefore As CheckBox
    Friend WithEvents Label23 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents Label75 As Label
    Friend WithEvents Label74 As Label
    Friend WithEvents Label71 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Label37 As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents txtStudentID As TextBox
    Friend WithEvents TxtSSNSearch As TextBox
    Friend WithEvents CheckBox_admit As CheckBox
    Friend WithEvents Label44 As Label
    Friend WithEvents ErrorProvider1 As ErrorProvider
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ReportToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClearFieldsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents PrintPreviewDialog1 As PrintPreviewDialog
    Friend WithEvents BackToWelcomeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem1 As ToolStripMenuItem
End Class
