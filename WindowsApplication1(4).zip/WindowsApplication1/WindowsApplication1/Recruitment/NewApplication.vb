﻿Imports System.Data.OleDb
Public Class NewApplication
    Dim ConnInfo As DBConnectionInfo = New DBConnectionInfo
    Dim ConnString As String = ConnInfo.GetConnString()

    'Connection Variable for the database
    Dim con As New OleDbConnection()
    Dim SSN As String
    Dim EmailAddr As String

    Private Sub FileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FileToolStripMenuItem.Click
        StudentHome.Show()
        Me.Hide()
    End Sub

    Private Sub SearchButton_Click(sender As Object, e As EventArgs) Handles SearchB.Click
        Dim StudID As Integer = IDTB.Text



        Try
            Dim Command As New OleDbCommand("SELECT FirstName, LastName, StudentID, Email, SSN FROM GradStudents WHERE StudentID ='" & StudID & "';", con)
            Dim Dr As OleDbDataReader

            'Open Connection String
            con.ConnectionString = ConnString
            con.Open()

            'Select the Records from the DB
            Dr = Command.ExecuteReader

            While Dr.Read()
                FNameL.Text = (Dr.GetString(0))
                LastNameL.Text = (Dr.GetString(1))
                IDL.Text = (Dr.GetString(2))
                EmailAddr = (Dr.GetString(3))
                SSN = (Dr.GetString(4))
                'Dim Var6 As String = (Dr.GetString(5))
                'Dim Var7 As String = (Dr.GetString(6))
                'Dim Var8 As String = (Dr.GetString(7))
                'Dim Var9 As String = (Dr.GetString(8))
                'Dim Var10 As String = (Dr.GetString(9))
                'Dim Var11 As String = (Dr.GetString(10))
                'Dim Var12 As String = (Dr.GetString(11))
                'Dim Var13 As String = (Dr.GetString(12))
                'Dim Var14 As String = (Dr.GetString(13))
                'Dim Var15 As String = (Dr.GetString(14))
                'Dim Var16 As String = (Dr.GetString(15))
                'Dim Var17 As String = (Dr.GetString(16))
                'Dim Var18 As String = (Dr.GetString(17))
            End While
            con.Close()

            FNameL.Visible = True
            LastNameL.Visible = True
            IDL.Visible = True
            ClearB.Visible = True
            PostB.Visible = True
            Header1L.Visible = True
            Header2L.Visible = True
            Header3L.Visible = True
            Emp1TB.Visible = True
            Emp2TB.Visible = True
            EmpL.Visible = True
            From1TB.Visible = True
            From2TB.Visible = True
            FromL.Visible = True
            To1TB.Visible = True
            To2TB.Visible = True
            Tol.Visible = True
            Position2TB.Visible = True
            PositionL.Visible = True
            Position1TB.Visible = True
            Cert1TB.Visible = True
            CertTB2.Visible = True
            CertL.Visible = True
            DateL.Visible = True
            Date1.Visible = True
            Date2.Visible = True
            Line1L.Visible = True
            Line2L.Visible = True
            ResumeTB.Visible = True
            Label1.Visible = True
            Label2.Visible = True
            Label4.Visible = True




        Catch ex As Exception
            'MessageBox.Show(ex.Message())
            con.Close()

            FNameL.Visible = False
            LastNameL.Visible = False
            IDL.Visible = False
            ClearB.Visible = False
            PostB.Visible = False
            Header1L.Visible = False
            Header2L.Visible = False
            Header3L.Visible = False
            Emp1TB.Visible = False
            Emp2TB.Visible = False
            EmpL.Visible = False
            From1TB.Visible = False
            From2TB.Visible = False
            FromL.Visible = False
            To1TB.Visible = False
            To2TB.Visible = False
            Tol.Visible = False
            Position2TB.Visible = False
            PositionL.Visible = False
            Position1TB.Visible = False
            Cert1TB.Visible = False
            CertTB2.Visible = False
            CertL.Visible = False
            DateL.Visible = False
            Date1.Visible = False
            Date2.Visible = False
            Line1L.Visible = False
            Line2L.Visible = False
            ResumeTB.Visible = False
            Label1.Visible = False
            Label2.Visible = False
            Label4.Visible = False

            IDTB.Select()
        End Try

    End Sub

    Private Sub NewApplication_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ClearB_Click(sender As Object, e As EventArgs) Handles ClearB.Click

        Emp1TB.Clear()
        Emp2TB.Clear()
        From1TB.Clear()
        From2TB.Clear()
        To1TB.Clear()
        To2TB.Clear()
        Position1TB.Clear()
        Position2TB.Clear()
        Cert1TB.Clear()
        CertTB2.Clear()
        Date1.Clear()
        Date2.Clear()
        ResumeTB.Clear()

    End Sub

    Private Sub PostB_Click(sender As Object, e As EventArgs) Handles PostB.Click
        Dim Employee1 As String = Emp1TB.Text
        Dim Employee2 As String = Emp2TB.Text
        Dim From1 As String = From1TB.Text
        Dim From2 As String = From2TB.Text
        Dim To1 As String = To1TB.Text
        Dim To2 As String = To2TB.Text
        Dim Pos1 As String = Position1TB.Text
        Dim Pos2 As String = Position2TB.Text
        Dim Cert1 As String = Cert1TB.Text
        Dim Cert2 As String = CertTB2.Text
        Dim DateA As String = Date1.Text
        Dim DateB As String = Date2.Text
        Dim Resume1 As String = ResumeTB.Text



        Try

            Dim Command As New OleDbCommand("INSERT INTO Recruitment(SSN, Email,StudentID, FirstName, LastName, Employer1A, Employer2A, FromDate1A, FromDate2A, ToDate1A, ToDate2A, Position1A, Position2A, Certification1A, Certification2A, ResumeA, Type1) VALUES('" & SSN & "','" & EmailAddr & "','" & IDL.Text & "','" & FNameL.Text & "','" & LastNameL.Text & "','" & Employee1 & "','" & Employee2 & "','" & From1 & "','" & From2 & "', '" & To1 & "','" & To2 & "','" & Pos1 & "','" & Pos2 & "','" & Cert1 & "','" & Cert2 & "','" & Resume1 & "','A');", con)
            Dim Dr As OleDbDataReader

            'Open Connection String
            con.ConnectionString = ConnString
            con.Open()

            'Select the Records from the DB
            Command.ExecuteNonQuery()
            MessageBox.Show("Welcome! And Good luck!", "Resume Successfully posted", MessageBoxButtons.OK)
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message())
        con.Close()
        End Try
    End Sub
End Class