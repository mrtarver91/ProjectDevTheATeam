﻿Imports System.Data.OleDb
Public Class NewJobRequest
    Dim ConnInfo As DBConnectionInfo = New DBConnectionInfo
    Dim ConnString As String = ConnInfo.GetConnString()

    'Connection Variable for the database
    Dim con As New OleDbConnection()

    Private Sub FileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FileToolStripMenuItem.Click
        RecruiterHome.Show()
        Me.Hide()
    End Sub

    Private Sub CheckBox4_CheckedChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles SelectB.Click
        Dim CompanyName As String = EmployerCB.SelectedText

        Try
            Dim Command As New OleDbCommand("SELECT CompanyName from Company;", con)
            Dim Dr As OleDbDataReader

            'Open Connection String
            con.ConnectionString = ConnString
            con.Open()

            'Select the Records from the DB
            Dr = Command.ExecuteReader

            While Dr.Read()
                CompanyL.Text = (Dr.GetString(0))
            End While
            con.Close()

            JobL.Visible = True
            JobL1.Visible = True
            JobL2.Visible = True
            ClearB.Visible = True
            PostB.Visible = True
            JobTB.Visible = True
            JobTB2.Visible = True
            PayGB.Visible = True
            HourlyRB.Visible = True
            SalaryRB.Visible = True
            CityL.Visible = True
            StateL1.Visible = True
            CityTB1.Visible = True
            CityL1.Visible = True
            StateCB2.Visible = True
            Line2L.Visible = True
            Line3L.Visible = True
            SeekingL.Visible = True
            UndergradL.Visible = True
            GradL.Visible = True
            UTB.Visible = True
            GTB.Visible = True
            DegreeTB.Visible = True
            DegreeL.Visible = True
            MDegree2.Visible = True
            MDegreeCB.Visible = True
            HonorsCB.Visible = True
            MoveCB.Visible = True

            EmployerL.Visible = False
            CompanyL2.Visible = False
            CompanyTB.Visible = False
            POCL.Visible = False
            POCTB.Visible = False
            PhoneL.Visible = False
            PhoneTB.Visible = False
            CityL.Visible = False
            CityTB.Visible = False
            StateL.Visible = False
            StateCB.Visible = False
            CreateB.Visible = False

            CompanyL.Text = EmployerCB.SelectedItem
            CompanyL.Visible = True

        Catch ex As Exception
            'MessageBox.Show(ex.Message())
            con.Close()
            JobL.Visible = False
            JobL1.Visible = False
            JobL2.Visible = False
            ClearB.Visible = False
            PostB.Visible = False
            JobTB.Visible = False
            JobTB2.Visible = False
            PayGB.Visible = False
            HourlyRB.Visible = False
            SalaryRB.Visible = False
            CityL.Visible = False
            StateL.Visible = False
            CityTB.Visible = False
            StateCB2.Visible = False
            Line2L.Visible = False
            Line3L.Visible = False
            SeekingL.Visible = False
            UndergradL.Visible = False
            GradL.Visible = False
            UTB.Visible = False
            GTB.Visible = False
            DegreeTB.Visible = False
            DegreeL.Visible = False
            MDegree2.Visible = False
            MDegreeCB.Visible = False
            HonorsCB.Visible = False
            MoveCB.Visible = False

            EmployerCB.Select()
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles CreateB.Click
        Dim Company As String = CompanyTB.Text
        Dim POC As String = POCTB.Text
        Dim Phone As Integer = PhoneTB.Text
        Dim City As String = CityTB.Text
        Dim State As String = StateCB.SelectedText

        Try

            Dim Command As New OleDbCommand("INSERT INTO Company(CompanyName, POC, Phone, City, State1) VALUES('" & Company & "','" & POC & "','" & Phone & "','" & City & "','" & State & "');", con)
            Dim Dr As OleDbDataReader

            'Open Connection String
            con.ConnectionString = ConnString
            con.Open()

            'Select the Records from the DB
            Command.ExecuteNonQuery()
            MessageBox.Show("Welcome! And Good luck!", "Success", MessageBoxButtons.OK)
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message())
            con.Close()
        End Try
        JobL.Visible = True
        JobL1.Visible = True
        JobL2.Visible = True
        ClearB.Visible = True
        PostB.Visible = True
        JobTB.Visible = True
        JobTB2.Visible = True
        PayGB.Visible = True
        HourlyRB.Visible = True
        SalaryRB.Visible = True
        CityL.Visible = True
        StateL1.Visible = True
        CityTB1.Visible = True
        CityL1.Visible = True
        StateCB2.Visible = True
        Line2L.Visible = True
        Line3L.Visible = True
        SeekingL.Visible = True
        UndergradL.Visible = True
        GradL.Visible = True
        UTB.Visible = True
        GTB.Visible = True
        DegreeTB.Visible = True
        DegreeL.Visible = True
        MDegree2.Visible = True
        MDegreeCB.Visible = True
        HonorsCB.Visible = True
        MoveCB.Visible = True
        CompanyL.Text = Company
        CompanyL.Visible = True

        CompanyTB.Clear()
        POCTB.Clear()
        PhoneTB.Clear()
        CityTB.Clear()
        StateCB.SelectedIndex = -1

        EmployerL.Visible = False
        CompanyL2.Visible = False
        CompanyTB.Visible = False
        POCL.Visible = False
        POCTB.Visible = False
        PhoneL.Visible = False
        PhoneTB.Visible = False
        CityL.Visible = False
        CityTB.Visible = False
        StateL.Visible = False
        StateCB.Visible = False
        CreateB.Visible = False

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles ClearB.Click

        JobTB.Clear()
        JobTB2.Clear()
        HourlyRB.Checked = False
        SalaryRB.Checked = False
        PayTB.Clear()
        CityTB.Clear()
        StateCB2.SelectedIndex = -1
        UTB.Clear()
        GTB.Clear()
        DegreeTB.Clear()
        MDegreeCB.SelectedIndex = -1
        HonorsCB.Checked = False
        MoveCB.Checked = False


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles PostB.Click
        Dim JobName As String = JobTB.Text
        Dim JobDescription As String = JobTB2.Text
        Dim Hourly As Boolean
        Dim Salary As Boolean
        Dim Pay As String = PayTB.Text
        Dim City As String = CityTB.Text
        Dim State As String = StateCB2.SelectedText
        Dim UGPA As String = UTB.Text
        Dim GGPA As String = GTB.Text
        Dim Honors As Boolean
        Dim Move As Boolean
        Dim CompanyName = CompanyL.Text

        Dim Degree As String = DegreeTB.Text
        Dim MDegree As String = MDegreeCB.SelectedText

        If HonorsCB.Checked = True Then
            Honors = 1
        Else Honors = 0
        End If
        If MoveCB.Checked = True Then
            Move = 1
        Else Move = 0
        End If
        If HourlyRB.Checked = True Then
            Hourly = 1
        Else Hourly = 0
        End If
        If SalaryRB.Checked = True Then
            Salary = 1
        Else Move = 0
        End If

        Try

            Dim Command As New OleDbCommand("INSERT INTO Recruitment(CompanyName, JobNameR, JobDescriptionR, HourlyR, SalaryR, PayR, CityR, StateR, UGPAR, GGPAR, UDegreeR, GDegreeR, HonorsR, MoveR) VALUES('" & CompanyName & "','" & JobName & "','" & JobDescription & "','" & Hourly & "','" & Salary & "','" & Pay & "','" & City & "', '" & State & "','" & UGPA & "','" & GGPA & "','" & Degree & "','" & MDegree & "', '" & Honors & "', '" & Move & "');", con)
            Dim Dr As OleDbDataReader

            'Open Connection String
            con.ConnectionString = ConnString
            con.Open()

            'Select the Records from the DB
            Command.ExecuteNonQuery()
            MessageBox.Show("Application Successfully Posted!", "Success!", MessageBoxButtons.OK)
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message())
            con.Close()
        End Try

    End Sub

    Private Sub NewJobRequest_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try
            Dim Command As New OleDbCommand("SELECT CompanyName FROM Company;", con)
            Dim Dr As OleDbDataReader

            'Open Connection String
            con.ConnectionString = ConnString
            con.Open()

            'Select the Records from the DB
            Dr = Command.ExecuteReader

            While Dr.Read()
                EmployerCB.Items.Add(Dr.GetString(0))
            End While

            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message())
            con.Close()
        End Try
    End Sub
End Class