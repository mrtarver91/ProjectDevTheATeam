﻿Imports System.Data.OleDb
Public Class RecruiterHome
    Dim ConnInfo As DBConnectionInfo = New DBConnectionInfo
    Dim ConnString As String = ConnInfo.GetConnString()

    'Connection Variable for the database
    Dim con As New OleDbConnection()

    'Variables for the datagridview
    Dim ds As New DataSet
    Dim OledbAdapter As OleDbDataAdapter

    Private Sub FileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FileToolStripMenuItem.Click
        NewJobRequest.Show()
        Me.Hide()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()

    End Sub

    Private Sub BackToHomeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BackToHomeToolStripMenuItem.Click
        Form1.Show()
        Me.Hide()

    End Sub

    Private Sub RecruiterHome_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Dim Command As New OleDbCommand("SELECT CompanyName FROM Company ;", con)
            Dim Dr As OleDbDataReader

            'Open Connection String
            con.ConnectionString = ConnString
            con.Open()

            'Select the Records from the DB
            Dr = Command.ExecuteReader

            While Dr.Read()
                CompanyCB.Items.Add(Dr.GetString(0))
            End While

            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message())
            con.Close()
        End Try
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles QSearchB.Click
        Dim Year As Integer
        Dim Honors As Boolean
        Dim GPA As String = GPATB.Text
        Dim State As String = StateCB.SelectedText
        Dim Move As Boolean
        Dim Major As String = MajorCB.SelectedText

        If HonorsCB.Checked = True Then
            Honors = 1
        Else Honors = 0
        End If

        If MoveCB.Checked = True Then
            Move = 1
        Else Move = 0
        End If

        Dim ds As New DataSet
        Try
            con.ConnectionString = ConnString

            Dim sql As String = "SELECT FirstName, LastName, StudentID, Email FROM GradStudents WHERE Major = '" & Major & "' OR PermState = '" & State & "' OR GradGPA = '" & GPA & "';"

            con.Open()
            OledbAdapter = New OleDbDataAdapter(sql, con)
            OledbAdapter.Fill(ds)
            MatchesDG.DataSource = ds.Tables(0)
            con.Close()

            GradCB.Checked = False
            HonorsCB.Checked = False
            MoveCB.Checked = False
            GPATB.Clear()
            StateCB.SelectedIndex = -1
            MajorCB.SelectedIndex = -1

        Catch ex As Exception
            con.Close()
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles ApplicationsDG.CellContentClick
        'Here we need to find the matches with the clicked job application

        MatchesDG.Refresh()
        'Try
        '    con.ConnectionString = ConnString

        '    Dim sql As String = "SELECT * FROM GradStudents WHERE ;"

        '    con.Open()
        '    OledbAdapter = New OleDbDataAdapter(sql, con)
        '    OledbAdapter.Fill(ds)
        '    MatchesDG.DataSource = ds.Tables(0)
        '    MatchesDG.Columns(0).Width = 100
        '    MatchesDG.Columns(1).Width = 100
        '    MatchesDG.Columns(2).Width = 100
        '    MatchesDG.Columns(3).Width = 100
        '    con.Close()
        'Catch ex As Exception
        '    con.Close()
        '    MessageBox.Show(ex.Message)
        'End Try

    End Sub

    Private Sub DataGridView2_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles MatchesDG.CellContentDoubleClick
        'Dim the student ID as TempID and make it a global object so that Matches can access it

        'Here we need to open up the matches form so the recruiter could see the details about that student

        Matches.Show()
        Me.Hide()

    End Sub

    Private Sub SearchB_Click(sender As Object, e As EventArgs) Handles SearchB.Click
        Dim CompName As String = CompanyCB.SelectedItem

        Dim ds As New DataSet

        Try
            con.ConnectionString = ConnString

            Dim sql As String = "SELECT JobNameR As 'Job Name', CityR As 'City', PayR As 'Pay' FROM Recruitment WHERE CompanyName = '" & CompName & "';"

            con.Open()
            OledbAdapter = New OleDbDataAdapter(sql, con)
            OledbAdapter.Fill(ds)
            ApplicationsDG.DataSource = ds.Tables(0)
            con.Close()


        Catch ex As Exception
            con.Close()
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub SeeAllB_Click(sender As Object, e As EventArgs) Handles SeeAllB.Click
        Dim ds As New DataSet

        Try
            con.ConnectionString = ConnString

            Dim sql As String = "SELECT JobNameR As 'Job Name', CityR As 'City', PayR As 'Pay' FROM Recruitment;"

            con.Open()
            OledbAdapter = New OleDbDataAdapter(sql, con)
            OledbAdapter.Fill(ds)
            ApplicationsDG.DataSource = ds.Tables(0)
            con.Close()
        Catch ex As Exception
            con.Close()
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub MatchesDG_CellContentDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles MatchesDG.CellContentDoubleClick

    End Sub
End Class