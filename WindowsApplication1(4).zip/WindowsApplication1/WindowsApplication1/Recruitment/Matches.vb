﻿Imports System.Data.OleDb
Public Class Matches
    Dim ConnInfo As DBConnectionInfo = New DBConnectionInfo
    Dim ConnString As String = ConnInfo.GetConnString()

    'Connection Variable for the database
    Dim con As New OleDbConnection()

    'Variables for the datagridview
    Dim ds As New DataSet
    Dim OledbAdapter As OleDbDataAdapter

    Private Sub Matches_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Here we will pull the matched studentID from StudentHome.MatchDG_ContentDoubleClick

        'SQL search for all pertinent data on that student 

        'Possibly throw in an option to email the student
    End Sub
End Class