﻿Imports System.Data.OleDb
Public Class StudentHome
    Dim ConnInfo As DBConnectionInfo = New DBConnectionInfo
    Dim ConnString As String = ConnInfo.GetConnString()

    'Connection Variable for the database
    Dim con As New OleDbConnection()

    'Variables for the datagridview
    Dim ds As New DataSet
    Dim OledbAdapter As OleDbDataAdapter


    Private Sub FileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FileToolStripMenuItem.Click
        NewApplication.Show()
        Me.Hide()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()

    End Sub

    Private Sub BackToHomeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BackToHomeToolStripMenuItem.Click
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles QSearchB.Click
        Dim Honors As Boolean
        Dim GPA As String = GPATB.Text
        Dim State As String = StateCB.SelectedText
        Dim Move As Boolean
        Dim Major As String = MajorCB.SelectedText

        If HonorsCB.Checked = True Then
            Honors = 1
        Else Honors = 0
        End If
        If MoveCB.Checked = True Then
            Move = 1
        Else Move = 0
        End If

        Dim ds As New DataSet
        Try
            con.ConnectionString = ConnString

            Dim sql As String = "SELECT CompanyName, JobNameR, CityR, StateR, PayR FROM Recruitment WHERE GDegreeR = '" & Major & "' OR StateR = '" & State & "' OR GGPAR = '" & GPA & "';"

            con.Open()
            OledbAdapter = New OleDbDataAdapter(sql, con)
            OledbAdapter.Fill(ds)
            MatchesDG.DataSource = ds.Tables(0)
            con.Close()

            GradCB.Checked = False
            HonorsCB.Checked = False
            MoveCB.Checked = False
            GPATB.Clear()
            StateCB.SelectedIndex = -1
            MajorCB.SelectedIndex = -1

        Catch ex As Exception
            con.Close()
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub ApplicationsDG_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles ApplicationsDG.CellContentClick
        'Here we need to find the matches with the clicked job application

        Dim ds As New DataSet
        Try
            con.ConnectionString = ConnString

            Dim sql As String = "Select * FROM GradStudents WHERE ;"

            con.Open()
            OledbAdapter = New OleDbDataAdapter(sql, con)
            OledbAdapter.Fill(ds)
            MatchesDG.DataSource = ds.Tables(0)
            con.Close()
        Catch ex As Exception
            con.Close()
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub DataGridView2_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles MatchesDG.CellContentDoubleClick
        'Dim the student ID as TempID and make it a global object so that Matches can access it

        'Here we need to open up the matches form so the recruiter could see the details about that student

        Matches.Show()
        Me.Hide()

    End Sub

    Private Sub SearchB_Click(sender As Object, e As EventArgs) Handles SearchB.Click
        Dim StudID As Integer = IDTB.Text

        Dim ds As New DataSet

        Try
            con.ConnectionString = ConnString

            Dim sql As String = "Select FirstName, LastName, StudentID, Email FROM Recruitment WHERE StudentID = '" & StudID & "';"

            con.Open()
            OledbAdapter = New OleDbDataAdapter(sql, con)
            OledbAdapter.Fill(ds)
            ApplicationsDG.DataSource = ds.Tables(0)
            ApplicationsDG.Columns(0).Width = 75
            ApplicationsDG.Columns(1).Width = 75
            ApplicationsDG.Columns(2).Width = 75
            ApplicationsDG.Columns(3).Width = 75
            con.Close()

            IDTB.Clear()
        Catch ex As Exception
            con.Close()
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub SearchALl_Click(sender As Object, e As EventArgs) Handles SearchALl.Click

        Dim ds As New DataSet
        Try
            con.ConnectionString = ConnString

            Dim sql As String = "SELECT FirstName, LastName, StudentID, Email FROM Recruitment WHERE TYPE1 = 'A';"

            con.Open()
            OledbAdapter = New OleDbDataAdapter(sql, con)
            OledbAdapter.Fill(ds)
            ApplicationsDG.DataSource = ds.Tables(0)
            con.Close()
        Catch ex As Exception
            con.Close()
            MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class