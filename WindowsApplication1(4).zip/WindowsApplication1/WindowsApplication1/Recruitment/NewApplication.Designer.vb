﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NewApplication
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IDTB = New System.Windows.Forms.TextBox()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.SearchB = New System.Windows.Forms.Button()
        Me.Line1L = New System.Windows.Forms.Label()
        Me.Header1L = New System.Windows.Forms.Label()
        Me.Emp1TB = New System.Windows.Forms.TextBox()
        Me.Tol = New System.Windows.Forms.Label()
        Me.FromL = New System.Windows.Forms.Label()
        Me.To1TB = New System.Windows.Forms.TextBox()
        Me.Emp2TB = New System.Windows.Forms.TextBox()
        Me.From2TB = New System.Windows.Forms.TextBox()
        Me.From1TB = New System.Windows.Forms.TextBox()
        Me.To2TB = New System.Windows.Forms.TextBox()
        Me.Position2TB = New System.Windows.Forms.TextBox()
        Me.Position1TB = New System.Windows.Forms.TextBox()
        Me.PositionL = New System.Windows.Forms.Label()
        Me.EmpL = New System.Windows.Forms.Label()
        Me.Header2L = New System.Windows.Forms.Label()
        Me.Date1 = New System.Windows.Forms.TextBox()
        Me.Date2 = New System.Windows.Forms.TextBox()
        Me.CertTB2 = New System.Windows.Forms.TextBox()
        Me.Cert1TB = New System.Windows.Forms.TextBox()
        Me.DateL = New System.Windows.Forms.Label()
        Me.CertL = New System.Windows.Forms.Label()
        Me.FNameL = New System.Windows.Forms.Label()
        Me.LastNameL = New System.Windows.Forms.Label()
        Me.IDL = New System.Windows.Forms.Label()
        Me.ResumeTB = New System.Windows.Forms.TextBox()
        Me.Line2L = New System.Windows.Forms.Label()
        Me.Header3L = New System.Windows.Forms.Label()
        Me.ClearB = New System.Windows.Forms.Button()
        Me.PostB = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(676, 24)
        Me.MenuStrip1.TabIndex = 19
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(41, 20)
        Me.FileToolStripMenuItem.Text = "Back"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'IDTB
        '
        Me.IDTB.Location = New System.Drawing.Point(31, 46)
        Me.IDTB.Name = "IDTB"
        Me.IDTB.Size = New System.Drawing.Size(118, 20)
        Me.IDTB.TabIndex = 20
        '
        'lblLastName
        '
        Me.lblLastName.AutoSize = True
        Me.lblLastName.Location = New System.Drawing.Point(31, 30)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(96, 13)
        Me.lblLastName.TabIndex = 202
        Me.lblLastName.Text = "Student ID number"
        '
        'SearchB
        '
        Me.SearchB.Location = New System.Drawing.Point(182, 43)
        Me.SearchB.Name = "SearchB"
        Me.SearchB.Size = New System.Drawing.Size(75, 23)
        Me.SearchB.TabIndex = 455
        Me.SearchB.Text = "Search"
        Me.SearchB.UseVisualStyleBackColor = True
        '
        'Line1L
        '
        Me.Line1L.AutoSize = True
        Me.Line1L.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Line1L.Location = New System.Drawing.Point(3, 69)
        Me.Line1L.Name = "Line1L"
        Me.Line1L.Size = New System.Drawing.Size(1024, 16)
        Me.Line1L.TabIndex = 456
        Me.Line1L.Text = "_________________________________________________________________________________" &
    "______________________________________________"
        '
        'Header1L
        '
        Me.Header1L.AutoSize = True
        Me.Header1L.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Header1L.Location = New System.Drawing.Point(23, 99)
        Me.Header1L.Name = "Header1L"
        Me.Header1L.Size = New System.Drawing.Size(126, 16)
        Me.Header1L.TabIndex = 457
        Me.Header1L.Text = "Work Experience"
        Me.Header1L.Visible = False
        '
        'Emp1TB
        '
        Me.Emp1TB.Location = New System.Drawing.Point(23, 142)
        Me.Emp1TB.Name = "Emp1TB"
        Me.Emp1TB.Size = New System.Drawing.Size(182, 20)
        Me.Emp1TB.TabIndex = 458
        Me.Emp1TB.Visible = False
        '
        'Tol
        '
        Me.Tol.AutoSize = True
        Me.Tol.Location = New System.Drawing.Point(286, 126)
        Me.Tol.Name = "Tol"
        Me.Tol.Size = New System.Drawing.Size(23, 13)
        Me.Tol.TabIndex = 465
        Me.Tol.Text = "To:"
        Me.Tol.Visible = False
        '
        'FromL
        '
        Me.FromL.AutoSize = True
        Me.FromL.Location = New System.Drawing.Point(211, 126)
        Me.FromL.Name = "FromL"
        Me.FromL.Size = New System.Drawing.Size(33, 13)
        Me.FromL.TabIndex = 466
        Me.FromL.Text = "From:"
        Me.FromL.Visible = False
        '
        'To1TB
        '
        Me.To1TB.Location = New System.Drawing.Point(287, 142)
        Me.To1TB.Name = "To1TB"
        Me.To1TB.Size = New System.Drawing.Size(70, 20)
        Me.To1TB.TabIndex = 460
        Me.To1TB.Visible = False
        '
        'Emp2TB
        '
        Me.Emp2TB.Location = New System.Drawing.Point(23, 168)
        Me.Emp2TB.Name = "Emp2TB"
        Me.Emp2TB.Size = New System.Drawing.Size(182, 20)
        Me.Emp2TB.TabIndex = 461
        Me.Emp2TB.Visible = False
        '
        'From2TB
        '
        Me.From2TB.Location = New System.Drawing.Point(211, 168)
        Me.From2TB.Name = "From2TB"
        Me.From2TB.Size = New System.Drawing.Size(70, 20)
        Me.From2TB.TabIndex = 462
        Me.From2TB.Visible = False
        '
        'From1TB
        '
        Me.From1TB.Location = New System.Drawing.Point(211, 142)
        Me.From1TB.Name = "From1TB"
        Me.From1TB.Size = New System.Drawing.Size(70, 20)
        Me.From1TB.TabIndex = 459
        Me.From1TB.Visible = False
        '
        'To2TB
        '
        Me.To2TB.Location = New System.Drawing.Point(287, 168)
        Me.To2TB.Name = "To2TB"
        Me.To2TB.Size = New System.Drawing.Size(70, 20)
        Me.To2TB.TabIndex = 463
        Me.To2TB.Visible = False
        '
        'Position2TB
        '
        Me.Position2TB.Location = New System.Drawing.Point(363, 168)
        Me.Position2TB.Name = "Position2TB"
        Me.Position2TB.Size = New System.Drawing.Size(182, 20)
        Me.Position2TB.TabIndex = 468
        Me.Position2TB.Visible = False
        '
        'Position1TB
        '
        Me.Position1TB.Location = New System.Drawing.Point(363, 142)
        Me.Position1TB.Name = "Position1TB"
        Me.Position1TB.Size = New System.Drawing.Size(182, 20)
        Me.Position1TB.TabIndex = 467
        Me.Position1TB.Visible = False
        '
        'PositionL
        '
        Me.PositionL.AutoSize = True
        Me.PositionL.Location = New System.Drawing.Point(360, 126)
        Me.PositionL.Name = "PositionL"
        Me.PositionL.Size = New System.Drawing.Size(44, 13)
        Me.PositionL.TabIndex = 469
        Me.PositionL.Text = "Position"
        Me.PositionL.Visible = False
        '
        'EmpL
        '
        Me.EmpL.AutoSize = True
        Me.EmpL.Location = New System.Drawing.Point(23, 121)
        Me.EmpL.Name = "EmpL"
        Me.EmpL.Size = New System.Drawing.Size(50, 13)
        Me.EmpL.TabIndex = 470
        Me.EmpL.Text = "Employer"
        Me.EmpL.Visible = False
        '
        'Header2L
        '
        Me.Header2L.AutoSize = True
        Me.Header2L.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Header2L.Location = New System.Drawing.Point(23, 207)
        Me.Header2L.Name = "Header2L"
        Me.Header2L.Size = New System.Drawing.Size(165, 16)
        Me.Header2L.TabIndex = 471
        Me.Header2L.Text = "Certifications/Licenses"
        Me.Header2L.Visible = False
        '
        'Date1
        '
        Me.Date1.Location = New System.Drawing.Point(213, 246)
        Me.Date1.Name = "Date1"
        Me.Date1.Size = New System.Drawing.Size(70, 20)
        Me.Date1.TabIndex = 473
        Me.Date1.Visible = False
        '
        'Date2
        '
        Me.Date2.Location = New System.Drawing.Point(213, 272)
        Me.Date2.Name = "Date2"
        Me.Date2.Size = New System.Drawing.Size(70, 20)
        Me.Date2.TabIndex = 475
        Me.Date2.Visible = False
        '
        'CertTB2
        '
        Me.CertTB2.Location = New System.Drawing.Point(23, 272)
        Me.CertTB2.Name = "CertTB2"
        Me.CertTB2.Size = New System.Drawing.Size(182, 20)
        Me.CertTB2.TabIndex = 474
        Me.CertTB2.Visible = False
        '
        'Cert1TB
        '
        Me.Cert1TB.Location = New System.Drawing.Point(23, 246)
        Me.Cert1TB.Name = "Cert1TB"
        Me.Cert1TB.Size = New System.Drawing.Size(182, 20)
        Me.Cert1TB.TabIndex = 472
        Me.Cert1TB.Visible = False
        '
        'DateL
        '
        Me.DateL.AutoSize = True
        Me.DateL.Location = New System.Drawing.Point(210, 230)
        Me.DateL.Name = "DateL"
        Me.DateL.Size = New System.Drawing.Size(30, 13)
        Me.DateL.TabIndex = 477
        Me.DateL.Text = "Date"
        Me.DateL.Visible = False
        '
        'CertL
        '
        Me.CertL.AutoSize = True
        Me.CertL.Location = New System.Drawing.Point(23, 230)
        Me.CertL.Name = "CertL"
        Me.CertL.Size = New System.Drawing.Size(62, 13)
        Me.CertL.TabIndex = 476
        Me.CertL.Text = "Certification"
        Me.CertL.Visible = False
        '
        'FNameL
        '
        Me.FNameL.AutoSize = True
        Me.FNameL.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FNameL.Location = New System.Drawing.Point(224, 89)
        Me.FNameL.Name = "FNameL"
        Me.FNameL.Size = New System.Drawing.Size(16, 16)
        Me.FNameL.TabIndex = 478
        Me.FNameL.Text = "_"
        Me.FNameL.Visible = False
        '
        'LastNameL
        '
        Me.LastNameL.AutoSize = True
        Me.LastNameL.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LastNameL.Location = New System.Drawing.Point(296, 89)
        Me.LastNameL.Name = "LastNameL"
        Me.LastNameL.Size = New System.Drawing.Size(16, 16)
        Me.LastNameL.TabIndex = 479
        Me.LastNameL.Text = "_"
        Me.LastNameL.Visible = False
        '
        'IDL
        '
        Me.IDL.AutoSize = True
        Me.IDL.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IDL.Location = New System.Drawing.Point(402, 89)
        Me.IDL.Name = "IDL"
        Me.IDL.Size = New System.Drawing.Size(16, 16)
        Me.IDL.TabIndex = 480
        Me.IDL.Text = "_"
        Me.IDL.Visible = False
        '
        'ResumeTB
        '
        Me.ResumeTB.Location = New System.Drawing.Point(26, 333)
        Me.ResumeTB.Multiline = True
        Me.ResumeTB.Name = "ResumeTB"
        Me.ResumeTB.Size = New System.Drawing.Size(625, 241)
        Me.ResumeTB.TabIndex = 481
        Me.ResumeTB.Visible = False
        '
        'Line2L
        '
        Me.Line2L.AutoSize = True
        Me.Line2L.Location = New System.Drawing.Point(23, 295)
        Me.Line2L.Name = "Line2L"
        Me.Line2L.Size = New System.Drawing.Size(151, 13)
        Me.Line2L.TabIndex = 482
        Me.Line2L.Text = "________________________"
        Me.Line2L.Visible = False
        '
        'Header3L
        '
        Me.Header3L.AutoSize = True
        Me.Header3L.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Header3L.Location = New System.Drawing.Point(23, 314)
        Me.Header3L.Name = "Header3L"
        Me.Header3L.Size = New System.Drawing.Size(65, 16)
        Me.Header3L.TabIndex = 483
        Me.Header3L.Text = "Resume"
        Me.Header3L.Visible = False
        '
        'ClearB
        '
        Me.ClearB.Location = New System.Drawing.Point(472, 86)
        Me.ClearB.Name = "ClearB"
        Me.ClearB.Size = New System.Drawing.Size(75, 23)
        Me.ClearB.TabIndex = 484
        Me.ClearB.Text = "Clear"
        Me.ClearB.UseVisualStyleBackColor = True
        Me.ClearB.Visible = False
        '
        'PostB
        '
        Me.PostB.Location = New System.Drawing.Point(573, 86)
        Me.PostB.Name = "PostB"
        Me.PostB.Size = New System.Drawing.Size(75, 23)
        Me.PostB.TabIndex = 485
        Me.PostB.Text = "Post"
        Me.PostB.UseVisualStyleBackColor = True
        Me.PostB.Visible = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.Label1.Location = New System.Drawing.Point(211, 191)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 13)
        Me.Label1.TabIndex = 486
        Me.Label1.Text = "2009-06-25"
        Me.Label1.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.Label4.Location = New System.Drawing.Point(211, 295)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(61, 13)
        Me.Label4.TabIndex = 489
        Me.Label4.Text = "2009-06-25"
        Me.Label4.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.Label2.Location = New System.Drawing.Point(286, 191)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 13)
        Me.Label2.TabIndex = 490
        Me.Label2.Text = "2009-06-25"
        Me.Label2.Visible = False
        '
        'NewApplication
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(676, 582)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PostB)
        Me.Controls.Add(Me.ClearB)
        Me.Controls.Add(Me.Header3L)
        Me.Controls.Add(Me.Line2L)
        Me.Controls.Add(Me.ResumeTB)
        Me.Controls.Add(Me.IDL)
        Me.Controls.Add(Me.LastNameL)
        Me.Controls.Add(Me.FNameL)
        Me.Controls.Add(Me.Date1)
        Me.Controls.Add(Me.Date2)
        Me.Controls.Add(Me.CertTB2)
        Me.Controls.Add(Me.Cert1TB)
        Me.Controls.Add(Me.DateL)
        Me.Controls.Add(Me.CertL)
        Me.Controls.Add(Me.Header2L)
        Me.Controls.Add(Me.EmpL)
        Me.Controls.Add(Me.PositionL)
        Me.Controls.Add(Me.Position2TB)
        Me.Controls.Add(Me.Position1TB)
        Me.Controls.Add(Me.To1TB)
        Me.Controls.Add(Me.To2TB)
        Me.Controls.Add(Me.From1TB)
        Me.Controls.Add(Me.From2TB)
        Me.Controls.Add(Me.Emp2TB)
        Me.Controls.Add(Me.Emp1TB)
        Me.Controls.Add(Me.FromL)
        Me.Controls.Add(Me.Tol)
        Me.Controls.Add(Me.Header1L)
        Me.Controls.Add(Me.Line1L)
        Me.Controls.Add(Me.SearchB)
        Me.Controls.Add(Me.lblLastName)
        Me.Controls.Add(Me.IDTB)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "NewApplication"
        Me.Text = "NewApplication"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents IDTB As TextBox
    Friend WithEvents lblLastName As Label
    Friend WithEvents SearchB As Button
    Friend WithEvents Line1L As Label
    Friend WithEvents Emp1TB As TextBox
    Friend WithEvents Tol As Label
    Friend WithEvents FromL As Label
    Friend WithEvents To1TB As TextBox
    Friend WithEvents Emp2TB As TextBox
    Friend WithEvents From2TB As TextBox
    Friend WithEvents From1TB As TextBox
    Friend WithEvents To2TB As TextBox
    Friend WithEvents Position2TB As TextBox
    Friend WithEvents Position1TB As TextBox
    Friend WithEvents Header2L As Label
    Friend WithEvents Date1 As TextBox
    Friend WithEvents Date2 As TextBox
    Friend WithEvents CertTB2 As TextBox
    Friend WithEvents Cert1TB As TextBox
    Friend WithEvents DateL As Label
    Friend WithEvents CertL As Label
    Friend WithEvents FNameL As Label
    Friend WithEvents LastNameL As Label
    Friend WithEvents IDL As Label
    Friend WithEvents ResumeTB As TextBox
    Friend WithEvents Line2L As Label
    Friend WithEvents EmpL As Label
    Friend WithEvents PositionL As Label
    Friend WithEvents Header1L As Label
    Friend WithEvents Header3L As Label
    Friend WithEvents ClearB As Button
    Friend WithEvents PostB As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label2 As Label
End Class
