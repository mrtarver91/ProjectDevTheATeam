<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.tabApplication = New System.Windows.Forms.TabPage
        Me.Label49 = New System.Windows.Forms.Label
        Me.Label48 = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.TextBox56 = New System.Windows.Forms.TextBox
        Me.Label50 = New System.Windows.Forms.Label
        Me.Label46 = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Label47 = New System.Windows.Forms.Label
        Me.ComboBox5 = New System.Windows.Forms.ComboBox
        Me.TextBox24 = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.TextBox23 = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.TextBox22 = New System.Windows.Forms.TextBox
        Me.Label21 = New System.Windows.Forms.Label
        Me.TextBox19 = New System.Windows.Forms.TextBox
        Me.Label16 = New System.Windows.Forms.Label
        Me.ComboBox3 = New System.Windows.Forms.ComboBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.TextBox20 = New System.Windows.Forms.TextBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.TextBox21 = New System.Windows.Forms.TextBox
        Me.CheckBox1 = New System.Windows.Forms.CheckBox
        Me.TextBox16 = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.ComboBox2 = New System.Windows.Forms.ComboBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.TextBox17 = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.TextBox18 = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.TextBox15 = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.TextBox14 = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.TextBox13 = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.TextBox12 = New System.Windows.Forms.TextBox
        Me.CheckBox6 = New System.Windows.Forms.CheckBox
        Me.CheckBox5 = New System.Windows.Forms.CheckBox
        Me.CheckBox4 = New System.Windows.Forms.CheckBox
        Me.CheckBox3 = New System.Windows.Forms.CheckBox
        Me.CheckBox2 = New System.Windows.Forms.CheckBox
        Me.ComboBox4 = New System.Windows.Forms.ComboBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.TextBox9 = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.TextBox11 = New System.Windows.Forms.TextBox
        Me.TextBox10 = New System.Windows.Forms.TextBox
        Me.TextBox8 = New System.Windows.Forms.TextBox
        Me.lblDOB = New System.Windows.Forms.Label
        Me.TextBox7 = New System.Windows.Forms.TextBox
        Me.TextBox6 = New System.Windows.Forms.TextBox
        Me.TextBox5 = New System.Windows.Forms.TextBox
        Me.lblSSN = New System.Windows.Forms.Label
        Me.TextBox4 = New System.Windows.Forms.TextBox
        Me.lblPreferredName = New System.Windows.Forms.Label
        Me.lblName = New System.Windows.Forms.Label
        Me.TextBox3 = New System.Windows.Forms.TextBox
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.lblMiddleName = New System.Windows.Forms.Label
        Me.lblFirstName = New System.Windows.Forms.Label
        Me.lblLastName = New System.Windows.Forms.Label
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.Label52 = New System.Windows.Forms.Label
        Me.ComboBox7 = New System.Windows.Forms.ComboBox
        Me.Label51 = New System.Windows.Forms.Label
        Me.ComboBox6 = New System.Windows.Forms.ComboBox
        Me.CheckBox22 = New System.Windows.Forms.CheckBox
        Me.TextBox27 = New System.Windows.Forms.TextBox
        Me.Label27 = New System.Windows.Forms.Label
        Me.CheckBox21 = New System.Windows.Forms.CheckBox
        Me.CheckBox19 = New System.Windows.Forms.CheckBox
        Me.CheckBox20 = New System.Windows.Forms.CheckBox
        Me.Label26 = New System.Windows.Forms.Label
        Me.CheckBox18 = New System.Windows.Forms.CheckBox
        Me.TextBox26 = New System.Windows.Forms.TextBox
        Me.Label25 = New System.Windows.Forms.Label
        Me.CheckBox17 = New System.Windows.Forms.CheckBox
        Me.CheckBox16 = New System.Windows.Forms.CheckBox
        Me.CheckBox13 = New System.Windows.Forms.CheckBox
        Me.CheckBox12 = New System.Windows.Forms.CheckBox
        Me.CheckBox9 = New System.Windows.Forms.CheckBox
        Me.Label24 = New System.Windows.Forms.Label
        Me.CheckBox7 = New System.Windows.Forms.CheckBox
        Me.CheckBox8 = New System.Windows.Forms.CheckBox
        Me.TextBox25 = New System.Windows.Forms.TextBox
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.CheckBox29 = New System.Windows.Forms.CheckBox
        Me.TextBox42 = New System.Windows.Forms.TextBox
        Me.TextBox43 = New System.Windows.Forms.TextBox
        Me.CheckBox28 = New System.Windows.Forms.CheckBox
        Me.CheckBox27 = New System.Windows.Forms.CheckBox
        Me.CheckBox26 = New System.Windows.Forms.CheckBox
        Me.CheckBox25 = New System.Windows.Forms.CheckBox
        Me.CheckBox24 = New System.Windows.Forms.CheckBox
        Me.CheckBox23 = New System.Windows.Forms.CheckBox
        Me.CheckBox15 = New System.Windows.Forms.CheckBox
        Me.CheckBox14 = New System.Windows.Forms.CheckBox
        Me.CheckBox11 = New System.Windows.Forms.CheckBox
        Me.CheckBox10 = New System.Windows.Forms.CheckBox
        Me.Label64 = New System.Windows.Forms.Label
        Me.Label63 = New System.Windows.Forms.Label
        Me.Label61 = New System.Windows.Forms.Label
        Me.Label62 = New System.Windows.Forms.Label
        Me.TextBox99 = New System.Windows.Forms.TextBox
        Me.TextBox100 = New System.Windows.Forms.TextBox
        Me.TextBox101 = New System.Windows.Forms.TextBox
        Me.TextBox102 = New System.Windows.Forms.TextBox
        Me.TextBox103 = New System.Windows.Forms.TextBox
        Me.TextBox104 = New System.Windows.Forms.TextBox
        Me.Label60 = New System.Windows.Forms.Label
        Me.TextBox93 = New System.Windows.Forms.TextBox
        Me.TextBox94 = New System.Windows.Forms.TextBox
        Me.TextBox95 = New System.Windows.Forms.TextBox
        Me.TextBox96 = New System.Windows.Forms.TextBox
        Me.TextBox97 = New System.Windows.Forms.TextBox
        Me.TextBox98 = New System.Windows.Forms.TextBox
        Me.Label59 = New System.Windows.Forms.Label
        Me.Label58 = New System.Windows.Forms.Label
        Me.TextBox87 = New System.Windows.Forms.TextBox
        Me.TextBox88 = New System.Windows.Forms.TextBox
        Me.TextBox89 = New System.Windows.Forms.TextBox
        Me.TextBox90 = New System.Windows.Forms.TextBox
        Me.TextBox91 = New System.Windows.Forms.TextBox
        Me.TextBox92 = New System.Windows.Forms.TextBox
        Me.Label57 = New System.Windows.Forms.Label
        Me.TextBox81 = New System.Windows.Forms.TextBox
        Me.TextBox82 = New System.Windows.Forms.TextBox
        Me.TextBox83 = New System.Windows.Forms.TextBox
        Me.TextBox84 = New System.Windows.Forms.TextBox
        Me.TextBox85 = New System.Windows.Forms.TextBox
        Me.TextBox86 = New System.Windows.Forms.TextBox
        Me.Label56 = New System.Windows.Forms.Label
        Me.Label55 = New System.Windows.Forms.Label
        Me.Label54 = New System.Windows.Forms.Label
        Me.TextBox69 = New System.Windows.Forms.TextBox
        Me.TextBox70 = New System.Windows.Forms.TextBox
        Me.TextBox71 = New System.Windows.Forms.TextBox
        Me.TextBox72 = New System.Windows.Forms.TextBox
        Me.TextBox73 = New System.Windows.Forms.TextBox
        Me.TextBox74 = New System.Windows.Forms.TextBox
        Me.TextBox75 = New System.Windows.Forms.TextBox
        Me.TextBox76 = New System.Windows.Forms.TextBox
        Me.TextBox77 = New System.Windows.Forms.TextBox
        Me.TextBox78 = New System.Windows.Forms.TextBox
        Me.TextBox79 = New System.Windows.Forms.TextBox
        Me.TextBox80 = New System.Windows.Forms.TextBox
        Me.TextBox67 = New System.Windows.Forms.TextBox
        Me.TextBox68 = New System.Windows.Forms.TextBox
        Me.TextBox65 = New System.Windows.Forms.TextBox
        Me.TextBox66 = New System.Windows.Forms.TextBox
        Me.TextBox57 = New System.Windows.Forms.TextBox
        Me.TextBox59 = New System.Windows.Forms.TextBox
        Me.TextBox61 = New System.Windows.Forms.TextBox
        Me.TextBox63 = New System.Windows.Forms.TextBox
        Me.TextBox58 = New System.Windows.Forms.TextBox
        Me.TextBox60 = New System.Windows.Forms.TextBox
        Me.TextBox62 = New System.Windows.Forms.TextBox
        Me.TextBox64 = New System.Windows.Forms.TextBox
        Me.Label53 = New System.Windows.Forms.Label
        Me.TextBox54 = New System.Windows.Forms.TextBox
        Me.TextBox55 = New System.Windows.Forms.TextBox
        Me.TextBox52 = New System.Windows.Forms.TextBox
        Me.TextBox53 = New System.Windows.Forms.TextBox
        Me.TextBox50 = New System.Windows.Forms.TextBox
        Me.TextBox51 = New System.Windows.Forms.TextBox
        Me.Label45 = New System.Windows.Forms.Label
        Me.Label43 = New System.Windows.Forms.Label
        Me.TextBox48 = New System.Windows.Forms.TextBox
        Me.Label44 = New System.Windows.Forms.Label
        Me.TextBox49 = New System.Windows.Forms.TextBox
        Me.Label42 = New System.Windows.Forms.Label
        Me.Label41 = New System.Windows.Forms.Label
        Me.TextBox47 = New System.Windows.Forms.TextBox
        Me.Label40 = New System.Windows.Forms.Label
        Me.TextBox46 = New System.Windows.Forms.TextBox
        Me.Label37 = New System.Windows.Forms.Label
        Me.Label38 = New System.Windows.Forms.Label
        Me.TextBox44 = New System.Windows.Forms.TextBox
        Me.Label39 = New System.Windows.Forms.Label
        Me.TextBox45 = New System.Windows.Forms.TextBox
        Me.Label36 = New System.Windows.Forms.Label
        Me.Label35 = New System.Windows.Forms.Label
        Me.TextBox41 = New System.Windows.Forms.TextBox
        Me.Label34 = New System.Windows.Forms.Label
        Me.TextBox40 = New System.Windows.Forms.TextBox
        Me.Label33 = New System.Windows.Forms.Label
        Me.TextBox34 = New System.Windows.Forms.TextBox
        Me.TextBox35 = New System.Windows.Forms.TextBox
        Me.TextBox36 = New System.Windows.Forms.TextBox
        Me.Label30 = New System.Windows.Forms.Label
        Me.TextBox31 = New System.Windows.Forms.TextBox
        Me.TextBox32 = New System.Windows.Forms.TextBox
        Me.TextBox33 = New System.Windows.Forms.TextBox
        Me.Label29 = New System.Windows.Forms.Label
        Me.Label32 = New System.Windows.Forms.Label
        Me.TextBox37 = New System.Windows.Forms.TextBox
        Me.TextBox38 = New System.Windows.Forms.TextBox
        Me.TextBox39 = New System.Windows.Forms.TextBox
        Me.Label31 = New System.Windows.Forms.Label
        Me.TextBox28 = New System.Windows.Forms.TextBox
        Me.TextBox29 = New System.Windows.Forms.TextBox
        Me.TextBox30 = New System.Windows.Forms.TextBox
        Me.Label28 = New System.Windows.Forms.Label
        Me.CheckBox30 = New System.Windows.Forms.CheckBox
        Me.MenuStrip1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.tabApplication.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.EditToolStripMenuItem, Me.ViewToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(842, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(35, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'ViewToolStripMenuItem
        '
        Me.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem"
        Me.ViewToolStripMenuItem.Size = New System.Drawing.Size(41, 20)
        Me.ViewToolStripMenuItem.Text = "View"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.tabApplication)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Location = New System.Drawing.Point(22, 68)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(796, 478)
        Me.TabControl1.TabIndex = 1
        '
        'tabApplication
        '
        Me.tabApplication.Controls.Add(Me.Label49)
        Me.tabApplication.Controls.Add(Me.Label48)
        Me.tabApplication.Controls.Add(Me.Panel1)
        Me.tabApplication.Controls.Add(Me.CheckBox6)
        Me.tabApplication.Controls.Add(Me.CheckBox5)
        Me.tabApplication.Controls.Add(Me.CheckBox4)
        Me.tabApplication.Controls.Add(Me.CheckBox3)
        Me.tabApplication.Controls.Add(Me.CheckBox2)
        Me.tabApplication.Controls.Add(Me.ComboBox4)
        Me.tabApplication.Controls.Add(Me.Label1)
        Me.tabApplication.Controls.Add(Me.TextBox9)
        Me.tabApplication.Controls.Add(Me.Label4)
        Me.tabApplication.Controls.Add(Me.TextBox11)
        Me.tabApplication.Controls.Add(Me.TextBox10)
        Me.tabApplication.Controls.Add(Me.TextBox8)
        Me.tabApplication.Controls.Add(Me.lblDOB)
        Me.tabApplication.Controls.Add(Me.TextBox7)
        Me.tabApplication.Controls.Add(Me.TextBox6)
        Me.tabApplication.Controls.Add(Me.TextBox5)
        Me.tabApplication.Controls.Add(Me.lblSSN)
        Me.tabApplication.Controls.Add(Me.TextBox4)
        Me.tabApplication.Controls.Add(Me.lblPreferredName)
        Me.tabApplication.Controls.Add(Me.lblName)
        Me.tabApplication.Controls.Add(Me.TextBox3)
        Me.tabApplication.Controls.Add(Me.TextBox2)
        Me.tabApplication.Controls.Add(Me.TextBox1)
        Me.tabApplication.Controls.Add(Me.lblMiddleName)
        Me.tabApplication.Controls.Add(Me.lblFirstName)
        Me.tabApplication.Controls.Add(Me.lblLastName)
        Me.tabApplication.Location = New System.Drawing.Point(4, 22)
        Me.tabApplication.Name = "tabApplication"
        Me.tabApplication.Padding = New System.Windows.Forms.Padding(3)
        Me.tabApplication.Size = New System.Drawing.Size(788, 452)
        Me.tabApplication.TabIndex = 0
        Me.tabApplication.Text = "Personal Information"
        Me.tabApplication.UseVisualStyleBackColor = True
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(466, 7)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(60, 13)
        Me.Label49.TabIndex = 71
        Me.Label49.Text = "Citizenship:"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(394, 7)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(45, 13)
        Me.Label48.TabIndex = 70
        Me.Label48.Text = "Gender:"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.TextBox56)
        Me.Panel1.Controls.Add(Me.Label50)
        Me.Panel1.Controls.Add(Me.Label46)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.TextBox19)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.ComboBox3)
        Me.Panel1.Controls.Add(Me.Label17)
        Me.Panel1.Controls.Add(Me.TextBox20)
        Me.Panel1.Controls.Add(Me.Label18)
        Me.Panel1.Controls.Add(Me.Label19)
        Me.Panel1.Controls.Add(Me.Label20)
        Me.Panel1.Controls.Add(Me.TextBox21)
        Me.Panel1.Controls.Add(Me.CheckBox1)
        Me.Panel1.Controls.Add(Me.TextBox16)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.ComboBox2)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.TextBox17)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.TextBox18)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.TextBox15)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.TextBox14)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.ComboBox1)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.TextBox13)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.TextBox12)
        Me.Panel1.Location = New System.Drawing.Point(5, 136)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(777, 310)
        Me.Panel1.TabIndex = 69
        '
        'TextBox56
        '
        Me.TextBox56.Location = New System.Drawing.Point(151, 275)
        Me.TextBox56.Name = "TextBox56"
        Me.TextBox56.Size = New System.Drawing.Size(22, 20)
        Me.TextBox56.TabIndex = 72
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(8, 278)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(137, 13)
        Me.Label50.TabIndex = 71
        Me.Label50.Text = "Years at the above address"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(368, 151)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(116, 13)
        Me.Label46.TabIndex = 70
        Me.Label46.Text = "Telephone Information:"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Label47)
        Me.Panel2.Controls.Add(Me.ComboBox5)
        Me.Panel2.Controls.Add(Me.TextBox24)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.TextBox23)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.TextBox22)
        Me.Panel2.Controls.Add(Me.Label21)
        Me.Panel2.Location = New System.Drawing.Point(368, 168)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(219, 111)
        Me.Panel2.TabIndex = 69
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(3, 85)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(94, 13)
        Me.Label47.TabIndex = 70
        Me.Label47.Text = "Primary Contact #:"
        '
        'ComboBox5
        '
        Me.ComboBox5.FormattingEnabled = True
        Me.ComboBox5.Location = New System.Drawing.Point(120, 82)
        Me.ComboBox5.Name = "ComboBox5"
        Me.ComboBox5.Size = New System.Drawing.Size(77, 21)
        Me.ComboBox5.TabIndex = 69
        '
        'TextBox24
        '
        Me.TextBox24.Location = New System.Drawing.Point(120, 31)
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.Size = New System.Drawing.Size(77, 20)
        Me.TextBox24.TabIndex = 68
        Me.TextBox24.Text = "(000)000-000"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(3, 34)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(70, 13)
        Me.Label3.TabIndex = 67
        Me.Label3.Text = "Work Phone:"
        '
        'TextBox23
        '
        Me.TextBox23.Location = New System.Drawing.Point(120, 56)
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Size = New System.Drawing.Size(77, 20)
        Me.TextBox23.TabIndex = 66
        Me.TextBox23.Text = "(000)000-000"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 59)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(115, 13)
        Me.Label2.TabIndex = 65
        Me.Label2.Text = "Permanent Telephone:"
        '
        'TextBox22
        '
        Me.TextBox22.Location = New System.Drawing.Point(120, 5)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Size = New System.Drawing.Size(77, 20)
        Me.TextBox22.TabIndex = 56
        Me.TextBox22.Text = "(000)000-000"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(3, 8)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(98, 13)
        Me.Label21.TabIndex = 55
        Me.Label21.Text = "Current Telephone:"
        '
        'TextBox19
        '
        Me.TextBox19.Location = New System.Drawing.Point(364, 97)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(87, 20)
        Me.TextBox19.TabIndex = 54
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(326, 100)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(22, 13)
        Me.Label16.TabIndex = 53
        Me.Label16.Text = "Zip"
        '
        'ComboBox3
        '
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(364, 70)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox3.TabIndex = 52
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(324, 73)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(32, 13)
        Me.Label17.TabIndex = 51
        Me.Label17.Text = "State"
        '
        'TextBox20
        '
        Me.TextBox20.Location = New System.Drawing.Point(364, 44)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(273, 20)
        Me.TextBox20.TabIndex = 50
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(324, 45)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(24, 13)
        Me.Label18.TabIndex = 49
        Me.Label18.Text = "City"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(323, 20)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(35, 13)
        Me.Label19.TabIndex = 48
        Me.Label19.Text = "Street"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(323, 3)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(84, 13)
        Me.Label20.TabIndex = 47
        Me.Label20.Text = "Mailing Address:"
        '
        'TextBox21
        '
        Me.TextBox21.Location = New System.Drawing.Point(364, 18)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(273, 20)
        Me.TextBox21.TabIndex = 46
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox1.Location = New System.Drawing.Point(203, 278)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(115, 17)
        Me.CheckBox1.TabIndex = 45
        Me.CheckBox1.Text = "Arkansas Resident"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'TextBox16
        '
        Me.TextBox16.Location = New System.Drawing.Point(46, 250)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(87, 20)
        Me.TextBox16.TabIndex = 43
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(8, 253)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(22, 13)
        Me.Label12.TabIndex = 42
        Me.Label12.Text = "Zip"
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(46, 223)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox2.TabIndex = 41
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(6, 226)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(32, 13)
        Me.Label13.TabIndex = 40
        Me.Label13.Text = "State"
        '
        'TextBox17
        '
        Me.TextBox17.Location = New System.Drawing.Point(46, 197)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(273, 20)
        Me.TextBox17.TabIndex = 39
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(6, 198)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(24, 13)
        Me.Label14.TabIndex = 38
        Me.Label14.Text = "City"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(5, 173)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(35, 13)
        Me.Label15.TabIndex = 37
        Me.Label15.Text = "Street"
        '
        'TextBox18
        '
        Me.TextBox18.Location = New System.Drawing.Point(46, 171)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(273, 20)
        Me.TextBox18.TabIndex = 36
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(5, 155)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(92, 13)
        Me.Label11.TabIndex = 35
        Me.Label11.Text = "Previous Address:"
        '
        'TextBox15
        '
        Me.TextBox15.Location = New System.Drawing.Point(148, 126)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(22, 20)
        Me.TextBox15.TabIndex = 34
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(5, 129)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(137, 13)
        Me.Label10.TabIndex = 33
        Me.Label10.Text = "Years at the above address"
        '
        'TextBox14
        '
        Me.TextBox14.Location = New System.Drawing.Point(43, 97)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(87, 20)
        Me.TextBox14.TabIndex = 32
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(5, 100)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(22, 13)
        Me.Label9.TabIndex = 31
        Me.Label9.Text = "Zip"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(43, 70)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 30
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(3, 73)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(32, 13)
        Me.Label8.TabIndex = 28
        Me.Label8.Text = "State"
        '
        'TextBox13
        '
        Me.TextBox13.Location = New System.Drawing.Point(43, 44)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(273, 20)
        Me.TextBox13.TabIndex = 27
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(3, 45)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(24, 13)
        Me.Label7.TabIndex = 26
        Me.Label7.Text = "City"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(2, 20)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(35, 13)
        Me.Label6.TabIndex = 25
        Me.Label6.Text = "Street"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(1, 3)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(102, 13)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "Permanent Address:"
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(43, 18)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(273, 20)
        Me.TextBox12.TabIndex = 23
        '
        'CheckBox6
        '
        Me.CheckBox6.AutoSize = True
        Me.CheckBox6.Location = New System.Drawing.Point(469, 73)
        Me.CheckBox6.Name = "CheckBox6"
        Me.CheckBox6.Size = New System.Drawing.Size(117, 17)
        Me.CheckBox6.TabIndex = 64
        Me.CheckBox6.Text = "Non-Resident Alien"
        Me.CheckBox6.UseVisualStyleBackColor = True
        '
        'CheckBox5
        '
        Me.CheckBox5.AutoSize = True
        Me.CheckBox5.Location = New System.Drawing.Point(469, 50)
        Me.CheckBox5.Name = "CheckBox5"
        Me.CheckBox5.Size = New System.Drawing.Size(94, 17)
        Me.CheckBox5.TabIndex = 63
        Me.CheckBox5.Text = "Resident Alien"
        Me.CheckBox5.UseVisualStyleBackColor = True
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.Location = New System.Drawing.Point(469, 27)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(81, 17)
        Me.CheckBox4.TabIndex = 62
        Me.CheckBox4.Text = "U.S. Citizen"
        Me.CheckBox4.UseVisualStyleBackColor = True
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Location = New System.Drawing.Point(397, 47)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(60, 17)
        Me.CheckBox3.TabIndex = 61
        Me.CheckBox3.Text = "Female"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Location = New System.Drawing.Point(397, 26)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(49, 17)
        Me.CheckBox2.TabIndex = 60
        Me.CheckBox2.Text = "Male"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'ComboBox4
        '
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Location = New System.Drawing.Point(253, 102)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox4.TabIndex = 59
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(168, 106)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(84, 13)
        Me.Label1.TabIndex = 57
        Me.Label1.Text = "Race / Ethnicity"
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(246, 78)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(128, 20)
        Me.TextBox9.TabIndex = 22
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(168, 81)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(70, 13)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "Place of Birth"
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(294, 53)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(22, 20)
        Me.TextBox11.TabIndex = 17
        Me.TextBox11.Text = "D"
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(323, 53)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(50, 20)
        Me.TextBox10.TabIndex = 16
        Me.TextBox10.Text = "Year"
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(265, 53)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(22, 20)
        Me.TextBox8.TabIndex = 14
        Me.TextBox8.Text = "M"
        '
        'lblDOB
        '
        Me.lblDOB.AutoSize = True
        Me.lblDOB.Location = New System.Drawing.Point(229, 54)
        Me.lblDOB.Name = "lblDOB"
        Me.lblDOB.Size = New System.Drawing.Size(30, 13)
        Me.lblDOB.TabIndex = 13
        Me.lblDOB.Text = "DOB"
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(304, 26)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(28, 20)
        Me.TextBox7.TabIndex = 12
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(338, 26)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(35, 20)
        Me.TextBox6.TabIndex = 11
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(264, 26)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(35, 20)
        Me.TextBox5.TabIndex = 10
        '
        'lblSSN
        '
        Me.lblSSN.AutoSize = True
        Me.lblSSN.Location = New System.Drawing.Point(229, 27)
        Me.lblSSN.Name = "lblSSN"
        Me.lblSSN.Size = New System.Drawing.Size(29, 13)
        Me.lblSSN.TabIndex = 9
        Me.lblSSN.Text = "SSN"
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(62, 103)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(100, 20)
        Me.TextBox4.TabIndex = 8
        '
        'lblPreferredName
        '
        Me.lblPreferredName.AutoSize = True
        Me.lblPreferredName.Location = New System.Drawing.Point(6, 105)
        Me.lblPreferredName.Name = "lblPreferredName"
        Me.lblPreferredName.Size = New System.Drawing.Size(50, 13)
        Me.lblPreferredName.TabIndex = 7
        Me.lblPreferredName.Text = "Preferred"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(6, 7)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(38, 13)
        Me.lblName.TabIndex = 6
        Me.lblName.Text = "Name:"
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(62, 51)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(161, 20)
        Me.TextBox3.TabIndex = 5
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(62, 77)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 4
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(62, 25)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(161, 20)
        Me.TextBox1.TabIndex = 3
        '
        'lblMiddleName
        '
        Me.lblMiddleName.AutoSize = True
        Me.lblMiddleName.Location = New System.Drawing.Point(6, 79)
        Me.lblMiddleName.Name = "lblMiddleName"
        Me.lblMiddleName.Size = New System.Drawing.Size(38, 13)
        Me.lblMiddleName.TabIndex = 2
        Me.lblMiddleName.Text = "Middle"
        '
        'lblFirstName
        '
        Me.lblFirstName.AutoSize = True
        Me.lblFirstName.Location = New System.Drawing.Point(6, 53)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(26, 13)
        Me.lblFirstName.TabIndex = 1
        Me.lblFirstName.Text = "First"
        '
        'lblLastName
        '
        Me.lblLastName.AutoSize = True
        Me.lblLastName.Location = New System.Drawing.Point(7, 26)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(27, 13)
        Me.lblLastName.TabIndex = 0
        Me.lblLastName.Text = "Last"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label52)
        Me.TabPage2.Controls.Add(Me.ComboBox7)
        Me.TabPage2.Controls.Add(Me.Label51)
        Me.TabPage2.Controls.Add(Me.ComboBox6)
        Me.TabPage2.Controls.Add(Me.CheckBox22)
        Me.TabPage2.Controls.Add(Me.TextBox27)
        Me.TabPage2.Controls.Add(Me.Label27)
        Me.TabPage2.Controls.Add(Me.CheckBox21)
        Me.TabPage2.Controls.Add(Me.CheckBox19)
        Me.TabPage2.Controls.Add(Me.CheckBox20)
        Me.TabPage2.Controls.Add(Me.Label26)
        Me.TabPage2.Controls.Add(Me.CheckBox18)
        Me.TabPage2.Controls.Add(Me.TextBox26)
        Me.TabPage2.Controls.Add(Me.Label25)
        Me.TabPage2.Controls.Add(Me.CheckBox17)
        Me.TabPage2.Controls.Add(Me.CheckBox16)
        Me.TabPage2.Controls.Add(Me.CheckBox13)
        Me.TabPage2.Controls.Add(Me.CheckBox12)
        Me.TabPage2.Controls.Add(Me.CheckBox9)
        Me.TabPage2.Controls.Add(Me.Label24)
        Me.TabPage2.Controls.Add(Me.CheckBox7)
        Me.TabPage2.Controls.Add(Me.CheckBox8)
        Me.TabPage2.Controls.Add(Me.TextBox25)
        Me.TabPage2.Controls.Add(Me.Label23)
        Me.TabPage2.Controls.Add(Me.Label22)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(788, 452)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Admission Request"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(252, 133)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(82, 13)
        Me.Label52.TabIndex = 72
        Me.Label52.Text = "Enrollment type:"
        '
        'ComboBox7
        '
        Me.ComboBox7.FormattingEnabled = True
        Me.ComboBox7.Items.AddRange(New Object() {"Full-Time", "Professional (Part-Time)"})
        Me.ComboBox7.Location = New System.Drawing.Point(255, 149)
        Me.ComboBox7.Name = "ComboBox7"
        Me.ComboBox7.Size = New System.Drawing.Size(148, 21)
        Me.ComboBox7.TabIndex = 71
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(35, 133)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(82, 13)
        Me.Label51.TabIndex = 70
        Me.Label51.Text = "Enrollment type:"
        '
        'ComboBox6
        '
        Me.ComboBox6.FormattingEnabled = True
        Me.ComboBox6.Items.AddRange(New Object() {"Full-Time", "Managerial (Part-Time)"})
        Me.ComboBox6.Location = New System.Drawing.Point(38, 149)
        Me.ComboBox6.Name = "ComboBox6"
        Me.ComboBox6.Size = New System.Drawing.Size(140, 21)
        Me.ComboBox6.TabIndex = 69
        '
        'CheckBox22
        '
        Me.CheckBox22.AutoSize = True
        Me.CheckBox22.Location = New System.Drawing.Point(9, 359)
        Me.CheckBox22.Name = "CheckBox22"
        Me.CheckBox22.Size = New System.Drawing.Size(214, 17)
        Me.CheckBox22.TabIndex = 68
        Me.CheckBox22.Text = "Requested Scholarship / Assistantship?"
        Me.CheckBox22.UseVisualStyleBackColor = True
        '
        'TextBox27
        '
        Me.TextBox27.Location = New System.Drawing.Point(130, 243)
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.Size = New System.Drawing.Size(48, 20)
        Me.TextBox27.TabIndex = 67
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(85, 246)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(42, 13)
        Me.Label27.TabIndex = 66
        Me.Label27.Text = "When?"
        '
        'CheckBox21
        '
        Me.CheckBox21.AutoSize = True
        Me.CheckBox21.Location = New System.Drawing.Point(20, 327)
        Me.CheckBox21.Name = "CheckBox21"
        Me.CheckBox21.Size = New System.Drawing.Size(52, 17)
        Me.CheckBox21.TabIndex = 65
        Me.CheckBox21.Text = "Other"
        Me.CheckBox21.UseVisualStyleBackColor = True
        '
        'CheckBox19
        '
        Me.CheckBox19.AutoSize = True
        Me.CheckBox19.Location = New System.Drawing.Point(20, 304)
        Me.CheckBox19.Name = "CheckBox19"
        Me.CheckBox19.Size = New System.Drawing.Size(97, 17)
        Me.CheckBox19.TabIndex = 64
        Me.CheckBox19.Text = "Undergraduate"
        Me.CheckBox19.UseVisualStyleBackColor = True
        '
        'CheckBox20
        '
        Me.CheckBox20.AutoSize = True
        Me.CheckBox20.Location = New System.Drawing.Point(20, 281)
        Me.CheckBox20.Name = "CheckBox20"
        Me.CheckBox20.Size = New System.Drawing.Size(70, 17)
        Me.CheckBox20.TabIndex = 63
        Me.CheckBox20.Text = "Graduate"
        Me.CheckBox20.UseVisualStyleBackColor = True
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(6, 265)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(56, 13)
        Me.Label26.TabIndex = 62
        Me.Label26.Text = "If enrolled:"
        '
        'CheckBox18
        '
        Me.CheckBox18.AutoSize = True
        Me.CheckBox18.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox18.Location = New System.Drawing.Point(6, 245)
        Me.CheckBox18.Name = "CheckBox18"
        Me.CheckBox18.Size = New System.Drawing.Size(70, 17)
        Me.CheckBox18.TabIndex = 61
        Me.CheckBox18.Text = "Enrolled?"
        Me.CheckBox18.UseVisualStyleBackColor = True
        '
        'TextBox26
        '
        Me.TextBox26.Location = New System.Drawing.Point(222, 221)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(48, 20)
        Me.TextBox26.TabIndex = 60
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(177, 224)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(42, 13)
        Me.Label25.TabIndex = 59
        Me.Label25.Text = "When?"
        '
        'CheckBox17
        '
        Me.CheckBox17.AutoSize = True
        Me.CheckBox17.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox17.Location = New System.Drawing.Point(6, 222)
        Me.CheckBox17.Name = "CheckBox17"
        Me.CheckBox17.Size = New System.Drawing.Size(163, 17)
        Me.CheckBox17.TabIndex = 58
        Me.CheckBox17.Text = "Applied to the U of A before?"
        Me.CheckBox17.UseVisualStyleBackColor = True
        '
        'CheckBox16
        '
        Me.CheckBox16.AutoSize = True
        Me.CheckBox16.Location = New System.Drawing.Point(235, 185)
        Me.CheckBox16.Name = "CheckBox16"
        Me.CheckBox16.Size = New System.Drawing.Size(168, 17)
        Me.CheckBox16.TabIndex = 56
        Me.CheckBox16.Text = "Masters of Arts in Econonmics"
        Me.CheckBox16.UseVisualStyleBackColor = True
        '
        'CheckBox13
        '
        Me.CheckBox13.AutoSize = True
        Me.CheckBox13.Location = New System.Drawing.Point(235, 116)
        Me.CheckBox13.Name = "CheckBox13"
        Me.CheckBox13.Size = New System.Drawing.Size(200, 17)
        Me.CheckBox13.TabIndex = 53
        Me.CheckBox13.Text = "Masters of Information Systems (MIS)"
        Me.CheckBox13.UseVisualStyleBackColor = True
        '
        'CheckBox12
        '
        Me.CheckBox12.AutoSize = True
        Me.CheckBox12.Location = New System.Drawing.Point(9, 185)
        Me.CheckBox12.Name = "CheckBox12"
        Me.CheckBox12.Size = New System.Drawing.Size(178, 17)
        Me.CheckBox12.TabIndex = 52
        Me.CheckBox12.Text = "Masters of Accountancy (MAcc)"
        Me.CheckBox12.UseVisualStyleBackColor = True
        '
        'CheckBox9
        '
        Me.CheckBox9.AutoSize = True
        Me.CheckBox9.Location = New System.Drawing.Point(9, 116)
        Me.CheckBox9.Name = "CheckBox9"
        Me.CheckBox9.Size = New System.Drawing.Size(220, 17)
        Me.CheckBox9.TabIndex = 49
        Me.CheckBox9.Text = "Masters of Business Administration (MBA)"
        Me.CheckBox9.UseVisualStyleBackColor = True
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(6, 100)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(60, 13)
        Me.Label24.TabIndex = 48
        Me.Label24.Text = "Applied for:"
        '
        'CheckBox7
        '
        Me.CheckBox7.AutoSize = True
        Me.CheckBox7.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox7.Location = New System.Drawing.Point(20, 70)
        Me.CheckBox7.Name = "CheckBox7"
        Me.CheckBox7.Size = New System.Drawing.Size(42, 17)
        Me.CheckBox7.TabIndex = 47
        Me.CheckBox7.Text = "Fall"
        Me.CheckBox7.UseVisualStyleBackColor = True
        '
        'CheckBox8
        '
        Me.CheckBox8.AutoSize = True
        Me.CheckBox8.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBox8.Location = New System.Drawing.Point(6, 47)
        Me.CheckBox8.Name = "CheckBox8"
        Me.CheckBox8.Size = New System.Drawing.Size(56, 17)
        Me.CheckBox8.TabIndex = 46
        Me.CheckBox8.Text = "Spring"
        Me.CheckBox8.UseVisualStyleBackColor = True
        '
        'TextBox25
        '
        Me.TextBox25.Location = New System.Drawing.Point(45, 21)
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(48, 20)
        Me.TextBox25.TabIndex = 2
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(6, 24)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(32, 13)
        Me.Label23.TabIndex = 1
        Me.Label23.Text = "Year:"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(4, 4)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(126, 13)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "Adminission Request For:"
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.CheckBox30)
        Me.TabPage1.Controls.Add(Me.CheckBox29)
        Me.TabPage1.Controls.Add(Me.TextBox42)
        Me.TabPage1.Controls.Add(Me.TextBox43)
        Me.TabPage1.Controls.Add(Me.CheckBox28)
        Me.TabPage1.Controls.Add(Me.CheckBox27)
        Me.TabPage1.Controls.Add(Me.CheckBox26)
        Me.TabPage1.Controls.Add(Me.CheckBox25)
        Me.TabPage1.Controls.Add(Me.CheckBox24)
        Me.TabPage1.Controls.Add(Me.CheckBox23)
        Me.TabPage1.Controls.Add(Me.CheckBox15)
        Me.TabPage1.Controls.Add(Me.CheckBox14)
        Me.TabPage1.Controls.Add(Me.CheckBox11)
        Me.TabPage1.Controls.Add(Me.CheckBox10)
        Me.TabPage1.Controls.Add(Me.Label64)
        Me.TabPage1.Controls.Add(Me.Label63)
        Me.TabPage1.Controls.Add(Me.Label61)
        Me.TabPage1.Controls.Add(Me.Label62)
        Me.TabPage1.Controls.Add(Me.TextBox99)
        Me.TabPage1.Controls.Add(Me.TextBox100)
        Me.TabPage1.Controls.Add(Me.TextBox101)
        Me.TabPage1.Controls.Add(Me.TextBox102)
        Me.TabPage1.Controls.Add(Me.TextBox103)
        Me.TabPage1.Controls.Add(Me.TextBox104)
        Me.TabPage1.Controls.Add(Me.Label60)
        Me.TabPage1.Controls.Add(Me.TextBox93)
        Me.TabPage1.Controls.Add(Me.TextBox94)
        Me.TabPage1.Controls.Add(Me.TextBox95)
        Me.TabPage1.Controls.Add(Me.TextBox96)
        Me.TabPage1.Controls.Add(Me.TextBox97)
        Me.TabPage1.Controls.Add(Me.TextBox98)
        Me.TabPage1.Controls.Add(Me.Label59)
        Me.TabPage1.Controls.Add(Me.Label58)
        Me.TabPage1.Controls.Add(Me.TextBox87)
        Me.TabPage1.Controls.Add(Me.TextBox88)
        Me.TabPage1.Controls.Add(Me.TextBox89)
        Me.TabPage1.Controls.Add(Me.TextBox90)
        Me.TabPage1.Controls.Add(Me.TextBox91)
        Me.TabPage1.Controls.Add(Me.TextBox92)
        Me.TabPage1.Controls.Add(Me.Label57)
        Me.TabPage1.Controls.Add(Me.TextBox81)
        Me.TabPage1.Controls.Add(Me.TextBox82)
        Me.TabPage1.Controls.Add(Me.TextBox83)
        Me.TabPage1.Controls.Add(Me.TextBox84)
        Me.TabPage1.Controls.Add(Me.TextBox85)
        Me.TabPage1.Controls.Add(Me.TextBox86)
        Me.TabPage1.Controls.Add(Me.Label56)
        Me.TabPage1.Controls.Add(Me.Label55)
        Me.TabPage1.Controls.Add(Me.Label54)
        Me.TabPage1.Controls.Add(Me.TextBox69)
        Me.TabPage1.Controls.Add(Me.TextBox70)
        Me.TabPage1.Controls.Add(Me.TextBox71)
        Me.TabPage1.Controls.Add(Me.TextBox72)
        Me.TabPage1.Controls.Add(Me.TextBox73)
        Me.TabPage1.Controls.Add(Me.TextBox74)
        Me.TabPage1.Controls.Add(Me.TextBox75)
        Me.TabPage1.Controls.Add(Me.TextBox76)
        Me.TabPage1.Controls.Add(Me.TextBox77)
        Me.TabPage1.Controls.Add(Me.TextBox78)
        Me.TabPage1.Controls.Add(Me.TextBox79)
        Me.TabPage1.Controls.Add(Me.TextBox80)
        Me.TabPage1.Controls.Add(Me.TextBox67)
        Me.TabPage1.Controls.Add(Me.TextBox68)
        Me.TabPage1.Controls.Add(Me.TextBox65)
        Me.TabPage1.Controls.Add(Me.TextBox66)
        Me.TabPage1.Controls.Add(Me.TextBox57)
        Me.TabPage1.Controls.Add(Me.TextBox59)
        Me.TabPage1.Controls.Add(Me.TextBox61)
        Me.TabPage1.Controls.Add(Me.TextBox63)
        Me.TabPage1.Controls.Add(Me.TextBox58)
        Me.TabPage1.Controls.Add(Me.TextBox60)
        Me.TabPage1.Controls.Add(Me.TextBox62)
        Me.TabPage1.Controls.Add(Me.TextBox64)
        Me.TabPage1.Controls.Add(Me.Label53)
        Me.TabPage1.Controls.Add(Me.TextBox54)
        Me.TabPage1.Controls.Add(Me.TextBox55)
        Me.TabPage1.Controls.Add(Me.TextBox52)
        Me.TabPage1.Controls.Add(Me.TextBox53)
        Me.TabPage1.Controls.Add(Me.TextBox50)
        Me.TabPage1.Controls.Add(Me.TextBox51)
        Me.TabPage1.Controls.Add(Me.Label45)
        Me.TabPage1.Controls.Add(Me.Label43)
        Me.TabPage1.Controls.Add(Me.TextBox48)
        Me.TabPage1.Controls.Add(Me.Label44)
        Me.TabPage1.Controls.Add(Me.TextBox49)
        Me.TabPage1.Controls.Add(Me.Label42)
        Me.TabPage1.Controls.Add(Me.Label41)
        Me.TabPage1.Controls.Add(Me.TextBox47)
        Me.TabPage1.Controls.Add(Me.Label40)
        Me.TabPage1.Controls.Add(Me.TextBox46)
        Me.TabPage1.Controls.Add(Me.Label37)
        Me.TabPage1.Controls.Add(Me.Label38)
        Me.TabPage1.Controls.Add(Me.TextBox44)
        Me.TabPage1.Controls.Add(Me.Label39)
        Me.TabPage1.Controls.Add(Me.TextBox45)
        Me.TabPage1.Controls.Add(Me.Label36)
        Me.TabPage1.Controls.Add(Me.Label35)
        Me.TabPage1.Controls.Add(Me.TextBox41)
        Me.TabPage1.Controls.Add(Me.Label34)
        Me.TabPage1.Controls.Add(Me.TextBox40)
        Me.TabPage1.Controls.Add(Me.Label33)
        Me.TabPage1.Controls.Add(Me.TextBox34)
        Me.TabPage1.Controls.Add(Me.TextBox35)
        Me.TabPage1.Controls.Add(Me.TextBox36)
        Me.TabPage1.Controls.Add(Me.Label30)
        Me.TabPage1.Controls.Add(Me.TextBox31)
        Me.TabPage1.Controls.Add(Me.TextBox32)
        Me.TabPage1.Controls.Add(Me.TextBox33)
        Me.TabPage1.Controls.Add(Me.Label29)
        Me.TabPage1.Controls.Add(Me.Label32)
        Me.TabPage1.Controls.Add(Me.TextBox37)
        Me.TabPage1.Controls.Add(Me.TextBox38)
        Me.TabPage1.Controls.Add(Me.TextBox39)
        Me.TabPage1.Controls.Add(Me.Label31)
        Me.TabPage1.Controls.Add(Me.TextBox28)
        Me.TabPage1.Controls.Add(Me.TextBox29)
        Me.TabPage1.Controls.Add(Me.TextBox30)
        Me.TabPage1.Controls.Add(Me.Label28)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(788, 452)
        Me.TabPage1.TabIndex = 2
        Me.TabPage1.Text = "Credentials & Documents"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'CheckBox29
        '
        Me.CheckBox29.AutoSize = True
        Me.CheckBox29.Location = New System.Drawing.Point(445, 195)
        Me.CheckBox29.Name = "CheckBox29"
        Me.CheckBox29.Size = New System.Drawing.Size(194, 17)
        Me.CheckBox29.TabIndex = 148
        Me.CheckBox29.Text = "TOEFL (International Students only)"
        Me.CheckBox29.UseVisualStyleBackColor = True
        '
        'TextBox42
        '
        Me.TextBox42.Location = New System.Drawing.Point(369, 59)
        Me.TextBox42.Name = "TextBox42"
        Me.TextBox42.Size = New System.Drawing.Size(31, 20)
        Me.TextBox42.TabIndex = 147
        '
        'TextBox43
        '
        Me.TextBox43.Location = New System.Drawing.Point(369, 29)
        Me.TextBox43.Name = "TextBox43"
        Me.TextBox43.Size = New System.Drawing.Size(31, 20)
        Me.TextBox43.TabIndex = 146
        '
        'CheckBox28
        '
        Me.CheckBox28.AutoSize = True
        Me.CheckBox28.Location = New System.Drawing.Point(445, 179)
        Me.CheckBox28.Name = "CheckBox28"
        Me.CheckBox28.Size = New System.Drawing.Size(371, 17)
        Me.CheckBox28.TabIndex = 145
        Me.CheckBox28.Text = "Supplemental and Financial Information Form (International Students only)"
        Me.CheckBox28.UseVisualStyleBackColor = True
        '
        'CheckBox27
        '
        Me.CheckBox27.AutoSize = True
        Me.CheckBox27.Location = New System.Drawing.Point(445, 163)
        Me.CheckBox27.Name = "CheckBox27"
        Me.CheckBox27.Size = New System.Drawing.Size(328, 17)
        Me.CheckBox27.TabIndex = 144
        Me.CheckBox27.Text = "Summary of educational experience (International Students only)"
        Me.CheckBox27.UseVisualStyleBackColor = True
        '
        'CheckBox26
        '
        Me.CheckBox26.AutoSize = True
        Me.CheckBox26.Location = New System.Drawing.Point(550, 75)
        Me.CheckBox26.Name = "CheckBox26"
        Me.CheckBox26.Size = New System.Drawing.Size(80, 17)
        Me.CheckBox26.TabIndex = 143
        Me.CheckBox26.Text = "GRE Score"
        Me.CheckBox26.UseVisualStyleBackColor = True
        '
        'CheckBox25
        '
        Me.CheckBox25.AutoSize = True
        Me.CheckBox25.Location = New System.Drawing.Point(550, 57)
        Me.CheckBox25.Name = "CheckBox25"
        Me.CheckBox25.Size = New System.Drawing.Size(88, 17)
        Me.CheckBox25.TabIndex = 142
        Me.CheckBox25.Text = "GMAT Score"
        Me.CheckBox25.UseVisualStyleBackColor = True
        '
        'CheckBox24
        '
        Me.CheckBox24.AutoSize = True
        Me.CheckBox24.Location = New System.Drawing.Point(445, 92)
        Me.CheckBox24.Name = "CheckBox24"
        Me.CheckBox24.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CheckBox24.Size = New System.Drawing.Size(104, 17)
        Me.CheckBox24.TabIndex = 141
        Me.CheckBox24.Text = "Essay Questions"
        Me.CheckBox24.UseVisualStyleBackColor = True
        '
        'CheckBox23
        '
        Me.CheckBox23.AutoSize = True
        Me.CheckBox23.Location = New System.Drawing.Point(445, 145)
        Me.CheckBox23.Name = "CheckBox23"
        Me.CheckBox23.Size = New System.Drawing.Size(257, 17)
        Me.CheckBox23.TabIndex = 140
        Me.CheckBox23.Text = "Official Transcripts from each University attended"
        Me.CheckBox23.UseVisualStyleBackColor = True
        '
        'CheckBox15
        '
        Me.CheckBox15.AutoSize = True
        Me.CheckBox15.Location = New System.Drawing.Point(445, 128)
        Me.CheckBox15.Name = "CheckBox15"
        Me.CheckBox15.Size = New System.Drawing.Size(187, 17)
        Me.CheckBox15.TabIndex = 139
        Me.CheckBox15.Text = "Three Letters of Recommendation"
        Me.CheckBox15.UseVisualStyleBackColor = True
        '
        'CheckBox14
        '
        Me.CheckBox14.AutoSize = True
        Me.CheckBox14.Location = New System.Drawing.Point(445, 74)
        Me.CheckBox14.Name = "CheckBox14"
        Me.CheckBox14.Size = New System.Drawing.Size(65, 17)
        Me.CheckBox14.TabIndex = 138
        Me.CheckBox14.Text = "Resume"
        Me.CheckBox14.UseVisualStyleBackColor = True
        '
        'CheckBox11
        '
        Me.CheckBox11.AutoSize = True
        Me.CheckBox11.Location = New System.Drawing.Point(445, 110)
        Me.CheckBox11.Name = "CheckBox11"
        Me.CheckBox11.Size = New System.Drawing.Size(176, 17)
        Me.CheckBox11.TabIndex = 137
        Me.CheckBox11.Text = "Walton College Applicaion Form"
        Me.CheckBox11.UseVisualStyleBackColor = True
        '
        'CheckBox10
        '
        Me.CheckBox10.AutoSize = True
        Me.CheckBox10.Location = New System.Drawing.Point(445, 57)
        Me.CheckBox10.Name = "CheckBox10"
        Me.CheckBox10.Size = New System.Drawing.Size(99, 17)
        Me.CheckBox10.TabIndex = 136
        Me.CheckBox10.Text = "Application Fee"
        Me.CheckBox10.UseVisualStyleBackColor = True
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(442, 13)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(455, 13)
        Me.Label64.TabIndex = 135
        Me.Label64.Text = "The following materials MUST be be submitted BEFORE application is considered COM" & _
            "PLETE:"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Location = New System.Drawing.Point(442, 40)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(60, 13)
        Me.Label63.TabIndex = 134
        Me.Label63.Text = "Check List:"
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Location = New System.Drawing.Point(689, 247)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(96, 13)
        Me.Label61.TabIndex = 133
        Me.Label61.Text = "Current Enrollment:"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(689, 232)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(47, 13)
        Me.Label62.TabIndex = 132
        Me.Label62.Text = "Hours of"
        '
        'TextBox99
        '
        Me.TextBox99.Location = New System.Drawing.Point(692, 389)
        Me.TextBox99.Name = "TextBox99"
        Me.TextBox99.Size = New System.Drawing.Size(50, 20)
        Me.TextBox99.TabIndex = 131
        '
        'TextBox100
        '
        Me.TextBox100.Location = New System.Drawing.Point(692, 363)
        Me.TextBox100.Name = "TextBox100"
        Me.TextBox100.Size = New System.Drawing.Size(50, 20)
        Me.TextBox100.TabIndex = 130
        '
        'TextBox101
        '
        Me.TextBox101.Location = New System.Drawing.Point(692, 339)
        Me.TextBox101.Name = "TextBox101"
        Me.TextBox101.Size = New System.Drawing.Size(50, 20)
        Me.TextBox101.TabIndex = 129
        '
        'TextBox102
        '
        Me.TextBox102.Location = New System.Drawing.Point(692, 313)
        Me.TextBox102.Name = "TextBox102"
        Me.TextBox102.Size = New System.Drawing.Size(50, 20)
        Me.TextBox102.TabIndex = 128
        '
        'TextBox103
        '
        Me.TextBox103.Location = New System.Drawing.Point(692, 288)
        Me.TextBox103.Name = "TextBox103"
        Me.TextBox103.Size = New System.Drawing.Size(50, 20)
        Me.TextBox103.TabIndex = 127
        '
        'TextBox104
        '
        Me.TextBox104.Location = New System.Drawing.Point(692, 263)
        Me.TextBox104.Name = "TextBox104"
        Me.TextBox104.Size = New System.Drawing.Size(50, 20)
        Me.TextBox104.TabIndex = 126
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(549, 247)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(87, 13)
        Me.Label60.TabIndex = 125
        Me.Label60.Text = "Degrees / Major:"
        '
        'TextBox93
        '
        Me.TextBox93.Location = New System.Drawing.Point(552, 389)
        Me.TextBox93.Name = "TextBox93"
        Me.TextBox93.Size = New System.Drawing.Size(134, 20)
        Me.TextBox93.TabIndex = 123
        '
        'TextBox94
        '
        Me.TextBox94.Location = New System.Drawing.Point(552, 363)
        Me.TextBox94.Name = "TextBox94"
        Me.TextBox94.Size = New System.Drawing.Size(134, 20)
        Me.TextBox94.TabIndex = 122
        '
        'TextBox95
        '
        Me.TextBox95.Location = New System.Drawing.Point(552, 339)
        Me.TextBox95.Name = "TextBox95"
        Me.TextBox95.Size = New System.Drawing.Size(134, 20)
        Me.TextBox95.TabIndex = 121
        '
        'TextBox96
        '
        Me.TextBox96.Location = New System.Drawing.Point(552, 313)
        Me.TextBox96.Name = "TextBox96"
        Me.TextBox96.Size = New System.Drawing.Size(134, 20)
        Me.TextBox96.TabIndex = 120
        '
        'TextBox97
        '
        Me.TextBox97.Location = New System.Drawing.Point(552, 288)
        Me.TextBox97.Name = "TextBox97"
        Me.TextBox97.Size = New System.Drawing.Size(134, 20)
        Me.TextBox97.TabIndex = 119
        '
        'TextBox98
        '
        Me.TextBox98.Location = New System.Drawing.Point(552, 263)
        Me.TextBox98.Name = "TextBox98"
        Me.TextBox98.Size = New System.Drawing.Size(134, 20)
        Me.TextBox98.TabIndex = 118
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(475, 247)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(75, 13)
        Me.Label59.TabIndex = 117
        Me.Label59.Text = "Hours Earned:"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(475, 232)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(51, 13)
        Me.Label58.TabIndex = 116
        Me.Label58.Text = "Semester"
        '
        'TextBox87
        '
        Me.TextBox87.Location = New System.Drawing.Point(478, 389)
        Me.TextBox87.Name = "TextBox87"
        Me.TextBox87.Size = New System.Drawing.Size(50, 20)
        Me.TextBox87.TabIndex = 115
        '
        'TextBox88
        '
        Me.TextBox88.Location = New System.Drawing.Point(478, 363)
        Me.TextBox88.Name = "TextBox88"
        Me.TextBox88.Size = New System.Drawing.Size(50, 20)
        Me.TextBox88.TabIndex = 114
        '
        'TextBox89
        '
        Me.TextBox89.Location = New System.Drawing.Point(478, 339)
        Me.TextBox89.Name = "TextBox89"
        Me.TextBox89.Size = New System.Drawing.Size(50, 20)
        Me.TextBox89.TabIndex = 113
        '
        'TextBox90
        '
        Me.TextBox90.Location = New System.Drawing.Point(478, 313)
        Me.TextBox90.Name = "TextBox90"
        Me.TextBox90.Size = New System.Drawing.Size(50, 20)
        Me.TextBox90.TabIndex = 112
        '
        'TextBox91
        '
        Me.TextBox91.Location = New System.Drawing.Point(478, 288)
        Me.TextBox91.Name = "TextBox91"
        Me.TextBox91.Size = New System.Drawing.Size(50, 20)
        Me.TextBox91.TabIndex = 111
        '
        'TextBox92
        '
        Me.TextBox92.Location = New System.Drawing.Point(478, 263)
        Me.TextBox92.Name = "TextBox92"
        Me.TextBox92.Size = New System.Drawing.Size(50, 20)
        Me.TextBox92.TabIndex = 110
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(416, 247)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(32, 13)
        Me.Label57.TabIndex = 109
        Me.Label57.Text = "GPA:"
        '
        'TextBox81
        '
        Me.TextBox81.Location = New System.Drawing.Point(419, 389)
        Me.TextBox81.Name = "TextBox81"
        Me.TextBox81.Size = New System.Drawing.Size(50, 20)
        Me.TextBox81.TabIndex = 108
        '
        'TextBox82
        '
        Me.TextBox82.Location = New System.Drawing.Point(419, 363)
        Me.TextBox82.Name = "TextBox82"
        Me.TextBox82.Size = New System.Drawing.Size(50, 20)
        Me.TextBox82.TabIndex = 107
        '
        'TextBox83
        '
        Me.TextBox83.Location = New System.Drawing.Point(419, 339)
        Me.TextBox83.Name = "TextBox83"
        Me.TextBox83.Size = New System.Drawing.Size(50, 20)
        Me.TextBox83.TabIndex = 106
        '
        'TextBox84
        '
        Me.TextBox84.Location = New System.Drawing.Point(419, 313)
        Me.TextBox84.Name = "TextBox84"
        Me.TextBox84.Size = New System.Drawing.Size(50, 20)
        Me.TextBox84.TabIndex = 105
        '
        'TextBox85
        '
        Me.TextBox85.Location = New System.Drawing.Point(419, 288)
        Me.TextBox85.Name = "TextBox85"
        Me.TextBox85.Size = New System.Drawing.Size(50, 20)
        Me.TextBox85.TabIndex = 104
        '
        'TextBox86
        '
        Me.TextBox86.Location = New System.Drawing.Point(419, 263)
        Me.TextBox86.Name = "TextBox86"
        Me.TextBox86.Size = New System.Drawing.Size(50, 20)
        Me.TextBox86.TabIndex = 103
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(248, 233)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(84, 13)
        Me.Label56.TabIndex = 102
        Me.Label56.Text = "Dates Attended:"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(334, 247)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(33, 13)
        Me.Label55.TabIndex = 101
        Me.Label55.Text = "From:"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(248, 247)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(23, 13)
        Me.Label54.TabIndex = 100
        Me.Label54.Text = "To:"
        '
        'TextBox69
        '
        Me.TextBox69.Location = New System.Drawing.Point(337, 389)
        Me.TextBox69.Name = "TextBox69"
        Me.TextBox69.Size = New System.Drawing.Size(22, 20)
        Me.TextBox69.TabIndex = 99
        Me.TextBox69.Text = "M"
        '
        'TextBox70
        '
        Me.TextBox70.Location = New System.Drawing.Point(364, 389)
        Me.TextBox70.Name = "TextBox70"
        Me.TextBox70.Size = New System.Drawing.Size(50, 20)
        Me.TextBox70.TabIndex = 98
        Me.TextBox70.Text = "Year"
        '
        'TextBox71
        '
        Me.TextBox71.Location = New System.Drawing.Point(337, 363)
        Me.TextBox71.Name = "TextBox71"
        Me.TextBox71.Size = New System.Drawing.Size(22, 20)
        Me.TextBox71.TabIndex = 97
        Me.TextBox71.Text = "M"
        '
        'TextBox72
        '
        Me.TextBox72.Location = New System.Drawing.Point(364, 363)
        Me.TextBox72.Name = "TextBox72"
        Me.TextBox72.Size = New System.Drawing.Size(50, 20)
        Me.TextBox72.TabIndex = 96
        Me.TextBox72.Text = "Year"
        '
        'TextBox73
        '
        Me.TextBox73.Location = New System.Drawing.Point(337, 339)
        Me.TextBox73.Name = "TextBox73"
        Me.TextBox73.Size = New System.Drawing.Size(22, 20)
        Me.TextBox73.TabIndex = 95
        Me.TextBox73.Text = "M"
        '
        'TextBox74
        '
        Me.TextBox74.Location = New System.Drawing.Point(337, 313)
        Me.TextBox74.Name = "TextBox74"
        Me.TextBox74.Size = New System.Drawing.Size(22, 20)
        Me.TextBox74.TabIndex = 94
        Me.TextBox74.Text = "M"
        '
        'TextBox75
        '
        Me.TextBox75.Location = New System.Drawing.Point(337, 288)
        Me.TextBox75.Name = "TextBox75"
        Me.TextBox75.Size = New System.Drawing.Size(22, 20)
        Me.TextBox75.TabIndex = 93
        Me.TextBox75.Text = "M"
        '
        'TextBox76
        '
        Me.TextBox76.Location = New System.Drawing.Point(337, 263)
        Me.TextBox76.Name = "TextBox76"
        Me.TextBox76.Size = New System.Drawing.Size(22, 20)
        Me.TextBox76.TabIndex = 92
        Me.TextBox76.Text = "M"
        '
        'TextBox77
        '
        Me.TextBox77.Location = New System.Drawing.Point(364, 339)
        Me.TextBox77.Name = "TextBox77"
        Me.TextBox77.Size = New System.Drawing.Size(50, 20)
        Me.TextBox77.TabIndex = 91
        Me.TextBox77.Text = "Year"
        '
        'TextBox78
        '
        Me.TextBox78.Location = New System.Drawing.Point(364, 313)
        Me.TextBox78.Name = "TextBox78"
        Me.TextBox78.Size = New System.Drawing.Size(50, 20)
        Me.TextBox78.TabIndex = 90
        Me.TextBox78.Text = "Year"
        '
        'TextBox79
        '
        Me.TextBox79.Location = New System.Drawing.Point(364, 288)
        Me.TextBox79.Name = "TextBox79"
        Me.TextBox79.Size = New System.Drawing.Size(50, 20)
        Me.TextBox79.TabIndex = 89
        Me.TextBox79.Text = "Year"
        '
        'TextBox80
        '
        Me.TextBox80.Location = New System.Drawing.Point(364, 263)
        Me.TextBox80.Name = "TextBox80"
        Me.TextBox80.Size = New System.Drawing.Size(50, 20)
        Me.TextBox80.TabIndex = 88
        Me.TextBox80.Text = "Year"
        '
        'TextBox67
        '
        Me.TextBox67.Location = New System.Drawing.Point(251, 389)
        Me.TextBox67.Name = "TextBox67"
        Me.TextBox67.Size = New System.Drawing.Size(22, 20)
        Me.TextBox67.TabIndex = 87
        Me.TextBox67.Text = "M"
        '
        'TextBox68
        '
        Me.TextBox68.Location = New System.Drawing.Point(277, 389)
        Me.TextBox68.Name = "TextBox68"
        Me.TextBox68.Size = New System.Drawing.Size(50, 20)
        Me.TextBox68.TabIndex = 86
        Me.TextBox68.Text = "Year"
        '
        'TextBox65
        '
        Me.TextBox65.Location = New System.Drawing.Point(251, 363)
        Me.TextBox65.Name = "TextBox65"
        Me.TextBox65.Size = New System.Drawing.Size(22, 20)
        Me.TextBox65.TabIndex = 85
        Me.TextBox65.Text = "M"
        '
        'TextBox66
        '
        Me.TextBox66.Location = New System.Drawing.Point(277, 363)
        Me.TextBox66.Name = "TextBox66"
        Me.TextBox66.Size = New System.Drawing.Size(50, 20)
        Me.TextBox66.TabIndex = 84
        Me.TextBox66.Text = "Year"
        '
        'TextBox57
        '
        Me.TextBox57.Location = New System.Drawing.Point(251, 339)
        Me.TextBox57.Name = "TextBox57"
        Me.TextBox57.Size = New System.Drawing.Size(22, 20)
        Me.TextBox57.TabIndex = 83
        Me.TextBox57.Text = "M"
        '
        'TextBox59
        '
        Me.TextBox59.Location = New System.Drawing.Point(251, 313)
        Me.TextBox59.Name = "TextBox59"
        Me.TextBox59.Size = New System.Drawing.Size(22, 20)
        Me.TextBox59.TabIndex = 82
        Me.TextBox59.Text = "M"
        '
        'TextBox61
        '
        Me.TextBox61.Location = New System.Drawing.Point(251, 288)
        Me.TextBox61.Name = "TextBox61"
        Me.TextBox61.Size = New System.Drawing.Size(22, 20)
        Me.TextBox61.TabIndex = 81
        Me.TextBox61.Text = "M"
        '
        'TextBox63
        '
        Me.TextBox63.Location = New System.Drawing.Point(251, 263)
        Me.TextBox63.Name = "TextBox63"
        Me.TextBox63.Size = New System.Drawing.Size(22, 20)
        Me.TextBox63.TabIndex = 80
        Me.TextBox63.Text = "M"
        '
        'TextBox58
        '
        Me.TextBox58.Location = New System.Drawing.Point(277, 339)
        Me.TextBox58.Name = "TextBox58"
        Me.TextBox58.Size = New System.Drawing.Size(50, 20)
        Me.TextBox58.TabIndex = 79
        Me.TextBox58.Text = "Year"
        '
        'TextBox60
        '
        Me.TextBox60.Location = New System.Drawing.Point(277, 313)
        Me.TextBox60.Name = "TextBox60"
        Me.TextBox60.Size = New System.Drawing.Size(50, 20)
        Me.TextBox60.TabIndex = 77
        Me.TextBox60.Text = "Year"
        '
        'TextBox62
        '
        Me.TextBox62.Location = New System.Drawing.Point(277, 288)
        Me.TextBox62.Name = "TextBox62"
        Me.TextBox62.Size = New System.Drawing.Size(50, 20)
        Me.TextBox62.TabIndex = 75
        Me.TextBox62.Text = "Year"
        '
        'TextBox64
        '
        Me.TextBox64.Location = New System.Drawing.Point(277, 263)
        Me.TextBox64.Name = "TextBox64"
        Me.TextBox64.Size = New System.Drawing.Size(50, 20)
        Me.TextBox64.TabIndex = 73
        Me.TextBox64.Text = "Year"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(9, 246)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(76, 13)
        Me.Label53.TabIndex = 72
        Me.Label53.Text = "College Name:"
        '
        'TextBox54
        '
        Me.TextBox54.Location = New System.Drawing.Point(12, 388)
        Me.TextBox54.Name = "TextBox54"
        Me.TextBox54.Size = New System.Drawing.Size(236, 20)
        Me.TextBox54.TabIndex = 71
        '
        'TextBox55
        '
        Me.TextBox55.Location = New System.Drawing.Point(12, 362)
        Me.TextBox55.Name = "TextBox55"
        Me.TextBox55.Size = New System.Drawing.Size(236, 20)
        Me.TextBox55.TabIndex = 70
        '
        'TextBox52
        '
        Me.TextBox52.Location = New System.Drawing.Point(12, 338)
        Me.TextBox52.Name = "TextBox52"
        Me.TextBox52.Size = New System.Drawing.Size(236, 20)
        Me.TextBox52.TabIndex = 69
        '
        'TextBox53
        '
        Me.TextBox53.Location = New System.Drawing.Point(12, 312)
        Me.TextBox53.Name = "TextBox53"
        Me.TextBox53.Size = New System.Drawing.Size(236, 20)
        Me.TextBox53.TabIndex = 68
        '
        'TextBox50
        '
        Me.TextBox50.Location = New System.Drawing.Point(12, 288)
        Me.TextBox50.Name = "TextBox50"
        Me.TextBox50.Size = New System.Drawing.Size(236, 20)
        Me.TextBox50.TabIndex = 67
        '
        'TextBox51
        '
        Me.TextBox51.Location = New System.Drawing.Point(12, 262)
        Me.TextBox51.Name = "TextBox51"
        Me.TextBox51.Size = New System.Drawing.Size(236, 20)
        Me.TextBox51.TabIndex = 66
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(9, 227)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(176, 13)
        Me.Label45.TabIndex = 65
        Me.Label45.Text = "Colleges Attended (Chronologically):"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(63, 189)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(102, 13)
        Me.Label43.TabIndex = 64
        Me.Label43.Text = "GPA in Jr./Sr. Years"
        '
        'TextBox48
        '
        Me.TextBox48.Location = New System.Drawing.Point(12, 186)
        Me.TextBox48.Name = "TextBox48"
        Me.TextBox48.Size = New System.Drawing.Size(50, 20)
        Me.TextBox48.TabIndex = 63
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(63, 163)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(82, 13)
        Me.Label44.TabIndex = 62
        Me.Label44.Text = "Undergrad GPA"
        '
        'TextBox49
        '
        Me.TextBox49.Location = New System.Drawing.Point(12, 160)
        Me.TextBox49.Name = "TextBox49"
        Me.TextBox49.Size = New System.Drawing.Size(50, 20)
        Me.TextBox49.TabIndex = 61
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(9, 144)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(58, 13)
        Me.Label42.TabIndex = 60
        Me.Label42.Text = "Education:"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(259, 114)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(55, 13)
        Me.Label41.TabIndex = 59
        Me.Label41.Text = "TSE Total"
        '
        'TextBox47
        '
        Me.TextBox47.Location = New System.Drawing.Point(222, 111)
        Me.TextBox47.Name = "TextBox47"
        Me.TextBox47.Size = New System.Drawing.Size(34, 20)
        Me.TextBox47.TabIndex = 58
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(259, 88)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(68, 13)
        Me.Label40.TabIndex = 57
        Me.Label40.Text = "TOEFL Total"
        '
        'TextBox46
        '
        Me.TextBox46.Location = New System.Drawing.Point(222, 85)
        Me.TextBox46.Name = "TextBox46"
        Me.TextBox46.Size = New System.Drawing.Size(34, 20)
        Me.TextBox46.TabIndex = 56
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(400, 62)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(39, 13)
        Me.Label37.TabIndex = 55
        Me.Label37.Text = "Analyt."
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(329, 62)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(36, 13)
        Me.Label38.TabIndex = 53
        Me.Label38.Text = "Quart."
        '
        'TextBox44
        '
        Me.TextBox44.Location = New System.Drawing.Point(298, 59)
        Me.TextBox44.Name = "TextBox44"
        Me.TextBox44.Size = New System.Drawing.Size(31, 20)
        Me.TextBox44.TabIndex = 52
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(259, 62)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(37, 13)
        Me.Label39.TabIndex = 51
        Me.Label39.Text = "Verbal"
        '
        'TextBox45
        '
        Me.TextBox45.Location = New System.Drawing.Point(222, 59)
        Me.TextBox45.Name = "TextBox45"
        Me.TextBox45.Size = New System.Drawing.Size(34, 20)
        Me.TextBox45.TabIndex = 50
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(400, 32)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(31, 13)
        Me.Label36.TabIndex = 49
        Me.Label36.Text = "Total"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(329, 32)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(39, 13)
        Me.Label35.TabIndex = 47
        Me.Label35.Text = "Quant."
        '
        'TextBox41
        '
        Me.TextBox41.Location = New System.Drawing.Point(298, 29)
        Me.TextBox41.Name = "TextBox41"
        Me.TextBox41.Size = New System.Drawing.Size(31, 20)
        Me.TextBox41.TabIndex = 46
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(259, 32)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(37, 13)
        Me.Label34.TabIndex = 45
        Me.Label34.Text = "Verbal"
        '
        'TextBox40
        '
        Me.TextBox40.Location = New System.Drawing.Point(222, 29)
        Me.TextBox40.Name = "TextBox40"
        Me.TextBox40.Size = New System.Drawing.Size(34, 20)
        Me.TextBox40.TabIndex = 44
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(219, 13)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(43, 13)
        Me.Label33.TabIndex = 43
        Me.Label33.Text = "Scores:"
        '
        'TextBox34
        '
        Me.TextBox34.Location = New System.Drawing.Point(36, 111)
        Me.TextBox34.Name = "TextBox34"
        Me.TextBox34.Size = New System.Drawing.Size(22, 20)
        Me.TextBox34.TabIndex = 42
        Me.TextBox34.Text = "D"
        '
        'TextBox35
        '
        Me.TextBox35.Location = New System.Drawing.Point(61, 111)
        Me.TextBox35.Name = "TextBox35"
        Me.TextBox35.Size = New System.Drawing.Size(50, 20)
        Me.TextBox35.TabIndex = 41
        Me.TextBox35.Text = "Year"
        '
        'TextBox36
        '
        Me.TextBox36.Location = New System.Drawing.Point(12, 111)
        Me.TextBox36.Name = "TextBox36"
        Me.TextBox36.Size = New System.Drawing.Size(22, 20)
        Me.TextBox36.TabIndex = 40
        Me.TextBox36.Text = "M"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(111, 114)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(28, 13)
        Me.Label30.TabIndex = 39
        Me.Label30.Text = "TSE"
        '
        'TextBox31
        '
        Me.TextBox31.Location = New System.Drawing.Point(36, 85)
        Me.TextBox31.Name = "TextBox31"
        Me.TextBox31.Size = New System.Drawing.Size(22, 20)
        Me.TextBox31.TabIndex = 38
        Me.TextBox31.Text = "D"
        '
        'TextBox32
        '
        Me.TextBox32.Location = New System.Drawing.Point(61, 85)
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.Size = New System.Drawing.Size(50, 20)
        Me.TextBox32.TabIndex = 37
        Me.TextBox32.Text = "Year"
        '
        'TextBox33
        '
        Me.TextBox33.Location = New System.Drawing.Point(12, 85)
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.Size = New System.Drawing.Size(22, 20)
        Me.TextBox33.TabIndex = 36
        Me.TextBox33.Text = "M"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(111, 88)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(41, 13)
        Me.Label29.TabIndex = 35
        Me.Label29.Text = "TOEFL"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(3, 13)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(175, 13)
        Me.Label32.TabIndex = 34
        Me.Label32.Text = "Test Dates (Taken or to be Taken):"
        '
        'TextBox37
        '
        Me.TextBox37.Location = New System.Drawing.Point(36, 59)
        Me.TextBox37.Name = "TextBox37"
        Me.TextBox37.Size = New System.Drawing.Size(22, 20)
        Me.TextBox37.TabIndex = 33
        Me.TextBox37.Text = "D"
        '
        'TextBox38
        '
        Me.TextBox38.Location = New System.Drawing.Point(61, 59)
        Me.TextBox38.Name = "TextBox38"
        Me.TextBox38.Size = New System.Drawing.Size(50, 20)
        Me.TextBox38.TabIndex = 32
        Me.TextBox38.Text = "Year"
        '
        'TextBox39
        '
        Me.TextBox39.Location = New System.Drawing.Point(12, 59)
        Me.TextBox39.Name = "TextBox39"
        Me.TextBox39.Size = New System.Drawing.Size(22, 20)
        Me.TextBox39.TabIndex = 31
        Me.TextBox39.Text = "M"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(111, 62)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(102, 13)
        Me.Label31.TabIndex = 30
        Me.Label31.Text = "GRE (MAEcon only)"
        '
        'TextBox28
        '
        Me.TextBox28.Location = New System.Drawing.Point(36, 33)
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.Size = New System.Drawing.Size(22, 20)
        Me.TextBox28.TabIndex = 21
        Me.TextBox28.Text = "D"
        '
        'TextBox29
        '
        Me.TextBox29.Location = New System.Drawing.Point(61, 33)
        Me.TextBox29.Name = "TextBox29"
        Me.TextBox29.Size = New System.Drawing.Size(50, 20)
        Me.TextBox29.TabIndex = 20
        Me.TextBox29.Text = "Year"
        '
        'TextBox30
        '
        Me.TextBox30.Location = New System.Drawing.Point(12, 33)
        Me.TextBox30.Name = "TextBox30"
        Me.TextBox30.Size = New System.Drawing.Size(22, 20)
        Me.TextBox30.TabIndex = 19
        Me.TextBox30.Text = "M"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(111, 36)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(38, 13)
        Me.Label28.TabIndex = 0
        Me.Label28.Text = "GMAT"
        '
        'CheckBox30
        '
        Me.CheckBox30.AutoSize = True
        Me.CheckBox30.Location = New System.Drawing.Point(445, 210)
        Me.CheckBox30.Name = "CheckBox30"
        Me.CheckBox30.Size = New System.Drawing.Size(210, 17)
        Me.CheckBox30.TabIndex = 149
        Me.CheckBox30.Text = "TSE (International MIS Applicants only)"
        Me.CheckBox30.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(842, 641)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Professional_MIS"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.tabApplication.ResumeLayout(False)
        Me.tabApplication.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tabApplication As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents lblMiddleName As System.Windows.Forms.Label
    Friend WithEvents lblFirstName As System.Windows.Forms.Label
    Friend WithEvents lblLastName As System.Windows.Forms.Label
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents lblDOB As System.Windows.Forms.Label
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents lblSSN As System.Windows.Forms.Label
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents lblPreferredName As System.Windows.Forms.Label
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox4 As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CheckBox6 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox5 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox4 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox3 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox7 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox8 As System.Windows.Forms.CheckBox
    Friend WithEvents TextBox25 As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents CheckBox9 As System.Windows.Forms.CheckBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents CheckBox12 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox18 As System.Windows.Forms.CheckBox
    Friend WithEvents TextBox26 As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents CheckBox17 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox16 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox13 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox22 As System.Windows.Forms.CheckBox
    Friend WithEvents TextBox27 As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents CheckBox21 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox19 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox20 As System.Windows.Forms.CheckBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TextBox37 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox38 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox39 As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents TextBox28 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox29 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox30 As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents TextBox41 As System.Windows.Forms.TextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents TextBox40 As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents TextBox34 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox35 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox36 As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents TextBox31 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox32 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox33 As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents TextBox47 As System.Windows.Forms.TextBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents TextBox46 As System.Windows.Forms.TextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents TextBox44 As System.Windows.Forms.TextBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents TextBox45 As System.Windows.Forms.TextBox
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents TextBox48 As System.Windows.Forms.TextBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents TextBox49 As System.Windows.Forms.TextBox
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents TextBox54 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox55 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox52 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox53 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox50 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox51 As System.Windows.Forms.TextBox
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents ComboBox5 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox24 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBox23 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBox22 As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents TextBox19 As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents TextBox20 As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents TextBox21 As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents TextBox17 As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TextBox18 As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox56 As System.Windows.Forms.TextBox
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents ComboBox6 As System.Windows.Forms.ComboBox
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents ComboBox7 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox67 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox68 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox65 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox66 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox57 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox59 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox61 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox63 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox58 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox60 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox62 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox64 As System.Windows.Forms.TextBox
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents TextBox87 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox88 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox89 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox90 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox91 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox92 As System.Windows.Forms.TextBox
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents TextBox81 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox82 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox83 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox84 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox85 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox86 As System.Windows.Forms.TextBox
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents TextBox69 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox70 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox71 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox72 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox73 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox74 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox75 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox76 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox77 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox78 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox79 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox80 As System.Windows.Forms.TextBox
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents TextBox93 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox94 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox95 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox96 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox97 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox98 As System.Windows.Forms.TextBox
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents TextBox99 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox100 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox101 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox102 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox103 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox104 As System.Windows.Forms.TextBox
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents CheckBox11 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox10 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox14 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox26 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox25 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox24 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox23 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox15 As System.Windows.Forms.CheckBox
    Friend WithEvents TextBox42 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox43 As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox28 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox27 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox29 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox30 As System.Windows.Forms.CheckBox

End Class
