<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmApplicationForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmApplicationForm))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EditToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.tabApplication = New System.Windows.Forms.TabControl
        Me.tabPersonalInfo = New System.Windows.Forms.TabPage
        Me.cbxFState = New System.Windows.Forms.ComboBox
        Me.cbxLState = New System.Windows.Forms.ComboBox
        Me.cbxPState = New System.Windows.Forms.ComboBox
        Me.txtPZipCode = New System.Windows.Forms.MaskedTextBox
        Me.txtLZipCode = New System.Windows.Forms.MaskedTextBox
        Me.txtFZipCode = New System.Windows.Forms.MaskedTextBox
        Me.txtPPhone = New System.Windows.Forms.MaskedTextBox
        Me.txtWorkPhone = New System.Windows.Forms.MaskedTextBox
        Me.txtCurrentPhone = New System.Windows.Forms.MaskedTextBox
        Me.txtBirthday1 = New System.Windows.Forms.MaskedTextBox
        Me.txtSSN = New System.Windows.Forms.MaskedTextBox
        Me.cbxOrigin = New System.Windows.Forms.ComboBox
        Me.txtEmail = New System.Windows.Forms.TextBox
        Me.Label72 = New System.Windows.Forms.Label
        Me.cbxCitizenship = New System.Windows.Forms.ComboBox
        Me.cbxGender = New System.Windows.Forms.ComboBox
        Me.txtStudentID = New System.Windows.Forms.TextBox
        Me.Label71 = New System.Windows.Forms.Label
        Me.Label66 = New System.Windows.Forms.Label
        Me.Label47 = New System.Windows.Forms.Label
        Me.cbxPrimaryContactNumber = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label65 = New System.Windows.Forms.Label
        Me.txtFYears = New System.Windows.Forms.TextBox
        Me.Label50 = New System.Windows.Forms.Label
        Me.Label46 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.txtLCity = New System.Windows.Forms.TextBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.txtLAddress = New System.Windows.Forms.TextBox
        Me.chkResident = New System.Windows.Forms.CheckBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.txtFCity = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.txtFAddress = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.txtPYears = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtPCity = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtPAddress = New System.Windows.Forms.TextBox
        Me.Label49 = New System.Windows.Forms.Label
        Me.Label48 = New System.Windows.Forms.Label
        Me.cbxEthnic = New System.Windows.Forms.ComboBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.lblDOB = New System.Windows.Forms.Label
        Me.lblSSN = New System.Windows.Forms.Label
        Me.txtPreferred = New System.Windows.Forms.TextBox
        Me.lblPreferredName = New System.Windows.Forms.Label
        Me.lblName = New System.Windows.Forms.Label
        Me.txtFirstName = New System.Windows.Forms.TextBox
        Me.txtMiddleName = New System.Windows.Forms.TextBox
        Me.txtLastName = New System.Windows.Forms.TextBox
        Me.lblMiddleName = New System.Windows.Forms.Label
        Me.lblFirstName = New System.Windows.Forms.Label
        Me.lblLastName = New System.Windows.Forms.Label
        Me.TabAdmission = New System.Windows.Forms.TabPage
        Me.Label67 = New System.Windows.Forms.Label
        Me.cbxStanding = New System.Windows.Forms.ComboBox
        Me.lblSession = New System.Windows.Forms.Label
        Me.cbxSession = New System.Windows.Forms.ComboBox
        Me.chkRequested = New System.Windows.Forms.CheckBox
        Me.txtEnrolled_When = New System.Windows.Forms.TextBox
        Me.Label27 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.chkEnrolled = New System.Windows.Forms.CheckBox
        Me.txtBefore_when = New System.Windows.Forms.TextBox
        Me.Label25 = New System.Windows.Forms.Label
        Me.chkBefore = New System.Windows.Forms.CheckBox
        Me.txtRequestYear = New System.Windows.Forms.TextBox
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.tabCredentials = New System.Windows.Forms.TabPage
        Me.txtCFrom1 = New System.Windows.Forms.TextBox
        Me.txtCFrom2 = New System.Windows.Forms.TextBox
        Me.txtCTo1 = New System.Windows.Forms.TextBox
        Me.txtCTo2 = New System.Windows.Forms.TextBox
        Me.Label95 = New System.Windows.Forms.Label
        Me.Label94 = New System.Windows.Forms.Label
        Me.txtDegreeDate2 = New System.Windows.Forms.TextBox
        Me.txtDegreeDate1 = New System.Windows.Forms.TextBox
        Me.Label93 = New System.Windows.Forms.Label
        Me.txtMajor2 = New System.Windows.Forms.TextBox
        Me.txtMajor1 = New System.Windows.Forms.TextBox
        Me.Label61 = New System.Windows.Forms.Label
        Me.Label62 = New System.Windows.Forms.Label
        Me.txtCurrentHours2 = New System.Windows.Forms.TextBox
        Me.txtCurrentHours1 = New System.Windows.Forms.TextBox
        Me.Label60 = New System.Windows.Forms.Label
        Me.txtDegree2 = New System.Windows.Forms.TextBox
        Me.txtDegree1 = New System.Windows.Forms.TextBox
        Me.Label59 = New System.Windows.Forms.Label
        Me.Label58 = New System.Windows.Forms.Label
        Me.txtHoursEarned2 = New System.Windows.Forms.TextBox
        Me.txtHoursEarned1 = New System.Windows.Forms.TextBox
        Me.Label57 = New System.Windows.Forms.Label
        Me.txtCGPA2 = New System.Windows.Forms.TextBox
        Me.txtCGPA1 = New System.Windows.Forms.TextBox
        Me.Label56 = New System.Windows.Forms.Label
        Me.Label55 = New System.Windows.Forms.Label
        Me.Label54 = New System.Windows.Forms.Label
        Me.Label53 = New System.Windows.Forms.Label
        Me.txtCName2 = New System.Windows.Forms.TextBox
        Me.txtCName1 = New System.Windows.Forms.TextBox
        Me.Label24 = New System.Windows.Forms.Label
        Me.txtTSEDate = New System.Windows.Forms.TextBox
        Me.txtTOEFLDate = New System.Windows.Forms.TextBox
        Me.Label70 = New System.Windows.Forms.Label
        Me.Label69 = New System.Windows.Forms.Label
        Me.Label68 = New System.Windows.Forms.Label
        Me.chkTSE = New System.Windows.Forms.CheckBox
        Me.chkTOEFL = New System.Windows.Forms.CheckBox
        Me.txtGMATTotal = New System.Windows.Forms.TextBox
        Me.chkFinancial = New System.Windows.Forms.CheckBox
        Me.chkEducation = New System.Windows.Forms.CheckBox
        Me.chkGREScore = New System.Windows.Forms.CheckBox
        Me.chkGMATScore = New System.Windows.Forms.CheckBox
        Me.chkEssay = New System.Windows.Forms.CheckBox
        Me.chkTranscript = New System.Windows.Forms.CheckBox
        Me.chkLOR = New System.Windows.Forms.CheckBox
        Me.chkResume = New System.Windows.Forms.CheckBox
        Me.chkAppForm = New System.Windows.Forms.CheckBox
        Me.chkAppFeePaid = New System.Windows.Forms.CheckBox
        Me.Label64 = New System.Windows.Forms.Label
        Me.Label63 = New System.Windows.Forms.Label
        Me.Label43 = New System.Windows.Forms.Label
        Me.txtGPASenior = New System.Windows.Forms.TextBox
        Me.Label44 = New System.Windows.Forms.Label
        Me.txtUnderGPA = New System.Windows.Forms.TextBox
        Me.Label42 = New System.Windows.Forms.Label
        Me.Label41 = New System.Windows.Forms.Label
        Me.txtTSETotal = New System.Windows.Forms.TextBox
        Me.Label40 = New System.Windows.Forms.Label
        Me.txtTOEFLTotal = New System.Windows.Forms.TextBox
        Me.Label36 = New System.Windows.Forms.Label
        Me.Label35 = New System.Windows.Forms.Label
        Me.txtGMATQuant = New System.Windows.Forms.TextBox
        Me.Label34 = New System.Windows.Forms.Label
        Me.txtGMATVerbal = New System.Windows.Forms.TextBox
        Me.Label33 = New System.Windows.Forms.Label
        Me.Label30 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.Label32 = New System.Windows.Forms.Label
        Me.txtGMATDate = New System.Windows.Forms.TextBox
        Me.Label28 = New System.Windows.Forms.Label
        Me.tabStudentStatus = New System.Windows.Forms.TabPage
        Me.Label51 = New System.Windows.Forms.Label
        Me.txtNotes = New System.Windows.Forms.TextBox
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.txtDateAccepted = New System.Windows.Forms.TextBox
        Me.txtAcceptedOffer = New System.Windows.Forms.TextBox
        Me.txtDDate = New System.Windows.Forms.TextBox
        Me.txtDeclined = New System.Windows.Forms.TextBox
        Me.txtDEnrolled = New System.Windows.Forms.TextBox
        Me.txtSEnrolled = New System.Windows.Forms.TextBox
        Me.txtDateApplied = New System.Windows.Forms.TextBox
        Me.txtAStatus = New System.Windows.Forms.TextBox
        Me.txtFeePaid = New System.Windows.Forms.TextBox
        Me.txtStatus = New System.Windows.Forms.TextBox
        Me.Label102 = New System.Windows.Forms.Label
        Me.Label101 = New System.Windows.Forms.Label
        Me.Label100 = New System.Windows.Forms.Label
        Me.lblStudentID = New System.Windows.Forms.Label
        Me.Label98 = New System.Windows.Forms.Label
        Me.lblStudentName = New System.Windows.Forms.Label
        Me.Label96 = New System.Windows.Forms.Label
        Me.Label92 = New System.Windows.Forms.Label
        Me.Label89 = New System.Windows.Forms.Label
        Me.Label88 = New System.Windows.Forms.Label
        Me.Label86 = New System.Windows.Forms.Label
        Me.Label84 = New System.Windows.Forms.Label
        Me.Label82 = New System.Windows.Forms.Label
        Me.Label80 = New System.Windows.Forms.Label
        Me.Label77 = New System.Windows.Forms.Label
        Me.Label75 = New System.Windows.Forms.Label
        Me.Label74 = New System.Windows.Forms.Label
        Me.btnAddRecord = New System.Windows.Forms.Button
        Me.btnEditRecord = New System.Windows.Forms.Button
        Me.btnDeleteRecord = New System.Windows.Forms.Button
        Me.btnSearchRecord = New System.Windows.Forms.Button
        Me.lblSearchDescription = New System.Windows.Forms.Label
        Me.Label103 = New System.Windows.Forms.Label
        Me.btnSaveChanges = New System.Windows.Forms.Button
        Me.btnClearSearchFields = New System.Windows.Forms.Button
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.Label52 = New System.Windows.Forms.Label
        Me.lblBirthdayFormat = New System.Windows.Forms.Label
        Me.Label31 = New System.Windows.Forms.Label
        Me.Label37 = New System.Windows.Forms.Label
        Me.Label38 = New System.Windows.Forms.Label
        Me.Label39 = New System.Windows.Forms.Label
        Me.Label45 = New System.Windows.Forms.Label
        Me.Label73 = New System.Windows.Forms.Label
        Me.Label76 = New System.Windows.Forms.Label
        Me.Label78 = New System.Windows.Forms.Label
        Me.Label79 = New System.Windows.Forms.Label
        Me.MenuStrip1.SuspendLayout()
        Me.tabApplication.SuspendLayout()
        Me.tabPersonalInfo.SuspendLayout()
        Me.TabAdmission.SuspendLayout()
        Me.tabCredentials.SuspendLayout()
        Me.tabStudentStatus.SuspendLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.EditToolStripMenuItem, Me.ViewToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(863, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(35, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(103, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EditToolStripMenuItem1})
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'EditToolStripMenuItem1
        '
        Me.EditToolStripMenuItem1.Name = "EditToolStripMenuItem1"
        Me.EditToolStripMenuItem1.Size = New System.Drawing.Size(103, 22)
        Me.EditToolStripMenuItem1.Text = "Edit"
        '
        'ViewToolStripMenuItem
        '
        Me.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem"
        Me.ViewToolStripMenuItem.Size = New System.Drawing.Size(41, 20)
        Me.ViewToolStripMenuItem.Text = "View"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'tabApplication
        '
        Me.tabApplication.Controls.Add(Me.tabPersonalInfo)
        Me.tabApplication.Controls.Add(Me.TabAdmission)
        Me.tabApplication.Controls.Add(Me.tabCredentials)
        Me.tabApplication.Controls.Add(Me.tabStudentStatus)
        Me.tabApplication.Location = New System.Drawing.Point(22, 144)
        Me.tabApplication.Name = "tabApplication"
        Me.tabApplication.SelectedIndex = 0
        Me.tabApplication.Size = New System.Drawing.Size(809, 478)
        Me.tabApplication.TabIndex = 1
        '
        'tabPersonalInfo
        '
        Me.tabPersonalInfo.Controls.Add(Me.lblBirthdayFormat)
        Me.tabPersonalInfo.Controls.Add(Me.cbxFState)
        Me.tabPersonalInfo.Controls.Add(Me.cbxLState)
        Me.tabPersonalInfo.Controls.Add(Me.cbxPState)
        Me.tabPersonalInfo.Controls.Add(Me.txtPZipCode)
        Me.tabPersonalInfo.Controls.Add(Me.txtLZipCode)
        Me.tabPersonalInfo.Controls.Add(Me.txtFZipCode)
        Me.tabPersonalInfo.Controls.Add(Me.txtPPhone)
        Me.tabPersonalInfo.Controls.Add(Me.txtWorkPhone)
        Me.tabPersonalInfo.Controls.Add(Me.txtCurrentPhone)
        Me.tabPersonalInfo.Controls.Add(Me.txtBirthday1)
        Me.tabPersonalInfo.Controls.Add(Me.txtSSN)
        Me.tabPersonalInfo.Controls.Add(Me.cbxOrigin)
        Me.tabPersonalInfo.Controls.Add(Me.txtEmail)
        Me.tabPersonalInfo.Controls.Add(Me.Label72)
        Me.tabPersonalInfo.Controls.Add(Me.cbxCitizenship)
        Me.tabPersonalInfo.Controls.Add(Me.cbxGender)
        Me.tabPersonalInfo.Controls.Add(Me.txtStudentID)
        Me.tabPersonalInfo.Controls.Add(Me.Label71)
        Me.tabPersonalInfo.Controls.Add(Me.Label66)
        Me.tabPersonalInfo.Controls.Add(Me.Label47)
        Me.tabPersonalInfo.Controls.Add(Me.cbxPrimaryContactNumber)
        Me.tabPersonalInfo.Controls.Add(Me.Label3)
        Me.tabPersonalInfo.Controls.Add(Me.Label2)
        Me.tabPersonalInfo.Controls.Add(Me.Label21)
        Me.tabPersonalInfo.Controls.Add(Me.Label65)
        Me.tabPersonalInfo.Controls.Add(Me.txtFYears)
        Me.tabPersonalInfo.Controls.Add(Me.Label50)
        Me.tabPersonalInfo.Controls.Add(Me.Label46)
        Me.tabPersonalInfo.Controls.Add(Me.Label16)
        Me.tabPersonalInfo.Controls.Add(Me.Label17)
        Me.tabPersonalInfo.Controls.Add(Me.txtLCity)
        Me.tabPersonalInfo.Controls.Add(Me.Label18)
        Me.tabPersonalInfo.Controls.Add(Me.Label19)
        Me.tabPersonalInfo.Controls.Add(Me.Label20)
        Me.tabPersonalInfo.Controls.Add(Me.txtLAddress)
        Me.tabPersonalInfo.Controls.Add(Me.chkResident)
        Me.tabPersonalInfo.Controls.Add(Me.Label12)
        Me.tabPersonalInfo.Controls.Add(Me.Label13)
        Me.tabPersonalInfo.Controls.Add(Me.txtFCity)
        Me.tabPersonalInfo.Controls.Add(Me.Label14)
        Me.tabPersonalInfo.Controls.Add(Me.Label15)
        Me.tabPersonalInfo.Controls.Add(Me.txtFAddress)
        Me.tabPersonalInfo.Controls.Add(Me.Label11)
        Me.tabPersonalInfo.Controls.Add(Me.txtPYears)
        Me.tabPersonalInfo.Controls.Add(Me.Label10)
        Me.tabPersonalInfo.Controls.Add(Me.Label9)
        Me.tabPersonalInfo.Controls.Add(Me.Label8)
        Me.tabPersonalInfo.Controls.Add(Me.txtPCity)
        Me.tabPersonalInfo.Controls.Add(Me.Label7)
        Me.tabPersonalInfo.Controls.Add(Me.Label6)
        Me.tabPersonalInfo.Controls.Add(Me.Label5)
        Me.tabPersonalInfo.Controls.Add(Me.txtPAddress)
        Me.tabPersonalInfo.Controls.Add(Me.Label49)
        Me.tabPersonalInfo.Controls.Add(Me.Label48)
        Me.tabPersonalInfo.Controls.Add(Me.cbxEthnic)
        Me.tabPersonalInfo.Controls.Add(Me.Label1)
        Me.tabPersonalInfo.Controls.Add(Me.Label4)
        Me.tabPersonalInfo.Controls.Add(Me.lblDOB)
        Me.tabPersonalInfo.Controls.Add(Me.lblSSN)
        Me.tabPersonalInfo.Controls.Add(Me.txtPreferred)
        Me.tabPersonalInfo.Controls.Add(Me.lblPreferredName)
        Me.tabPersonalInfo.Controls.Add(Me.lblName)
        Me.tabPersonalInfo.Controls.Add(Me.txtFirstName)
        Me.tabPersonalInfo.Controls.Add(Me.txtMiddleName)
        Me.tabPersonalInfo.Controls.Add(Me.txtLastName)
        Me.tabPersonalInfo.Controls.Add(Me.lblMiddleName)
        Me.tabPersonalInfo.Controls.Add(Me.lblFirstName)
        Me.tabPersonalInfo.Controls.Add(Me.lblLastName)
        Me.tabPersonalInfo.Location = New System.Drawing.Point(4, 22)
        Me.tabPersonalInfo.Name = "tabPersonalInfo"
        Me.tabPersonalInfo.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPersonalInfo.Size = New System.Drawing.Size(801, 452)
        Me.tabPersonalInfo.TabIndex = 0
        Me.tabPersonalInfo.Text = "Personal Information"
        Me.tabPersonalInfo.UseVisualStyleBackColor = True
        '
        'cbxFState
        '
        Me.cbxFState.FormattingEnabled = True
        Me.cbxFState.Items.AddRange(New Object() {"ALABAMA", "ALASKA", "AMERICAN SAMOA", "ARIZONA", "ARKANSAS", "CALIFORNIA", "COLORADO", "CONNECTICUT", "DELAWARE", "DISTRICT OF COLUMBIA", "FEDERATED STATES OF MICRONESIA", "FLORIDA", "GEORGIA", "GUAM", "HAWAII", "IDAHO", "ILLINOIS", "INDIANA", "IOWA", "KANSAS", "KENTUCKY", "LOUISIANA", "MAINE", "MARSHALL ISLANDS", "MARYLAND", "MASSACHUSETTS", "MICHIGAN", "MINNESOTA", "MISSISSIPPI", "MISSOURI", "MONTANA", "NEBRASKA", "NEVADA", "NEW HAMPSHIRE", "NEW JERSEY", "NEW MEXICO", "NEW YORK", "NORTH CAROLINA", "NORTH DAKOTA", "NORTHERN MARIANA ISLANDS", "OHIO", "OKLAHOMA", "OREGON", "PALAU", "PENNSYLVANIA", "PUERTO RICO", "RHODE ISLAND", "SOUTH CAROLINA", "SOUTH DAKOTA", "TENNESSEE", "TEXAS", "UTAH", "VERMONT", "VIRGIN ISLANDS", "VIRGINIA", "WASHINGTON", "WEST VIRGINIA", "WISCONSIN", "WYOMING"})
        Me.cbxFState.Location = New System.Drawing.Point(51, 369)
        Me.cbxFState.Name = "cbxFState"
        Me.cbxFState.Size = New System.Drawing.Size(121, 21)
        Me.cbxFState.TabIndex = 23
        '
        'cbxLState
        '
        Me.cbxLState.FormattingEnabled = True
        Me.cbxLState.Items.AddRange(New Object() {"ALABAMA", "ALASKA", "AMERICAN SAMOA", "ARIZONA", "ARKANSAS", "CALIFORNIA", "COLORADO", "CONNECTICUT", "DELAWARE", "DISTRICT OF COLUMBIA", "FEDERATED STATES OF MICRONESIA", "FLORIDA", "GEORGIA", "GUAM", "HAWAII", "IDAHO", "ILLINOIS", "INDIANA", "IOWA", "KANSAS", "KENTUCKY", "LOUISIANA", "MAINE", "MARSHALL ISLANDS", "MARYLAND", "MASSACHUSETTS", "MICHIGAN", "MINNESOTA", "MISSISSIPPI", "MISSOURI", "MONTANA", "NEBRASKA", "NEVADA", "NEW HAMPSHIRE", "NEW JERSEY", "NEW MEXICO", "NEW YORK", "NORTH CAROLINA", "NORTH DAKOTA", "NORTHERN MARIANA ISLANDS", "OHIO", "OKLAHOMA", "OREGON", "PALAU", "PENNSYLVANIA", "PUERTO RICO", "RHODE ISLAND", "SOUTH CAROLINA", "SOUTH DAKOTA", "TENNESSEE", "TEXAS", "UTAH", "VERMONT", "VIRGIN ISLANDS", "VIRGINIA", "WASHINGTON", "WEST VIRGINIA", "WISCONSIN", "WYOMING"})
        Me.cbxLState.Location = New System.Drawing.Point(369, 216)
        Me.cbxLState.Name = "cbxLState"
        Me.cbxLState.Size = New System.Drawing.Size(121, 21)
        Me.cbxLState.TabIndex = 19
        '
        'cbxPState
        '
        Me.cbxPState.FormattingEnabled = True
        Me.cbxPState.Items.AddRange(New Object() {"ALABAMA", "ALASKA", "AMERICAN SAMOA", "ARIZONA", "ARKANSAS", "CALIFORNIA", "COLORADO", "CONNECTICUT", "DELAWARE", "DISTRICT OF COLUMBIA", "FEDERATED STATES OF MICRONESIA", "FLORIDA", "GEORGIA", "GUAM", "HAWAII", "IDAHO", "ILLINOIS", "INDIANA", "IOWA", "KANSAS", "KENTUCKY", "LOUISIANA", "MAINE", "MARSHALL ISLANDS", "MARYLAND", "MASSACHUSETTS", "MICHIGAN", "MINNESOTA", "MISSISSIPPI", "MISSOURI", "MONTANA", "NEBRASKA", "NEVADA", "NEW HAMPSHIRE", "NEW JERSEY", "NEW MEXICO", "NEW YORK", "NORTH CAROLINA", "NORTH DAKOTA", "NORTHERN MARIANA ISLANDS", "OHIO", "OKLAHOMA", "OREGON", "PALAU", "PENNSYLVANIA", "PUERTO RICO", "RHODE ISLAND", "SOUTH CAROLINA", "SOUTH DAKOTA", "TENNESSEE", "TEXAS", "UTAH", "VERMONT", "VIRGIN ISLANDS", "VIRGINIA", "WASHINGTON", "WEST VIRGINIA", "WISCONSIN", "WYOMING"})
        Me.cbxPState.Location = New System.Drawing.Point(48, 216)
        Me.cbxPState.Name = "cbxPState"
        Me.cbxPState.Size = New System.Drawing.Size(121, 21)
        Me.cbxPState.TabIndex = 14
        '
        'txtPZipCode
        '
        Me.txtPZipCode.Location = New System.Drawing.Point(47, 243)
        Me.txtPZipCode.Mask = "00000-0000"
        Me.txtPZipCode.Name = "txtPZipCode"
        Me.txtPZipCode.Size = New System.Drawing.Size(75, 20)
        Me.txtPZipCode.TabIndex = 15
        Me.txtPZipCode.ValidatingType = GetType(Integer)
        '
        'txtLZipCode
        '
        Me.txtLZipCode.Location = New System.Drawing.Point(370, 243)
        Me.txtLZipCode.Mask = "00000-0000"
        Me.txtLZipCode.Name = "txtLZipCode"
        Me.txtLZipCode.Size = New System.Drawing.Size(75, 20)
        Me.txtLZipCode.TabIndex = 20
        Me.txtLZipCode.ValidatingType = GetType(Integer)
        '
        'txtFZipCode
        '
        Me.txtFZipCode.Location = New System.Drawing.Point(51, 396)
        Me.txtFZipCode.Mask = "00000-0000"
        Me.txtFZipCode.Name = "txtFZipCode"
        Me.txtFZipCode.Size = New System.Drawing.Size(75, 20)
        Me.txtFZipCode.TabIndex = 24
        Me.txtFZipCode.ValidatingType = GetType(Integer)
        '
        'txtPPhone
        '
        Me.txtPPhone.Location = New System.Drawing.Point(512, 369)
        Me.txtPPhone.Mask = "(999) 000-0000"
        Me.txtPPhone.Name = "txtPPhone"
        Me.txtPPhone.Size = New System.Drawing.Size(100, 20)
        Me.txtPPhone.TabIndex = 29
        '
        'txtWorkPhone
        '
        Me.txtWorkPhone.Location = New System.Drawing.Point(512, 347)
        Me.txtWorkPhone.Mask = "(999) 000-0000"
        Me.txtWorkPhone.Name = "txtWorkPhone"
        Me.txtWorkPhone.Size = New System.Drawing.Size(100, 20)
        Me.txtWorkPhone.TabIndex = 28
        '
        'txtCurrentPhone
        '
        Me.txtCurrentPhone.Location = New System.Drawing.Point(512, 321)
        Me.txtCurrentPhone.Mask = "(999) 000-0000"
        Me.txtCurrentPhone.Name = "txtCurrentPhone"
        Me.txtCurrentPhone.Size = New System.Drawing.Size(100, 20)
        Me.txtCurrentPhone.TabIndex = 27
        '
        'txtBirthday1
        '
        Me.txtBirthday1.Location = New System.Drawing.Point(222, 103)
        Me.txtBirthday1.Name = "txtBirthday1"
        Me.txtBirthday1.Size = New System.Drawing.Size(71, 20)
        Me.txtBirthday1.TabIndex = 7
        '
        'txtSSN
        '
        Me.txtSSN.Location = New System.Drawing.Point(222, 75)
        Me.txtSSN.Name = "txtSSN"
        Me.txtSSN.Size = New System.Drawing.Size(71, 20)
        Me.txtSSN.TabIndex = 6
        '
        'cbxOrigin
        '
        Me.cbxOrigin.FormattingEnabled = True
        Me.cbxOrigin.Items.AddRange(New Object() {"Abkhazia � Republic of Abkhazia[5]", "Afghanistan Afghanistan � Islamic Republic of Afghanistan", "the United Kingdom Akrotiri and Dhekelia � Sovereign Base Areas of Akrotiri and D" & _
                        "hekelia (UK overseas territory)", "�land Islands �land � �land Islands (Autonomous province of Finland)", "Albania Albania � Republic of Albania", "Algeria Algeria � People's Democratic Republic of Algeria", "American Samoa American Samoa � Territory of American Samoa (US territory)", "Andorra Andorra � Principality of Andorra", "Angola Angola � Republic of Angola", "Anguilla Anguilla (UK overseas territory)", "Antigua and Barbuda Antigua and Barbuda", "Argentina Argentina � Argentine Republic[11]", "Armenia Armenia � Republic of Armenia", "Aruba Aruba (Self-governing country in the Kingdom of the Netherlands)", "the United Kingdom Ascension Island (Dependency of the UK overseas territory of S" & _
                        "aint Helena)", "Australia Australia � Commonwealth of Australia", "Austria Austria � Republic of Austria", "Azerbaijan Azerbaijan � Republic of Azerbaijan[12]", "the Bahamas Bahamas, The � Commonwealth of The Bahamas", "Bahrain Bahrain � Kingdom of Bahrain", "Bangladesh Bangladesh � People's Republic of Bangladesh", "Barbados Barbados", "Belarus Belarus � Republic of Belarus", "Belgium Belgium � Kingdom of Belgium", "Belize Belize", "Benin Benin � Republic of Benin", "Bermuda Bermuda (UK overseas territory)", "Bhutan Bhutan � Kingdom of Bhutan", "Bolivia Bolivia � Republic of Bolivia", "Bosnia and Herzegovina Bosnia and Herzegovina[13]", "Botswana Botswana � Republic of Botswana", "Brazil Brazil � Federative Republic of Brazil", "Brunei Brunei � Negara Brunei Darussalam", "Bulgaria Bulgaria � Republic of Bulgaria", "Burkina Faso Burkina Faso", """Burma"", see Myanmar", "Burundi Burundi � Republic of Burundi", "Cambodia Cambodia � Kingdom of Cambodia", "Cameroon Cameroon � Republic of Cameroon", "Canada Canada[14]", "Cape Verde Cape Verde � Republic of Cape Verde", "Cayman Islands Cayman Islands (UK overseas territory)", "the Central African Republic Central African Republic[15]", "Chad Chad � Republic of Chad", "Chile Chile � Republic of Chile", "the People's Republic of China China, People's Republic of � People's Republic of" & _
                        " China[16]", "the Republic of China China, Republic of � Republic of China [17]", "Christmas Island Christmas Island � Territory of Christmas Island (Australian ove" & _
                        "rseas territory)", "the Cocos (Keeling) Islands Cocos (Keeling) Islands � Territory of Cocos (Keeling" & _
                        ") Islands (Australian overseas territory)", "Colombia Colombia � Republic of Colombia", "the Comoros Comoros � Union of the Comoros", "the Democratic Republic of the Congo Congo � Democratic Republic of the Congo[18]" & _
                        "", "the Republic of the Congo Congo � Republic of the Congo[19]", "the Cook Islands Cook Islands (Associated state of New Zealand)", "Costa Rica Costa Rica � Republic of Costa Rica", "C�te d'Ivoire C�te d'Ivoire � Republic of C�te d'Ivoire", "Croatia Croatia � Republic of Croatia", "Cuba Cuba � Republic of Cuba", "Cyprus Cyprus � Republic of Cyprus[20]", "the Czech Republic Czech Republic[21]", "Denmark Denmark � Kingdom of Denmark", """Dhekelia"", see Akrotiri and Dhekelia", "Djibouti Djibouti � Republic of Djibouti", "Dominica Dominica � Commonwealth of Dominica", "the Dominican Republic Dominican Republic", "East Timor East Timor � Democratic Republic of Timor-Leste", "Ecuador Ecuador � Republic of Ecuador", "Egypt Egypt � Arab Republic of Egypt", "El Salvador El Salvador � Republic of El Salvador", "Equatorial Guinea Equatorial Guinea � Republic of Equatorial Guinea", "Eritrea Eritrea � State of Eritrea", "Estonia Estonia � Republic of Estonia", "Ethiopia Ethiopia � Federal Democratic Republic of Ethiopia", "the Falkland Islands Falkland Islands (UK overseas territory)[22]", "the Faroe Islands Faroe Islands (Self-governing country in the Kingdom of Denmark" & _
                        ")", "Fiji Fiji � Republic of the Fiji Islands", "Finland Finland � Republic of Finland", "France France � French Republic", "French Polynesia French Polynesia (French overseas collectivity)", "Gabon Gabon � Gabonese Republic", "The Gambia Gambia, The � Republic of The Gambia", "Georgia (country) Georgia[23]", "Germany Germany � Federal Republic of Germany", "Ghana Ghana � Republic of Ghana", "Gibraltar Gibraltar (UK overseas territory)", "Greece Greece � Hellenic Republic", "Greenland Greenland (Self-governing country in the Kingdom of Denmark)", "Grenada Grenada", "Guam Guam � Territory of Guam (US organized territory)", "Guatemala Guatemala � Republic of Guatemala", "Guernsey Guernsey � Bailiwick of Guernsey (British Crown dependency)[24]", "Guinea Guinea � Republic of Guinea", "Guinea-Bissau Guinea-Bissau � Republic of Guinea-Bissau", "Guyana Guyana � Co-operative Republic of Guyana", "Haiti Haiti � Republic of Haiti", "Honduras Honduras � Republic of Honduras", "Hong Kong Hong Kong � Hong Kong Special Administrative Region of the People's Rep" & _
                        "ublic of China (Area of special sovereignty)[25]", "Hungary Hungary � Republic of Hungary", "Iceland Iceland � Republic of Iceland", "India India � Republic of India", "Indonesia Indonesia � Republic of Indonesia", "Iran Iran � Islamic Republic of Iran", "Iraq Iraq � Republic of Iraq", "Ireland Ireland - Republic of Ireland[26]", "the Isle of Man Isle of Man (British Crown dependency)", "Israel Israel � State of Israel", "Italy Italy � Italian Republic", """Ivory Coast"", see C�te d'Ivoire", "Jamaica Jamaica", "Japan Japan", "Jersey Jersey � Bailiwick of Jersey (British Crown dependency)", "Jordan Jordan � Hashemite Kingdom of Jordan", "Kazakhstan Kazakhstan � Republic of Kazakhstan", "Kenya Kenya � Republic of Kenya", "Kiribati Kiribati � Republic of Kiribati", "North Korea Korea, North � Democratic People's Republic of Korea[27]", "South Korea Korea, South � Republic of Korea[28]", "Kosovo Kosovo � Republic of Kosovo[3]", "Kuwait Kuwait � State of Kuwait", "Kyrgyzstan Kyrgyzstan � Kyrgyz Republic[29]", "Laos Laos � Lao People's Democratic Republic", "Latvia Latvia � Republic of Latvia", "Lebanon Lebanon � Republic of Lebanon", "Lesotho Lesotho � Kingdom of Lesotho", "Liberia Liberia � Republic of Liberia", "Libya Libya � Great Socialist People's Libyan Arab Jamahiriya", "Liechtenstein Liechtenstein � Principality of Liechtenstein", "Lithuania Lithuania � Republic of Lithuania", "Luxembourg Luxembourg � Grand Duchy of Luxembourg", "Macau Macao � Macao Special Administrative Region of the People's Republic of Chi" & _
                        "na (Area of special sovereignty)[30]", "the Republic of Macedonia Macedonia � Republic of Macedonia[31]", "Madagascar Madagascar � Republic of Madagascar", "Malawi Malawi � Republic of Malawi", "Malaysia Malaysia", "the Maldives Maldives � Republic of Maldives", "Mali Mali � Republic of Mali", "Malta Malta � Republic of Malta", "the Marshall Islands Marshall Islands � Republic of the Marshall Islands", "Mauritania Mauritania � Islamic Republic of Mauritania", "Mauritius Mauritius � Republic of Mauritius", "Mayotte Mayotte � Departmental Collectivity of Mayotte (French overseas collectiv" & _
                        "ity)", "Mexico Mexico � United Mexican States", "the Federated States of Micronesia Micronesia � Federated States of Micronesia", "Moldova Moldova � Republic of Moldova[32]", "Monaco Monaco � Principality of Monaco", "Mongolia Mongolia", "Montenegro Montenegro � Republic of Montenegro", "Montserrat Montserrat (UK overseas territory)", "Morocco Morocco � Kingdom of Morocco[33]", "Mozambique Mozambique � Republic of Mozambique", "Burma Myanmar � Union of Myanmar", "Nagorno-Karabakh Republic Nagorno-Karabakh � Nagorno-Karabakh Republic[6]", "Namibia Namibia � Republic of Namibia", "Nauru Nauru � Republic of Nauru", "Nepal Nepal � State of Nepal", "the Netherlands Netherlands � Kingdom of the Netherlands[34]", "the Netherlands Antilles Netherlands Antilles (Self-governing country in the King" & _
                        "dom of the Netherlands)", "New Caledonia New Caledonia � Territory of New Caledonia and Dependencies (French" & _
                        " community sui generis)", "New Zealand New Zealand", "Nicaragua Nicaragua � Republic of Nicaragua", "Niger Niger � Republic of Niger", "Nigeria Nigeria � Federal Republic of Nigeria", "Niue Niue (Associated state of New Zealand)", "Norfolk Island Norfolk Island � Territory of Norfolk Island (Australian overseas " & _
                        "territory)", "the Turkish Republic of Northern Cyprus Northern Cyprus � Turkish Republic of Nor" & _
                        "thern Cyprus[4]", "the Northern Mariana Islands Northern Mariana Islands � Commonwealth of the North" & _
                        "ern Mariana Islands (US commonwealth)", """North Korea"", see Korea, North", "Norway Norway � Kingdom of Norway", "Oman Oman � Sultanate of Oman", "Pakistan Pakistan � Islamic Republic of Pakistan", "Palau Palau � Republic of Palau", "Palestinian flag Palestine � Occupied Palestinian Territories[35]", "Panama Panama � Republic of Panama", "Papua New Guinea Papua New Guinea � Independent State of Papua New Guinea", "Paraguay Paraguay � Republic of Paraguay", """People's Republic of China"", see China, People's Republic of", "Peru Peru � Republic of Peru", "the Philippines Philippines � Republic of the Philippines", "the Pitcairn Islands Pitcairn Islands � Pitcairn, Henderson, Ducie, and Oeno Isla" & _
                        "nds (UK overseas territory)", "Poland Poland � Republic of Poland", "Portugal Portugal � Portuguese Republic", """Pridnestrovie"", see Transnistria", "Puerto Rico Puerto Rico � Commonwealth of Puerto Rico (US commonwealth)", "Qatar Qatar � State of Qatar", """Republic of China"", see China, Republic of", "Romania Romania", "Russia Russia � Russian Federation", "Rwanda Rwanda � Republic of Rwanda", "Saint Barth�lemy Saint Barth�lemy � Collectivity of Saint Barth�lemy (French over" & _
                        "seas collectivity)", "Saint Helena Saint Helena (UK overseas territory)", "Saint Kitts and Nevis Saint Kitts and Nevis � Federation of Saint Christopher and" & _
                        " Nevis", "Saint Lucia Saint Lucia", "Saint Martin (France) Saint Martin � Collectivity of Saint Martin (French oversea" & _
                        "s collectivity)", "Saint Pierre and Miquelon Saint Pierre and Miquelon � Territorial Collectivity of" & _
                        " Saint Pierre and Miquelon (French overseas collectivity)", "Saint Vincent and the Grenadines Saint Vincent and the Grenadines", "Samoa Samoa � Independent State of Samoa", "San Marino San Marino � Most Serene Republic of San Marino", "S�o Tom� and Pr�ncipe S�o Tom� and Pr�ncipe � Democratic Republic of S�o Tom� and" & _
                        " Pr�ncipe", "Saudi Arabia Saudi Arabia � Kingdom of Saudi Arabia", "Senegal Senegal � Republic of Senegal", "Serbia Serbia � Republic of Serbia[36]", "the Seychelles Seychelles � Republic of Seychelles", "Sierra Leone Sierra Leone � Republic of Sierra Leone", "Singapore Singapore � Republic of Singapore", "Slovakia Slovakia � Slovak Republic", "Slovenia Slovenia � Republic of Slovenia", "the Solomon Islands Solomon Islands", "Somalia Somalia[37]", "Somaliland Somaliland � Republic of Somaliland[8]", "South Africa South Africa � Republic of South Africa", """South Korea"", see Korea, South", "South Ossetia South Ossetia � Republic of South Ossetia[9]", "Spain Spain � Kingdom of Spain", "Sri Lanka Sri Lanka � Democratic Socialist Republic of Sri Lanka", "Sudan Sudan � Republic of the Sudan", "Suriname Suriname � Republic of Suriname", "Svalbard Svalbard (Territory of Norway)[38]", "Swaziland Swaziland � Kingdom of Swaziland", "Sweden Sweden � Kingdom of Sweden", "Switzerland Switzerland � Swiss Confederation", "Syria Syria � Syrian Arab Republic", """Taiwan"", see China, Republic of", "Tajikistan Tajikistan � Republic of Tajikistan", "Tanzania Tanzania � United Republic of Tanzania", "Thailand Thailand � Kingdom of Thailand", """Timor-Leste"", see East Timor", "Togo Togo � Togolese Republic", "Tokelau Tokelau (Overseas territory of New Zealand)", "Tonga Tonga � Kingdom of Tonga", "Transnistria Transnistria � Transnistrian Moldovan Republic[7]", "Trinidad and Tobago Trinidad and Tobago � Republic of Trinidad and Tobago", "Tristan da Cunha Tristan da Cunha (Dependency of the UK overseas territory of Sai" & _
                        "nt Helena)", "Tunisia Tunisia � Tunisian Republic", "Turkey Turkey � Republic of Turkey", "Turkmenistan Turkmenistan", "the Turks and Caicos Islands Turks and Caicos Islands (UK overseas territory)", "Tuvalu Tuvalu", "Uganda Uganda � Republic of Uganda", "Ukraine Ukraine", "the United Arab Emirates United Arab Emirates", "the United Kingdom United Kingdom � United Kingdom of Great Britain and Northern " & _
                        "Ireland", "the United States United States � United States of America", "Uruguay Uruguay � Eastern Republic of Uruguay", "Uzbekistan Uzbekistan � Republic of Uzbekistan", "Vanuatu Vanuatu � Republic of Vanuatu", "the Vatican City Vatican City � State of the Vatican City[39]", "Venezuela Venezuela � Bolivarian Republic of Venezuela", "Vietnam Vietnam � Socialist Republic of Vietnam", "the British Virgin Islands Virgin Islands, British � British Virgin Islands (UK o" & _
                        "verseas territory)", "the United States Virgin Islands Virgin Islands, United States � United States Vi" & _
                        "rgin Islands (US organized territory)", "Wallis and Futuna Wallis and Futuna � Territory of Wallis and Futuna Islands (Fre" & _
                        "nch overseas collectivity)", "Western Sahara Western Sahara[40]", "Yemen Yemen � Republic of Yemen", """Zaire"", see Democratic Republic of the Congo", "Zambia Zambia � Republic of Zambia", "Zimbabwe Zimbabwe � Republic of Zimbabwe"})
        Me.cbxOrigin.Location = New System.Drawing.Point(365, 24)
        Me.cbxOrigin.Name = "cbxOrigin"
        Me.cbxOrigin.Size = New System.Drawing.Size(121, 21)
        Me.cbxOrigin.TabIndex = 8
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(480, 420)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(132, 20)
        Me.txtEmail.TabIndex = 31
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.Location = New System.Drawing.Point(394, 423)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(80, 13)
        Me.Label72.TabIndex = 235
        Me.Label72.Text = "Email Address*:"
        '
        'cbxCitizenship
        '
        Me.cbxCitizenship.FormattingEnabled = True
        Me.cbxCitizenship.Items.AddRange(New Object() {"U.S. Citizen", "Resident Alien", "Non-Resident Alien"})
        Me.cbxCitizenship.Location = New System.Drawing.Point(503, 24)
        Me.cbxCitizenship.Name = "cbxCitizenship"
        Me.cbxCitizenship.Size = New System.Drawing.Size(121, 21)
        Me.cbxCitizenship.TabIndex = 11
        '
        'cbxGender
        '
        Me.cbxGender.FormattingEnabled = True
        Me.cbxGender.Items.AddRange(New Object() {"Male", "Female"})
        Me.cbxGender.Location = New System.Drawing.Point(365, 105)
        Me.cbxGender.Name = "cbxGender"
        Me.cbxGender.Size = New System.Drawing.Size(121, 21)
        Me.cbxGender.TabIndex = 10
        '
        'txtStudentID
        '
        Me.txtStudentID.Location = New System.Drawing.Point(222, 25)
        Me.txtStudentID.Name = "txtStudentID"
        Me.txtStudentID.Size = New System.Drawing.Size(128, 20)
        Me.txtStudentID.TabIndex = 5
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Location = New System.Drawing.Point(219, 7)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(62, 13)
        Me.Label71.TabIndex = 205
        Me.Label71.Text = "Student ID*"
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Location = New System.Drawing.Point(331, 275)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(439, 13)
        Me.Label66.TabIndex = 315
        Me.Label66.Text = "________________________________________________________________________"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(393, 398)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(94, 13)
        Me.Label47.TabIndex = 234
        Me.Label47.Text = "Primary Contact #:"
        '
        'cbxPrimaryContactNumber
        '
        Me.cbxPrimaryContactNumber.FormattingEnabled = True
        Me.cbxPrimaryContactNumber.Items.AddRange(New Object() {"Local", "Work", "Permanent"})
        Me.cbxPrimaryContactNumber.Location = New System.Drawing.Point(513, 395)
        Me.cbxPrimaryContactNumber.Name = "cbxPrimaryContactNumber"
        Me.cbxPrimaryContactNumber.Size = New System.Drawing.Size(99, 21)
        Me.cbxPrimaryContactNumber.TabIndex = 30
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(393, 347)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(70, 13)
        Me.Label3.TabIndex = 232
        Me.Label3.Text = "Work Phone:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(393, 372)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(115, 13)
        Me.Label2.TabIndex = 233
        Me.Label2.Text = "Permanent Telephone:"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(393, 321)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(90, 13)
        Me.Label21.TabIndex = 231
        Me.Label21.Text = "Local Telephone:"
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(5, 129)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(769, 13)
        Me.Label65.TabIndex = 314
        Me.Label65.Text = "_________________________________________________________________________________" & _
            "______________________________________________"
        '
        'txtFYears
        '
        Me.txtFYears.Location = New System.Drawing.Point(156, 421)
        Me.txtFYears.Name = "txtFYears"
        Me.txtFYears.Size = New System.Drawing.Size(22, 20)
        Me.txtFYears.TabIndex = 25
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(13, 424)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(137, 13)
        Me.Label50.TabIndex = 228
        Me.Label50.Text = "Years at the above address"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(388, 301)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(102, 13)
        Me.Label46.TabIndex = 230
        Me.Label46.Text = "Contact Information:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(331, 246)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(22, 13)
        Me.Label16.TabIndex = 222
        Me.Label16.Text = "Zip"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(329, 219)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(32, 13)
        Me.Label17.TabIndex = 221
        Me.Label17.Text = "State"
        '
        'txtLCity
        '
        Me.txtLCity.Location = New System.Drawing.Point(369, 190)
        Me.txtLCity.Name = "txtLCity"
        Me.txtLCity.Size = New System.Drawing.Size(273, 20)
        Me.txtLCity.TabIndex = 18
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(329, 191)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(24, 13)
        Me.Label18.TabIndex = 220
        Me.Label18.Text = "City"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(328, 166)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(35, 13)
        Me.Label19.TabIndex = 219
        Me.Label19.Text = "Street"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(328, 149)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(84, 13)
        Me.Label20.TabIndex = 218
        Me.Label20.Text = "Mailing Address:"
        '
        'txtLAddress
        '
        Me.txtLAddress.Location = New System.Drawing.Point(369, 164)
        Me.txtLAddress.Name = "txtLAddress"
        Me.txtLAddress.Size = New System.Drawing.Size(273, 20)
        Me.txtLAddress.TabIndex = 17
        '
        'chkResident
        '
        Me.chkResident.AutoSize = True
        Me.chkResident.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkResident.Location = New System.Drawing.Point(208, 424)
        Me.chkResident.Name = "chkResident"
        Me.chkResident.Size = New System.Drawing.Size(115, 17)
        Me.chkResident.TabIndex = 26
        Me.chkResident.Text = "Arkansas Resident"
        Me.chkResident.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(13, 399)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(22, 13)
        Me.Label12.TabIndex = 227
        Me.Label12.Text = "Zip"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(11, 372)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(32, 13)
        Me.Label13.TabIndex = 226
        Me.Label13.Text = "State"
        '
        'txtFCity
        '
        Me.txtFCity.Location = New System.Drawing.Point(51, 343)
        Me.txtFCity.Name = "txtFCity"
        Me.txtFCity.Size = New System.Drawing.Size(273, 20)
        Me.txtFCity.TabIndex = 22
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(11, 344)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(24, 13)
        Me.Label14.TabIndex = 225
        Me.Label14.Text = "City"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(10, 319)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(35, 13)
        Me.Label15.TabIndex = 224
        Me.Label15.Text = "Street"
        '
        'txtFAddress
        '
        Me.txtFAddress.Location = New System.Drawing.Point(51, 317)
        Me.txtFAddress.Name = "txtFAddress"
        Me.txtFAddress.Size = New System.Drawing.Size(273, 20)
        Me.txtFAddress.TabIndex = 21
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(10, 301)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(83, 13)
        Me.Label11.TabIndex = 223
        Me.Label11.Text = "Former Address:"
        '
        'txtPYears
        '
        Me.txtPYears.Location = New System.Drawing.Point(153, 272)
        Me.txtPYears.Name = "txtPYears"
        Me.txtPYears.Size = New System.Drawing.Size(22, 20)
        Me.txtPYears.TabIndex = 16
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(10, 275)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(137, 13)
        Me.Label10.TabIndex = 217
        Me.Label10.Text = "Years at the above address"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(10, 246)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(22, 13)
        Me.Label9.TabIndex = 216
        Me.Label9.Text = "Zip"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(8, 219)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(32, 13)
        Me.Label8.TabIndex = 215
        Me.Label8.Text = "State"
        '
        'txtPCity
        '
        Me.txtPCity.Location = New System.Drawing.Point(48, 190)
        Me.txtPCity.Name = "txtPCity"
        Me.txtPCity.Size = New System.Drawing.Size(273, 20)
        Me.txtPCity.TabIndex = 13
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(8, 191)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(24, 13)
        Me.Label7.TabIndex = 214
        Me.Label7.Text = "City"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(7, 166)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(35, 13)
        Me.Label6.TabIndex = 213
        Me.Label6.Text = "Street"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 149)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(102, 13)
        Me.Label5.TabIndex = 212
        Me.Label5.Text = "Permanent Address:"
        '
        'txtPAddress
        '
        Me.txtPAddress.Location = New System.Drawing.Point(48, 164)
        Me.txtPAddress.Name = "txtPAddress"
        Me.txtPAddress.Size = New System.Drawing.Size(273, 20)
        Me.txtPAddress.TabIndex = 12
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(500, 7)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(60, 13)
        Me.Label49.TabIndex = 211
        Me.Label49.Text = "Citizenship:"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(362, 89)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(45, 13)
        Me.Label48.TabIndex = 210
        Me.Label48.Text = "Gender:"
        '
        'cbxEthnic
        '
        Me.cbxEthnic.FormattingEnabled = True
        Me.cbxEthnic.Items.AddRange(New Object() {"Alaskan Native or American Indian", "Black, Non-Hispanic", "Asian or Pacific Islander", "White, Non-Hispanic", "Hispanic"})
        Me.cbxEthnic.Location = New System.Drawing.Point(365, 65)
        Me.cbxEthnic.Name = "cbxEthnic"
        Me.cbxEthnic.Size = New System.Drawing.Size(121, 21)
        Me.cbxEthnic.TabIndex = 9
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(362, 49)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(84, 13)
        Me.Label1.TabIndex = 209
        Me.Label1.Text = "Race / Ethnicity"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(362, 7)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(70, 13)
        Me.Label4.TabIndex = 208
        Me.Label4.Text = "Place of Birth"
        '
        'lblDOB
        '
        Me.lblDOB.AutoSize = True
        Me.lblDOB.Location = New System.Drawing.Point(177, 105)
        Me.lblDOB.Name = "lblDOB"
        Me.lblDOB.Size = New System.Drawing.Size(30, 13)
        Me.lblDOB.TabIndex = 207
        Me.lblDOB.Text = "DOB"
        '
        'lblSSN
        '
        Me.lblSSN.AutoSize = True
        Me.lblSSN.Location = New System.Drawing.Point(177, 78)
        Me.lblSSN.Name = "lblSSN"
        Me.lblSSN.Size = New System.Drawing.Size(33, 13)
        Me.lblSSN.TabIndex = 206
        Me.lblSSN.Text = "SSN*"
        '
        'txtPreferred
        '
        Me.txtPreferred.Location = New System.Drawing.Point(62, 103)
        Me.txtPreferred.Name = "txtPreferred"
        Me.txtPreferred.Size = New System.Drawing.Size(100, 20)
        Me.txtPreferred.TabIndex = 4
        '
        'lblPreferredName
        '
        Me.lblPreferredName.AutoSize = True
        Me.lblPreferredName.Location = New System.Drawing.Point(6, 105)
        Me.lblPreferredName.Name = "lblPreferredName"
        Me.lblPreferredName.Size = New System.Drawing.Size(50, 13)
        Me.lblPreferredName.TabIndex = 204
        Me.lblPreferredName.Text = "Preferred"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(6, 7)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(38, 13)
        Me.lblName.TabIndex = 200
        Me.lblName.Text = "Name:"
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(62, 51)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(145, 20)
        Me.txtFirstName.TabIndex = 2
        '
        'txtMiddleName
        '
        Me.txtMiddleName.Location = New System.Drawing.Point(62, 77)
        Me.txtMiddleName.Name = "txtMiddleName"
        Me.txtMiddleName.Size = New System.Drawing.Size(100, 20)
        Me.txtMiddleName.TabIndex = 3
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(62, 25)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(145, 20)
        Me.txtLastName.TabIndex = 1
        '
        'lblMiddleName
        '
        Me.lblMiddleName.AutoSize = True
        Me.lblMiddleName.Location = New System.Drawing.Point(6, 79)
        Me.lblMiddleName.Name = "lblMiddleName"
        Me.lblMiddleName.Size = New System.Drawing.Size(38, 13)
        Me.lblMiddleName.TabIndex = 203
        Me.lblMiddleName.Text = "Middle"
        '
        'lblFirstName
        '
        Me.lblFirstName.AutoSize = True
        Me.lblFirstName.Location = New System.Drawing.Point(6, 53)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(26, 13)
        Me.lblFirstName.TabIndex = 202
        Me.lblFirstName.Text = "First"
        '
        'lblLastName
        '
        Me.lblLastName.AutoSize = True
        Me.lblLastName.Location = New System.Drawing.Point(7, 26)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(31, 13)
        Me.lblLastName.TabIndex = 201
        Me.lblLastName.Text = "Last*"
        '
        'TabAdmission
        '
        Me.TabAdmission.Controls.Add(Me.Label37)
        Me.TabAdmission.Controls.Add(Me.Label31)
        Me.TabAdmission.Controls.Add(Me.Label67)
        Me.TabAdmission.Controls.Add(Me.cbxStanding)
        Me.TabAdmission.Controls.Add(Me.lblSession)
        Me.TabAdmission.Controls.Add(Me.cbxSession)
        Me.TabAdmission.Controls.Add(Me.chkRequested)
        Me.TabAdmission.Controls.Add(Me.txtEnrolled_When)
        Me.TabAdmission.Controls.Add(Me.Label27)
        Me.TabAdmission.Controls.Add(Me.Label26)
        Me.TabAdmission.Controls.Add(Me.chkEnrolled)
        Me.TabAdmission.Controls.Add(Me.txtBefore_when)
        Me.TabAdmission.Controls.Add(Me.Label25)
        Me.TabAdmission.Controls.Add(Me.chkBefore)
        Me.TabAdmission.Controls.Add(Me.txtRequestYear)
        Me.TabAdmission.Controls.Add(Me.Label23)
        Me.TabAdmission.Controls.Add(Me.Label22)
        Me.TabAdmission.Location = New System.Drawing.Point(4, 22)
        Me.TabAdmission.Name = "TabAdmission"
        Me.TabAdmission.Padding = New System.Windows.Forms.Padding(3)
        Me.TabAdmission.Size = New System.Drawing.Size(801, 452)
        Me.TabAdmission.TabIndex = 1
        Me.TabAdmission.Text = "Admission Request"
        Me.TabAdmission.UseVisualStyleBackColor = True
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Location = New System.Drawing.Point(9, 86)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(775, 13)
        Me.Label67.TabIndex = 313
        Me.Label67.Text = "_________________________________________________________________________________" & _
            "_______________________________________________"
        '
        'cbxStanding
        '
        Me.cbxStanding.FormattingEnabled = True
        Me.cbxStanding.Items.AddRange(New Object() {"Graduate", "Undergraduate", "Other"})
        Me.cbxStanding.Location = New System.Drawing.Point(12, 170)
        Me.cbxStanding.Name = "cbxStanding"
        Me.cbxStanding.Size = New System.Drawing.Size(133, 21)
        Me.cbxStanding.TabIndex = 39
        '
        'lblSession
        '
        Me.lblSession.AutoSize = True
        Me.lblSession.Location = New System.Drawing.Point(6, 43)
        Me.lblSession.Name = "lblSession"
        Me.lblSession.Size = New System.Drawing.Size(47, 13)
        Me.lblSession.TabIndex = 238
        Me.lblSession.Text = "Session:"
        '
        'cbxSession
        '
        Me.cbxSession.FormattingEnabled = True
        Me.cbxSession.Items.AddRange(New Object() {"Spring", "Fall"})
        Me.cbxSession.Location = New System.Drawing.Point(9, 59)
        Me.cbxSession.Name = "cbxSession"
        Me.cbxSession.Size = New System.Drawing.Size(133, 21)
        Me.cbxSession.TabIndex = 34
        '
        'chkRequested
        '
        Me.chkRequested.AutoSize = True
        Me.chkRequested.Location = New System.Drawing.Point(12, 197)
        Me.chkRequested.Name = "chkRequested"
        Me.chkRequested.Size = New System.Drawing.Size(214, 17)
        Me.chkRequested.TabIndex = 244
        Me.chkRequested.Text = "Requested Scholarship / Assistantship?"
        Me.chkRequested.UseVisualStyleBackColor = True
        '
        'txtEnrolled_When
        '
        Me.txtEnrolled_When.Location = New System.Drawing.Point(133, 132)
        Me.txtEnrolled_When.Name = "txtEnrolled_When"
        Me.txtEnrolled_When.Size = New System.Drawing.Size(70, 20)
        Me.txtEnrolled_When.TabIndex = 38
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(88, 135)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(42, 13)
        Me.Label27.TabIndex = 242
        Me.Label27.Text = "When?"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(9, 154)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(56, 13)
        Me.Label26.TabIndex = 243
        Me.Label26.Text = "If enrolled:"
        '
        'chkEnrolled
        '
        Me.chkEnrolled.AutoSize = True
        Me.chkEnrolled.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkEnrolled.Location = New System.Drawing.Point(9, 134)
        Me.chkEnrolled.Name = "chkEnrolled"
        Me.chkEnrolled.Size = New System.Drawing.Size(70, 17)
        Me.chkEnrolled.TabIndex = 241
        Me.chkEnrolled.Text = "Enrolled?"
        Me.chkEnrolled.UseVisualStyleBackColor = True
        '
        'txtBefore_when
        '
        Me.txtBefore_when.Location = New System.Drawing.Point(225, 110)
        Me.txtBefore_when.Name = "txtBefore_when"
        Me.txtBefore_when.Size = New System.Drawing.Size(70, 20)
        Me.txtBefore_when.TabIndex = 36
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(180, 113)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(42, 13)
        Me.Label25.TabIndex = 240
        Me.Label25.Text = "When?"
        '
        'chkBefore
        '
        Me.chkBefore.AutoSize = True
        Me.chkBefore.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkBefore.Location = New System.Drawing.Point(9, 111)
        Me.chkBefore.Name = "chkBefore"
        Me.chkBefore.Size = New System.Drawing.Size(163, 17)
        Me.chkBefore.TabIndex = 239
        Me.chkBefore.Text = "Applied to the U of A before?"
        Me.chkBefore.UseVisualStyleBackColor = True
        '
        'txtRequestYear
        '
        Me.txtRequestYear.Location = New System.Drawing.Point(45, 21)
        Me.txtRequestYear.Name = "txtRequestYear"
        Me.txtRequestYear.Size = New System.Drawing.Size(48, 20)
        Me.txtRequestYear.TabIndex = 33
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(6, 23)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(32, 13)
        Me.Label23.TabIndex = 237
        Me.Label23.Text = "Year:"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(4, 4)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(126, 13)
        Me.Label22.TabIndex = 236
        Me.Label22.Text = "Adminission Request For:"
        '
        'tabCredentials
        '
        Me.tabCredentials.Controls.Add(Me.Label45)
        Me.tabCredentials.Controls.Add(Me.Label39)
        Me.tabCredentials.Controls.Add(Me.Label38)
        Me.tabCredentials.Controls.Add(Me.txtCFrom1)
        Me.tabCredentials.Controls.Add(Me.txtCFrom2)
        Me.tabCredentials.Controls.Add(Me.txtCTo1)
        Me.tabCredentials.Controls.Add(Me.txtCTo2)
        Me.tabCredentials.Controls.Add(Me.Label95)
        Me.tabCredentials.Controls.Add(Me.Label94)
        Me.tabCredentials.Controls.Add(Me.txtDegreeDate2)
        Me.tabCredentials.Controls.Add(Me.txtDegreeDate1)
        Me.tabCredentials.Controls.Add(Me.Label93)
        Me.tabCredentials.Controls.Add(Me.txtMajor2)
        Me.tabCredentials.Controls.Add(Me.txtMajor1)
        Me.tabCredentials.Controls.Add(Me.Label61)
        Me.tabCredentials.Controls.Add(Me.Label62)
        Me.tabCredentials.Controls.Add(Me.txtCurrentHours2)
        Me.tabCredentials.Controls.Add(Me.txtCurrentHours1)
        Me.tabCredentials.Controls.Add(Me.Label60)
        Me.tabCredentials.Controls.Add(Me.txtDegree2)
        Me.tabCredentials.Controls.Add(Me.txtDegree1)
        Me.tabCredentials.Controls.Add(Me.Label59)
        Me.tabCredentials.Controls.Add(Me.Label58)
        Me.tabCredentials.Controls.Add(Me.txtHoursEarned2)
        Me.tabCredentials.Controls.Add(Me.txtHoursEarned1)
        Me.tabCredentials.Controls.Add(Me.Label57)
        Me.tabCredentials.Controls.Add(Me.txtCGPA2)
        Me.tabCredentials.Controls.Add(Me.txtCGPA1)
        Me.tabCredentials.Controls.Add(Me.Label56)
        Me.tabCredentials.Controls.Add(Me.Label55)
        Me.tabCredentials.Controls.Add(Me.Label54)
        Me.tabCredentials.Controls.Add(Me.Label53)
        Me.tabCredentials.Controls.Add(Me.txtCName2)
        Me.tabCredentials.Controls.Add(Me.txtCName1)
        Me.tabCredentials.Controls.Add(Me.Label24)
        Me.tabCredentials.Controls.Add(Me.txtTSEDate)
        Me.tabCredentials.Controls.Add(Me.txtTOEFLDate)
        Me.tabCredentials.Controls.Add(Me.Label70)
        Me.tabCredentials.Controls.Add(Me.Label69)
        Me.tabCredentials.Controls.Add(Me.Label68)
        Me.tabCredentials.Controls.Add(Me.chkTSE)
        Me.tabCredentials.Controls.Add(Me.chkTOEFL)
        Me.tabCredentials.Controls.Add(Me.txtGMATTotal)
        Me.tabCredentials.Controls.Add(Me.chkFinancial)
        Me.tabCredentials.Controls.Add(Me.chkEducation)
        Me.tabCredentials.Controls.Add(Me.chkGREScore)
        Me.tabCredentials.Controls.Add(Me.chkGMATScore)
        Me.tabCredentials.Controls.Add(Me.chkEssay)
        Me.tabCredentials.Controls.Add(Me.chkTranscript)
        Me.tabCredentials.Controls.Add(Me.chkLOR)
        Me.tabCredentials.Controls.Add(Me.chkResume)
        Me.tabCredentials.Controls.Add(Me.chkAppForm)
        Me.tabCredentials.Controls.Add(Me.chkAppFeePaid)
        Me.tabCredentials.Controls.Add(Me.Label64)
        Me.tabCredentials.Controls.Add(Me.Label63)
        Me.tabCredentials.Controls.Add(Me.Label43)
        Me.tabCredentials.Controls.Add(Me.txtGPASenior)
        Me.tabCredentials.Controls.Add(Me.Label44)
        Me.tabCredentials.Controls.Add(Me.txtUnderGPA)
        Me.tabCredentials.Controls.Add(Me.Label42)
        Me.tabCredentials.Controls.Add(Me.Label41)
        Me.tabCredentials.Controls.Add(Me.txtTSETotal)
        Me.tabCredentials.Controls.Add(Me.Label40)
        Me.tabCredentials.Controls.Add(Me.txtTOEFLTotal)
        Me.tabCredentials.Controls.Add(Me.Label36)
        Me.tabCredentials.Controls.Add(Me.Label35)
        Me.tabCredentials.Controls.Add(Me.txtGMATQuant)
        Me.tabCredentials.Controls.Add(Me.Label34)
        Me.tabCredentials.Controls.Add(Me.txtGMATVerbal)
        Me.tabCredentials.Controls.Add(Me.Label33)
        Me.tabCredentials.Controls.Add(Me.Label30)
        Me.tabCredentials.Controls.Add(Me.Label29)
        Me.tabCredentials.Controls.Add(Me.Label32)
        Me.tabCredentials.Controls.Add(Me.txtGMATDate)
        Me.tabCredentials.Controls.Add(Me.Label28)
        Me.tabCredentials.Location = New System.Drawing.Point(4, 22)
        Me.tabCredentials.Name = "tabCredentials"
        Me.tabCredentials.Padding = New System.Windows.Forms.Padding(3)
        Me.tabCredentials.Size = New System.Drawing.Size(801, 452)
        Me.tabCredentials.TabIndex = 2
        Me.tabCredentials.Text = "Credentials & Documents"
        Me.tabCredentials.UseVisualStyleBackColor = True
        '
        'txtCFrom1
        '
        Me.txtCFrom1.Location = New System.Drawing.Point(282, 280)
        Me.txtCFrom1.Name = "txtCFrom1"
        Me.txtCFrom1.Size = New System.Drawing.Size(70, 20)
        Me.txtCFrom1.TabIndex = 362
        '
        'txtCFrom2
        '
        Me.txtCFrom2.Location = New System.Drawing.Point(282, 306)
        Me.txtCFrom2.Name = "txtCFrom2"
        Me.txtCFrom2.Size = New System.Drawing.Size(70, 20)
        Me.txtCFrom2.TabIndex = 371
        '
        'txtCTo1
        '
        Me.txtCTo1.Location = New System.Drawing.Point(202, 280)
        Me.txtCTo1.Name = "txtCTo1"
        Me.txtCTo1.Size = New System.Drawing.Size(70, 20)
        Me.txtCTo1.TabIndex = 361
        '
        'txtCTo2
        '
        Me.txtCTo2.Location = New System.Drawing.Point(202, 306)
        Me.txtCTo2.Name = "txtCTo2"
        Me.txtCTo2.Size = New System.Drawing.Size(70, 20)
        Me.txtCTo2.TabIndex = 370
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Location = New System.Drawing.Point(617, 263)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(33, 13)
        Me.Label95.TabIndex = 388
        Me.Label95.Text = "Date:"
        '
        'Label94
        '
        Me.Label94.AutoSize = True
        Me.Label94.Location = New System.Drawing.Point(617, 249)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(42, 13)
        Me.Label94.TabIndex = 387
        Me.Label94.Text = "Degree"
        '
        'txtDegreeDate2
        '
        Me.txtDegreeDate2.Location = New System.Drawing.Point(620, 305)
        Me.txtDegreeDate2.Name = "txtDegreeDate2"
        Me.txtDegreeDate2.Size = New System.Drawing.Size(70, 20)
        Me.txtDegreeDate2.TabIndex = 376
        '
        'txtDegreeDate1
        '
        Me.txtDegreeDate1.Location = New System.Drawing.Point(620, 280)
        Me.txtDegreeDate1.Name = "txtDegreeDate1"
        Me.txtDegreeDate1.Size = New System.Drawing.Size(70, 20)
        Me.txtDegreeDate1.TabIndex = 367
        '
        'Label93
        '
        Me.Label93.AutoSize = True
        Me.Label93.Location = New System.Drawing.Point(556, 263)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(36, 13)
        Me.Label93.TabIndex = 386
        Me.Label93.Text = "Major:"
        '
        'txtMajor2
        '
        Me.txtMajor2.Location = New System.Drawing.Point(559, 305)
        Me.txtMajor2.Name = "txtMajor2"
        Me.txtMajor2.Size = New System.Drawing.Size(55, 20)
        Me.txtMajor2.TabIndex = 375
        '
        'txtMajor1
        '
        Me.txtMajor1.Location = New System.Drawing.Point(559, 280)
        Me.txtMajor1.Name = "txtMajor1"
        Me.txtMajor1.Size = New System.Drawing.Size(55, 20)
        Me.txtMajor1.TabIndex = 366
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Location = New System.Drawing.Point(694, 264)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(96, 13)
        Me.Label61.TabIndex = 390
        Me.Label61.Text = "Current Enrollment:"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(694, 251)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(47, 13)
        Me.Label62.TabIndex = 389
        Me.Label62.Text = "Hours of"
        '
        'txtCurrentHours2
        '
        Me.txtCurrentHours2.Location = New System.Drawing.Point(697, 306)
        Me.txtCurrentHours2.Name = "txtCurrentHours2"
        Me.txtCurrentHours2.Size = New System.Drawing.Size(50, 20)
        Me.txtCurrentHours2.TabIndex = 377
        '
        'txtCurrentHours1
        '
        Me.txtCurrentHours1.Location = New System.Drawing.Point(697, 280)
        Me.txtCurrentHours1.Name = "txtCurrentHours1"
        Me.txtCurrentHours1.Size = New System.Drawing.Size(50, 20)
        Me.txtCurrentHours1.TabIndex = 368
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(495, 264)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(45, 13)
        Me.Label60.TabIndex = 385
        Me.Label60.Text = "Degree:"
        '
        'txtDegree2
        '
        Me.txtDegree2.Location = New System.Drawing.Point(498, 305)
        Me.txtDegree2.Name = "txtDegree2"
        Me.txtDegree2.Size = New System.Drawing.Size(55, 20)
        Me.txtDegree2.TabIndex = 374
        '
        'txtDegree1
        '
        Me.txtDegree1.Location = New System.Drawing.Point(498, 280)
        Me.txtDegree1.Name = "txtDegree1"
        Me.txtDegree1.Size = New System.Drawing.Size(55, 20)
        Me.txtDegree1.TabIndex = 365
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(411, 264)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(75, 13)
        Me.Label59.TabIndex = 384
        Me.Label59.Text = "Hours Earned:"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(419, 251)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(51, 13)
        Me.Label58.TabIndex = 383
        Me.Label58.Text = "Semester"
        '
        'txtHoursEarned2
        '
        Me.txtHoursEarned2.Location = New System.Drawing.Point(428, 305)
        Me.txtHoursEarned2.Name = "txtHoursEarned2"
        Me.txtHoursEarned2.Size = New System.Drawing.Size(50, 20)
        Me.txtHoursEarned2.TabIndex = 373
        '
        'txtHoursEarned1
        '
        Me.txtHoursEarned1.Location = New System.Drawing.Point(428, 279)
        Me.txtHoursEarned1.Name = "txtHoursEarned1"
        Me.txtHoursEarned1.Size = New System.Drawing.Size(50, 20)
        Me.txtHoursEarned1.TabIndex = 364
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(355, 264)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(32, 13)
        Me.Label57.TabIndex = 382
        Me.Label57.Text = "GPA:"
        '
        'txtCGPA2
        '
        Me.txtCGPA2.Location = New System.Drawing.Point(358, 305)
        Me.txtCGPA2.Name = "txtCGPA2"
        Me.txtCGPA2.Size = New System.Drawing.Size(50, 20)
        Me.txtCGPA2.TabIndex = 372
        '
        'txtCGPA1
        '
        Me.txtCGPA1.Location = New System.Drawing.Point(358, 280)
        Me.txtCGPA1.Name = "txtCGPA1"
        Me.txtCGPA1.Size = New System.Drawing.Size(50, 20)
        Me.txtCGPA1.TabIndex = 363
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(199, 251)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(84, 13)
        Me.Label56.TabIndex = 379
        Me.Label56.Text = "Dates Attended:"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(279, 264)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(33, 13)
        Me.Label55.TabIndex = 381
        Me.Label55.Text = "From:"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(199, 264)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(23, 13)
        Me.Label54.TabIndex = 380
        Me.Label54.Text = "To:"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(9, 264)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(76, 13)
        Me.Label53.TabIndex = 378
        Me.Label53.Text = "College Name:"
        '
        'txtCName2
        '
        Me.txtCName2.Location = New System.Drawing.Point(12, 306)
        Me.txtCName2.Name = "txtCName2"
        Me.txtCName2.Size = New System.Drawing.Size(182, 20)
        Me.txtCName2.TabIndex = 369
        '
        'txtCName1
        '
        Me.txtCName1.Location = New System.Drawing.Point(12, 280)
        Me.txtCName1.Name = "txtCName1"
        Me.txtCName1.Size = New System.Drawing.Size(182, 20)
        Me.txtCName1.TabIndex = 360
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(6, 26)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(120, 13)
        Me.Label24.TabIndex = 246
        Me.Label24.Text = "(Taken or to be Taken):"
        '
        'txtTSEDate
        '
        Me.txtTSEDate.Location = New System.Drawing.Point(6, 114)
        Me.txtTSEDate.Name = "txtTSEDate"
        Me.txtTSEDate.Size = New System.Drawing.Size(70, 20)
        Me.txtTSEDate.TabIndex = 51
        '
        'txtTOEFLDate
        '
        Me.txtTOEFLDate.Location = New System.Drawing.Point(6, 81)
        Me.txtTOEFLDate.Name = "txtTOEFLDate"
        Me.txtTOEFLDate.Size = New System.Drawing.Size(70, 20)
        Me.txtTOEFLDate.TabIndex = 49
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Location = New System.Drawing.Point(-9, 232)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(793, 13)
        Me.Label70.TabIndex = 312
        Me.Label70.Text = "_________________________________________________________________________________" & _
            "__________________________________________________"
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Location = New System.Drawing.Point(411, 32)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(379, 13)
        Me.Label69.TabIndex = 311
        Me.Label69.Text = "______________________________________________________________"
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.Location = New System.Drawing.Point(410, 21)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(123, 13)
        Me.Label68.TabIndex = 264
        Me.Label68.Text = "considered COMPLETE:"
        '
        'chkTSE
        '
        Me.chkTSE.AutoSize = True
        Me.chkTSE.Location = New System.Drawing.Point(413, 216)
        Me.chkTSE.Name = "chkTSE"
        Me.chkTSE.Size = New System.Drawing.Size(210, 17)
        Me.chkTSE.TabIndex = 275
        Me.chkTSE.Text = "TSE (International MIS Applicants only)"
        Me.chkTSE.UseVisualStyleBackColor = True
        '
        'chkTOEFL
        '
        Me.chkTOEFL.AutoSize = True
        Me.chkTOEFL.Location = New System.Drawing.Point(413, 201)
        Me.chkTOEFL.Name = "chkTOEFL"
        Me.chkTOEFL.Size = New System.Drawing.Size(194, 17)
        Me.chkTOEFL.TabIndex = 274
        Me.chkTOEFL.Text = "TOEFL (International Students only)"
        Me.chkTOEFL.UseVisualStyleBackColor = True
        '
        'txtGMATTotal
        '
        Me.txtGMATTotal.Location = New System.Drawing.Point(307, 43)
        Me.txtGMATTotal.Name = "txtGMATTotal"
        Me.txtGMATTotal.Size = New System.Drawing.Size(31, 20)
        Me.txtGMATTotal.TabIndex = 44
        '
        'chkFinancial
        '
        Me.chkFinancial.AutoSize = True
        Me.chkFinancial.Location = New System.Drawing.Point(413, 185)
        Me.chkFinancial.Name = "chkFinancial"
        Me.chkFinancial.Size = New System.Drawing.Size(371, 17)
        Me.chkFinancial.TabIndex = 273
        Me.chkFinancial.Text = "Supplemental and Financial Information Form (International Students only)"
        Me.chkFinancial.UseVisualStyleBackColor = True
        '
        'chkEducation
        '
        Me.chkEducation.AutoSize = True
        Me.chkEducation.Location = New System.Drawing.Point(413, 169)
        Me.chkEducation.Name = "chkEducation"
        Me.chkEducation.Size = New System.Drawing.Size(328, 17)
        Me.chkEducation.TabIndex = 272
        Me.chkEducation.Text = "Summary of educational experience (International Students only)"
        Me.chkEducation.UseVisualStyleBackColor = True
        '
        'chkGREScore
        '
        Me.chkGREScore.AutoSize = True
        Me.chkGREScore.Location = New System.Drawing.Point(518, 81)
        Me.chkGREScore.Name = "chkGREScore"
        Me.chkGREScore.Size = New System.Drawing.Size(80, 17)
        Me.chkGREScore.TabIndex = 277
        Me.chkGREScore.Text = "GRE Score"
        Me.chkGREScore.UseVisualStyleBackColor = True
        '
        'chkGMATScore
        '
        Me.chkGMATScore.AutoSize = True
        Me.chkGMATScore.Location = New System.Drawing.Point(518, 63)
        Me.chkGMATScore.Name = "chkGMATScore"
        Me.chkGMATScore.Size = New System.Drawing.Size(88, 17)
        Me.chkGMATScore.TabIndex = 276
        Me.chkGMATScore.Text = "GMAT Score"
        Me.chkGMATScore.UseVisualStyleBackColor = True
        '
        'chkEssay
        '
        Me.chkEssay.AutoSize = True
        Me.chkEssay.Location = New System.Drawing.Point(413, 98)
        Me.chkEssay.Name = "chkEssay"
        Me.chkEssay.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkEssay.Size = New System.Drawing.Size(104, 17)
        Me.chkEssay.TabIndex = 268
        Me.chkEssay.Text = "Essay Questions"
        Me.chkEssay.UseVisualStyleBackColor = True
        '
        'chkTranscript
        '
        Me.chkTranscript.AutoSize = True
        Me.chkTranscript.Location = New System.Drawing.Point(413, 151)
        Me.chkTranscript.Name = "chkTranscript"
        Me.chkTranscript.Size = New System.Drawing.Size(257, 17)
        Me.chkTranscript.TabIndex = 271
        Me.chkTranscript.Text = "Official Transcripts from each University attended"
        Me.chkTranscript.UseVisualStyleBackColor = True
        '
        'chkLOR
        '
        Me.chkLOR.AutoSize = True
        Me.chkLOR.Location = New System.Drawing.Point(413, 134)
        Me.chkLOR.Name = "chkLOR"
        Me.chkLOR.Size = New System.Drawing.Size(187, 17)
        Me.chkLOR.TabIndex = 270
        Me.chkLOR.Text = "Three Letters of Recommendation"
        Me.chkLOR.UseVisualStyleBackColor = True
        '
        'chkResume
        '
        Me.chkResume.AutoSize = True
        Me.chkResume.Location = New System.Drawing.Point(413, 80)
        Me.chkResume.Name = "chkResume"
        Me.chkResume.Size = New System.Drawing.Size(65, 17)
        Me.chkResume.TabIndex = 267
        Me.chkResume.Text = "Resume"
        Me.chkResume.UseVisualStyleBackColor = True
        '
        'chkAppForm
        '
        Me.chkAppForm.AutoSize = True
        Me.chkAppForm.Location = New System.Drawing.Point(413, 116)
        Me.chkAppForm.Name = "chkAppForm"
        Me.chkAppForm.Size = New System.Drawing.Size(176, 17)
        Me.chkAppForm.TabIndex = 269
        Me.chkAppForm.Text = "Walton College Applicaion Form"
        Me.chkAppForm.UseVisualStyleBackColor = True
        '
        'chkAppFeePaid
        '
        Me.chkAppFeePaid.AutoSize = True
        Me.chkAppFeePaid.Location = New System.Drawing.Point(413, 63)
        Me.chkAppFeePaid.Name = "chkAppFeePaid"
        Me.chkAppFeePaid.Size = New System.Drawing.Size(99, 17)
        Me.chkAppFeePaid.TabIndex = 266
        Me.chkAppFeePaid.Text = "Application Fee"
        Me.chkAppFeePaid.UseVisualStyleBackColor = True
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(410, 8)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(336, 13)
        Me.Label64.TabIndex = 263
        Me.Label64.Text = "The following materials MUST be be submitted BEFORE application is"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label63.Location = New System.Drawing.Point(410, 46)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(60, 13)
        Me.Label63.TabIndex = 265
        Me.Label63.Text = "Check List:"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(57, 200)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(102, 13)
        Me.Label43.TabIndex = 262
        Me.Label43.Text = "GPA in Jr./Sr. Years"
        '
        'txtGPASenior
        '
        Me.txtGPASenior.Location = New System.Drawing.Point(6, 197)
        Me.txtGPASenior.Name = "txtGPASenior"
        Me.txtGPASenior.Size = New System.Drawing.Size(50, 20)
        Me.txtGPASenior.TabIndex = 54
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(57, 174)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(82, 13)
        Me.Label44.TabIndex = 261
        Me.Label44.Text = "Undergrad GPA"
        '
        'txtUnderGPA
        '
        Me.txtUnderGPA.Location = New System.Drawing.Point(6, 171)
        Me.txtUnderGPA.Name = "txtUnderGPA"
        Me.txtUnderGPA.Size = New System.Drawing.Size(50, 20)
        Me.txtUnderGPA.TabIndex = 53
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(3, 155)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(58, 13)
        Me.Label42.TabIndex = 260
        Me.Label42.Text = "Education:"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(197, 117)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(55, 13)
        Me.Label41.TabIndex = 259
        Me.Label41.Text = "TSE Total"
        '
        'txtTSETotal
        '
        Me.txtTSETotal.Location = New System.Drawing.Point(160, 114)
        Me.txtTSETotal.Name = "txtTSETotal"
        Me.txtTSETotal.Size = New System.Drawing.Size(34, 20)
        Me.txtTSETotal.TabIndex = 52
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(197, 85)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(68, 13)
        Me.Label40.TabIndex = 257
        Me.Label40.Text = "TOEFL Total"
        '
        'txtTOEFLTotal
        '
        Me.txtTOEFLTotal.Location = New System.Drawing.Point(160, 81)
        Me.txtTOEFLTotal.Name = "txtTOEFLTotal"
        Me.txtTOEFLTotal.Size = New System.Drawing.Size(34, 20)
        Me.txtTOEFLTotal.TabIndex = 50
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(338, 46)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(31, 13)
        Me.Label36.TabIndex = 251
        Me.Label36.Text = "Total"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(267, 46)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(39, 13)
        Me.Label35.TabIndex = 250
        Me.Label35.Text = "Quant."
        '
        'txtGMATQuant
        '
        Me.txtGMATQuant.Location = New System.Drawing.Point(236, 43)
        Me.txtGMATQuant.Name = "txtGMATQuant"
        Me.txtGMATQuant.Size = New System.Drawing.Size(31, 20)
        Me.txtGMATQuant.TabIndex = 43
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(197, 46)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(37, 13)
        Me.Label34.TabIndex = 249
        Me.Label34.Text = "Verbal"
        '
        'txtGMATVerbal
        '
        Me.txtGMATVerbal.Location = New System.Drawing.Point(160, 43)
        Me.txtGMATVerbal.Name = "txtGMATVerbal"
        Me.txtGMATVerbal.Size = New System.Drawing.Size(34, 20)
        Me.txtGMATVerbal.TabIndex = 42
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(156, 21)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(43, 13)
        Me.Label33.TabIndex = 247
        Me.Label33.Text = "Scores:"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(82, 117)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(28, 13)
        Me.Label30.TabIndex = 258
        Me.Label30.Text = "TSE"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(82, 84)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(41, 13)
        Me.Label29.TabIndex = 256
        Me.Label29.Text = "TOEFL"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(9, 13)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(59, 13)
        Me.Label32.TabIndex = 245
        Me.Label32.Text = "Test Dates"
        '
        'txtGMATDate
        '
        Me.txtGMATDate.Location = New System.Drawing.Point(6, 46)
        Me.txtGMATDate.Name = "txtGMATDate"
        Me.txtGMATDate.Size = New System.Drawing.Size(70, 20)
        Me.txtGMATDate.TabIndex = 41
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(82, 50)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(38, 13)
        Me.Label28.TabIndex = 248
        Me.Label28.Text = "GMAT"
        '
        'tabStudentStatus
        '
        Me.tabStudentStatus.Controls.Add(Me.Label79)
        Me.tabStudentStatus.Controls.Add(Me.Label78)
        Me.tabStudentStatus.Controls.Add(Me.Label76)
        Me.tabStudentStatus.Controls.Add(Me.Label73)
        Me.tabStudentStatus.Controls.Add(Me.Label51)
        Me.tabStudentStatus.Controls.Add(Me.txtNotes)
        Me.tabStudentStatus.Controls.Add(Me.TextBox1)
        Me.tabStudentStatus.Controls.Add(Me.txtDateAccepted)
        Me.tabStudentStatus.Controls.Add(Me.txtAcceptedOffer)
        Me.tabStudentStatus.Controls.Add(Me.txtDDate)
        Me.tabStudentStatus.Controls.Add(Me.txtDeclined)
        Me.tabStudentStatus.Controls.Add(Me.txtDEnrolled)
        Me.tabStudentStatus.Controls.Add(Me.txtSEnrolled)
        Me.tabStudentStatus.Controls.Add(Me.txtDateApplied)
        Me.tabStudentStatus.Controls.Add(Me.txtAStatus)
        Me.tabStudentStatus.Controls.Add(Me.txtFeePaid)
        Me.tabStudentStatus.Controls.Add(Me.txtStatus)
        Me.tabStudentStatus.Controls.Add(Me.Label102)
        Me.tabStudentStatus.Controls.Add(Me.Label101)
        Me.tabStudentStatus.Controls.Add(Me.Label100)
        Me.tabStudentStatus.Controls.Add(Me.lblStudentID)
        Me.tabStudentStatus.Controls.Add(Me.Label98)
        Me.tabStudentStatus.Controls.Add(Me.lblStudentName)
        Me.tabStudentStatus.Controls.Add(Me.Label96)
        Me.tabStudentStatus.Controls.Add(Me.Label92)
        Me.tabStudentStatus.Controls.Add(Me.Label89)
        Me.tabStudentStatus.Controls.Add(Me.Label88)
        Me.tabStudentStatus.Controls.Add(Me.Label86)
        Me.tabStudentStatus.Controls.Add(Me.Label84)
        Me.tabStudentStatus.Controls.Add(Me.Label82)
        Me.tabStudentStatus.Controls.Add(Me.Label80)
        Me.tabStudentStatus.Controls.Add(Me.Label77)
        Me.tabStudentStatus.Controls.Add(Me.Label75)
        Me.tabStudentStatus.Controls.Add(Me.Label74)
        Me.tabStudentStatus.Location = New System.Drawing.Point(4, 22)
        Me.tabStudentStatus.Name = "tabStudentStatus"
        Me.tabStudentStatus.Padding = New System.Windows.Forms.Padding(3)
        Me.tabStudentStatus.Size = New System.Drawing.Size(801, 452)
        Me.tabStudentStatus.TabIndex = 3
        Me.tabStudentStatus.Text = "Student Status"
        Me.tabStudentStatus.UseVisualStyleBackColor = True
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.Location = New System.Drawing.Point(308, 68)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(38, 13)
        Me.Label51.TabIndex = 310
        Me.Label51.Text = "Notes:"
        '
        'txtNotes
        '
        Me.txtNotes.Location = New System.Drawing.Point(311, 84)
        Me.txtNotes.Multiline = True
        Me.txtNotes.Name = "txtNotes"
        Me.txtNotes.Size = New System.Drawing.Size(465, 289)
        Me.txtNotes.TabIndex = 131
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(321, 74)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(30, 0)
        Me.TextBox1.TabIndex = 37
        '
        'txtDateAccepted
        '
        Me.txtDateAccepted.Location = New System.Drawing.Point(94, 353)
        Me.txtDateAccepted.Name = "txtDateAccepted"
        Me.txtDateAccepted.Size = New System.Drawing.Size(70, 20)
        Me.txtDateAccepted.TabIndex = 130
        '
        'txtAcceptedOffer
        '
        Me.txtAcceptedOffer.Location = New System.Drawing.Point(6, 353)
        Me.txtAcceptedOffer.Name = "txtAcceptedOffer"
        Me.txtAcceptedOffer.Size = New System.Drawing.Size(51, 20)
        Me.txtAcceptedOffer.TabIndex = 129
        '
        'txtDDate
        '
        Me.txtDDate.Location = New System.Drawing.Point(94, 309)
        Me.txtDDate.Name = "txtDDate"
        Me.txtDDate.Size = New System.Drawing.Size(70, 20)
        Me.txtDDate.TabIndex = 128
        '
        'txtDeclined
        '
        Me.txtDeclined.Location = New System.Drawing.Point(6, 309)
        Me.txtDeclined.Name = "txtDeclined"
        Me.txtDeclined.Size = New System.Drawing.Size(51, 20)
        Me.txtDeclined.TabIndex = 127
        '
        'txtDEnrolled
        '
        Me.txtDEnrolled.Location = New System.Drawing.Point(94, 267)
        Me.txtDEnrolled.Name = "txtDEnrolled"
        Me.txtDEnrolled.Size = New System.Drawing.Size(70, 20)
        Me.txtDEnrolled.TabIndex = 126
        '
        'txtSEnrolled
        '
        Me.txtSEnrolled.Location = New System.Drawing.Point(6, 267)
        Me.txtSEnrolled.Name = "txtSEnrolled"
        Me.txtSEnrolled.Size = New System.Drawing.Size(51, 20)
        Me.txtSEnrolled.TabIndex = 125
        '
        'txtDateApplied
        '
        Me.txtDateApplied.Location = New System.Drawing.Point(10, 137)
        Me.txtDateApplied.Name = "txtDateApplied"
        Me.txtDateApplied.Size = New System.Drawing.Size(100, 20)
        Me.txtDateApplied.TabIndex = 122
        '
        'txtAStatus
        '
        Me.txtAStatus.Location = New System.Drawing.Point(7, 179)
        Me.txtAStatus.Name = "txtAStatus"
        Me.txtAStatus.Size = New System.Drawing.Size(100, 20)
        Me.txtAStatus.TabIndex = 123
        '
        'txtFeePaid
        '
        Me.txtFeePaid.Location = New System.Drawing.Point(7, 217)
        Me.txtFeePaid.Name = "txtFeePaid"
        Me.txtFeePaid.Size = New System.Drawing.Size(100, 20)
        Me.txtFeePaid.TabIndex = 124
        '
        'txtStatus
        '
        Me.txtStatus.Location = New System.Drawing.Point(9, 100)
        Me.txtStatus.Name = "txtStatus"
        Me.txtStatus.Size = New System.Drawing.Size(100, 20)
        Me.txtStatus.TabIndex = 121
        '
        'Label102
        '
        Me.Label102.AutoSize = True
        Me.Label102.Location = New System.Drawing.Point(3, 238)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(289, 13)
        Me.Label102.TabIndex = 302
        Me.Label102.Text = "_______________________________________________"
        '
        'Label101
        '
        Me.Label101.AutoSize = True
        Me.Label101.Location = New System.Drawing.Point(6, 151)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(289, 13)
        Me.Label101.TabIndex = 299
        Me.Label101.Text = "_______________________________________________"
        '
        'Label100
        '
        Me.Label100.AutoSize = True
        Me.Label100.Location = New System.Drawing.Point(6, 71)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(289, 13)
        Me.Label100.TabIndex = 296
        Me.Label100.Text = "_______________________________________________"
        '
        'lblStudentID
        '
        Me.lblStudentID.AutoSize = True
        Me.lblStudentID.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStudentID.Location = New System.Drawing.Point(6, 60)
        Me.lblStudentID.Name = "lblStudentID"
        Me.lblStudentID.Size = New System.Drawing.Size(58, 13)
        Me.lblStudentID.TabIndex = 295
        Me.lblStudentID.Text = "Student ID"
        '
        'Label98
        '
        Me.Label98.AutoSize = True
        Me.Label98.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label98.Location = New System.Drawing.Point(6, 44)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(61, 13)
        Me.Label98.TabIndex = 294
        Me.Label98.Text = "Student ID:"
        '
        'lblStudentName
        '
        Me.lblStudentName.AutoSize = True
        Me.lblStudentName.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStudentName.Location = New System.Drawing.Point(5, 27)
        Me.lblStudentName.Name = "lblStudentName"
        Me.lblStudentName.Size = New System.Drawing.Size(75, 13)
        Me.lblStudentName.TabIndex = 293
        Me.lblStudentName.Text = "Student Name"
        '
        'Label96
        '
        Me.Label96.AutoSize = True
        Me.Label96.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label96.Location = New System.Drawing.Point(6, 11)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(78, 13)
        Me.Label96.TabIndex = 292
        Me.Label96.Text = "Student Name:"
        '
        'Label92
        '
        Me.Label92.AutoSize = True
        Me.Label92.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label92.Location = New System.Drawing.Point(7, 121)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(70, 13)
        Me.Label92.TabIndex = 298
        Me.Label92.Text = "Date applied:"
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label89.Location = New System.Drawing.Point(6, 84)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(80, 13)
        Me.Label89.TabIndex = 297
        Me.Label89.Text = "Student Status:"
        '
        'Label88
        '
        Me.Label88.AutoSize = True
        Me.Label88.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label88.Location = New System.Drawing.Point(91, 337)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(81, 13)
        Me.Label88.TabIndex = 309
        Me.Label88.Text = "Date accepted:"
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label86.Location = New System.Drawing.Point(6, 251)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(51, 13)
        Me.Label86.TabIndex = 304
        Me.Label86.Text = "Enrolled?"
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label84.Location = New System.Drawing.Point(6, 293)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(79, 13)
        Me.Label84.TabIndex = 306
        Me.Label84.Text = "Declined offer?"
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label82.Location = New System.Drawing.Point(6, 337)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(83, 13)
        Me.Label82.TabIndex = 308
        Me.Label82.Text = "Accepted offer?"
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label80.Location = New System.Drawing.Point(91, 293)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(76, 13)
        Me.Label80.TabIndex = 307
        Me.Label80.Text = "Date declined:"
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label77.Location = New System.Drawing.Point(91, 251)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(73, 13)
        Me.Label77.TabIndex = 305
        Me.Label77.Text = "Date enrolled:"
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label75.Location = New System.Drawing.Point(6, 201)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(105, 13)
        Me.Label75.TabIndex = 301
        Me.Label75.Text = "Admission Fee Paid?"
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label74.Location = New System.Drawing.Point(6, 163)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(104, 13)
        Me.Label74.TabIndex = 300
        Me.Label74.Text = "Assistantship Status:"
        '
        'btnAddRecord
        '
        Me.btnAddRecord.Location = New System.Drawing.Point(22, 36)
        Me.btnAddRecord.Name = "btnAddRecord"
        Me.btnAddRecord.Size = New System.Drawing.Size(112, 26)
        Me.btnAddRecord.TabIndex = 500
        Me.btnAddRecord.Text = "Add New Record"
        Me.btnAddRecord.UseVisualStyleBackColor = True
        '
        'btnEditRecord
        '
        Me.btnEditRecord.Location = New System.Drawing.Point(361, 36)
        Me.btnEditRecord.Name = "btnEditRecord"
        Me.btnEditRecord.Size = New System.Drawing.Size(100, 26)
        Me.btnEditRecord.TabIndex = 503
        Me.btnEditRecord.Text = "Edit Record"
        Me.btnEditRecord.UseVisualStyleBackColor = True
        '
        'btnDeleteRecord
        '
        Me.btnDeleteRecord.Location = New System.Drawing.Point(575, 36)
        Me.btnDeleteRecord.Name = "btnDeleteRecord"
        Me.btnDeleteRecord.Size = New System.Drawing.Size(102, 26)
        Me.btnDeleteRecord.TabIndex = 506
        Me.btnDeleteRecord.Text = "Delete Record"
        Me.btnDeleteRecord.UseVisualStyleBackColor = True
        '
        'btnSearchRecord
        '
        Me.btnSearchRecord.Location = New System.Drawing.Point(140, 36)
        Me.btnSearchRecord.Name = "btnSearchRecord"
        Me.btnSearchRecord.Size = New System.Drawing.Size(100, 26)
        Me.btnSearchRecord.TabIndex = 501
        Me.btnSearchRecord.Text = "Search Record"
        Me.btnSearchRecord.UseVisualStyleBackColor = True
        '
        'lblSearchDescription
        '
        Me.lblSearchDescription.AutoSize = True
        Me.lblSearchDescription.Location = New System.Drawing.Point(23, 95)
        Me.lblSearchDescription.Name = "lblSearchDescription"
        Me.lblSearchDescription.Size = New System.Drawing.Size(557, 13)
        Me.lblSearchDescription.TabIndex = 317
        Me.lblSearchDescription.Text = "Enter one of the fields:  Last & First Name, Student ID, Student email address, S" & _
            "tudent SSN, and click Search Record."
        '
        'Label103
        '
        Me.Label103.AutoSize = True
        Me.Label103.Font = New System.Drawing.Font("Times New Roman", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label103.Location = New System.Drawing.Point(23, 75)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(91, 16)
        Me.Label103.TabIndex = 316
        Me.Label103.Text = "How to search:"
        '
        'btnSaveChanges
        '
        Me.btnSaveChanges.Location = New System.Drawing.Point(467, 36)
        Me.btnSaveChanges.Name = "btnSaveChanges"
        Me.btnSaveChanges.Size = New System.Drawing.Size(102, 26)
        Me.btnSaveChanges.TabIndex = 504
        Me.btnSaveChanges.Text = "Save Changes"
        Me.btnSaveChanges.UseVisualStyleBackColor = True
        '
        'btnClearSearchFields
        '
        Me.btnClearSearchFields.Location = New System.Drawing.Point(245, 36)
        Me.btnClearSearchFields.Name = "btnClearSearchFields"
        Me.btnClearSearchFields.Size = New System.Drawing.Size(110, 26)
        Me.btnClearSearchFields.TabIndex = 502
        Me.btnClearSearchFields.Text = "Clear Search Fields"
        Me.btnClearSearchFields.UseVisualStyleBackColor = True
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(23, 114)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(143, 13)
        Me.Label52.TabIndex = 507
        Me.Label52.Text = "* Denotes a searchable field "
        '
        'lblBirthdayFormat
        '
        Me.lblBirthdayFormat.AutoSize = True
        Me.lblBirthdayFormat.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBirthdayFormat.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblBirthdayFormat.Location = New System.Drawing.Point(220, 129)
        Me.lblBirthdayFormat.Name = "lblBirthdayFormat"
        Me.lblBirthdayFormat.Size = New System.Drawing.Size(61, 10)
        Me.lblBirthdayFormat.TabIndex = 316
        Me.lblBirthdayFormat.Text = "YYYY-MM-DD"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label31.Location = New System.Drawing.Point(301, 116)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(61, 10)
        Me.Label31.TabIndex = 317
        Me.Label31.Text = "YYYY-MM-DD"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label37.Location = New System.Drawing.Point(209, 138)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(61, 10)
        Me.Label37.TabIndex = 318
        Me.Label37.Text = "YYYY-MM-DD"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label38.Location = New System.Drawing.Point(200, 329)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(61, 10)
        Me.Label38.TabIndex = 391
        Me.Label38.Text = "YYYY-MM-DD"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label39.Location = New System.Drawing.Point(280, 329)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(61, 10)
        Me.Label39.TabIndex = 392
        Me.Label39.Text = "YYYY-MM-DD"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label45.Location = New System.Drawing.Point(618, 329)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(61, 10)
        Me.Label45.TabIndex = 393
        Me.Label45.Text = "YYYY-MM-DD"
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label73.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label73.Location = New System.Drawing.Point(116, 143)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(61, 10)
        Me.Label73.TabIndex = 317
        Me.Label73.Text = "YYYY-MM-DD"
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label76.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label76.Location = New System.Drawing.Point(170, 273)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(61, 10)
        Me.Label76.TabIndex = 318
        Me.Label76.Text = "YYYY-MM-DD"
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label78.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label78.Location = New System.Drawing.Point(170, 315)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(61, 10)
        Me.Label78.TabIndex = 319
        Me.Label78.Text = "YYYY-MM-DD"
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label79.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label79.Location = New System.Drawing.Point(170, 359)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(61, 10)
        Me.Label79.TabIndex = 320
        Me.Label79.Text = "YYYY-MM-DD"
        '
        'frmApplicationForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(863, 642)
        Me.Controls.Add(Me.Label52)
        Me.Controls.Add(Me.btnClearSearchFields)
        Me.Controls.Add(Me.btnSaveChanges)
        Me.Controls.Add(Me.Label103)
        Me.Controls.Add(Me.lblSearchDescription)
        Me.Controls.Add(Me.btnSearchRecord)
        Me.Controls.Add(Me.btnDeleteRecord)
        Me.Controls.Add(Me.btnEditRecord)
        Me.Controls.Add(Me.btnAddRecord)
        Me.Controls.Add(Me.tabApplication)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmApplicationForm"
        Me.Text = "MIS Graduate Database System"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.tabApplication.ResumeLayout(False)
        Me.tabPersonalInfo.ResumeLayout(False)
        Me.tabPersonalInfo.PerformLayout()
        Me.TabAdmission.ResumeLayout(False)
        Me.TabAdmission.PerformLayout()
        Me.tabCredentials.ResumeLayout(False)
        Me.tabCredentials.PerformLayout()
        Me.tabStudentStatus.ResumeLayout(False)
        Me.tabStudentStatus.PerformLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tabApplication As System.Windows.Forms.TabControl
    Friend WithEvents tabPersonalInfo As System.Windows.Forms.TabPage
    Friend WithEvents TabAdmission As System.Windows.Forms.TabPage
    Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents txtMiddleName As System.Windows.Forms.TextBox
    Friend WithEvents txtLastName As System.Windows.Forms.TextBox
    Friend WithEvents lblMiddleName As System.Windows.Forms.Label
    Friend WithEvents lblFirstName As System.Windows.Forms.Label
    Friend WithEvents lblLastName As System.Windows.Forms.Label
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents lblDOB As System.Windows.Forms.Label
    Friend WithEvents lblSSN As System.Windows.Forms.Label
    Friend WithEvents txtPreferred As System.Windows.Forms.TextBox
    Friend WithEvents lblPreferredName As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cbxEthnic As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtRequestYear As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents chkEnrolled As System.Windows.Forms.CheckBox
    Friend WithEvents txtBefore_when As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents chkBefore As System.Windows.Forms.CheckBox
    Friend WithEvents chkRequested As System.Windows.Forms.CheckBox
    Friend WithEvents txtEnrolled_When As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents tabCredentials As System.Windows.Forms.TabPage
    Friend WithEvents txtGMATDate As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents txtGMATQuant As System.Windows.Forms.TextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents txtGMATVerbal As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents txtTSETotal As System.Windows.Forms.TextBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents txtTOEFLTotal As System.Windows.Forms.TextBox
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents txtGPASenior As System.Windows.Forms.TextBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents txtUnderGPA As System.Windows.Forms.TextBox
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents chkAppForm As System.Windows.Forms.CheckBox
    Friend WithEvents chkAppFeePaid As System.Windows.Forms.CheckBox
    Friend WithEvents chkResume As System.Windows.Forms.CheckBox
    Friend WithEvents chkGREScore As System.Windows.Forms.CheckBox
    Friend WithEvents chkGMATScore As System.Windows.Forms.CheckBox
    Friend WithEvents chkEssay As System.Windows.Forms.CheckBox
    Friend WithEvents chkTranscript As System.Windows.Forms.CheckBox
    Friend WithEvents chkLOR As System.Windows.Forms.CheckBox
    Friend WithEvents txtGMATTotal As System.Windows.Forms.TextBox
    Friend WithEvents chkFinancial As System.Windows.Forms.CheckBox
    Friend WithEvents chkEducation As System.Windows.Forms.CheckBox
    Friend WithEvents chkTOEFL As System.Windows.Forms.CheckBox
    Friend WithEvents chkTSE As System.Windows.Forms.CheckBox
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtLCity As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents txtLAddress As System.Windows.Forms.TextBox
    Friend WithEvents chkResident As System.Windows.Forms.CheckBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtFCity As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtFAddress As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtPCity As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtPAddress As System.Windows.Forms.TextBox
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents cbxPrimaryContactNumber As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents lblSession As System.Windows.Forms.Label
    Friend WithEvents cbxSession As System.Windows.Forms.ComboBox
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents cbxStanding As System.Windows.Forms.ComboBox
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents btnAddRecord As System.Windows.Forms.Button
    Friend WithEvents btnEditRecord As System.Windows.Forms.Button
    Friend WithEvents btnDeleteRecord As System.Windows.Forms.Button
    Friend WithEvents btnSearchRecord As System.Windows.Forms.Button
    Friend WithEvents txtStudentID As System.Windows.Forms.TextBox
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents cbxCitizenship As System.Windows.Forms.ComboBox
    Friend WithEvents cbxGender As System.Windows.Forms.ComboBox
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents tabStudentStatus As System.Windows.Forms.TabPage
    Friend WithEvents Label89 As System.Windows.Forms.Label
    Friend WithEvents lblStudentName As System.Windows.Forms.Label
    Friend WithEvents Label96 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents lblSearchDescription As System.Windows.Forms.Label
    Friend WithEvents Label103 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents txtTSEDate As System.Windows.Forms.TextBox
    Friend WithEvents txtTOEFLDate As System.Windows.Forms.TextBox
    Friend WithEvents txtDateAccepted As System.Windows.Forms.TextBox
    Friend WithEvents txtAcceptedOffer As System.Windows.Forms.TextBox
    Friend WithEvents txtDDate As System.Windows.Forms.TextBox
    Friend WithEvents txtDeclined As System.Windows.Forms.TextBox
    Friend WithEvents txtDEnrolled As System.Windows.Forms.TextBox
    Friend WithEvents txtSEnrolled As System.Windows.Forms.TextBox
    Friend WithEvents txtDateApplied As System.Windows.Forms.TextBox
    Friend WithEvents txtAStatus As System.Windows.Forms.TextBox
    Friend WithEvents txtFeePaid As System.Windows.Forms.TextBox
    Friend WithEvents txtStatus As System.Windows.Forms.TextBox
    Friend WithEvents Label102 As System.Windows.Forms.Label
    Friend WithEvents Label101 As System.Windows.Forms.Label
    Friend WithEvents Label100 As System.Windows.Forms.Label
    Friend WithEvents lblStudentID As System.Windows.Forms.Label
    Friend WithEvents Label98 As System.Windows.Forms.Label
    Friend WithEvents Label92 As System.Windows.Forms.Label
    Friend WithEvents Label88 As System.Windows.Forms.Label
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents btnSaveChanges As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents txtNotes As System.Windows.Forms.TextBox
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cbxOrigin As System.Windows.Forms.ComboBox
    Friend WithEvents btnClearSearchFields As System.Windows.Forms.Button
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents txtSSN As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtPPhone As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtWorkPhone As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtCurrentPhone As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtPZipCode As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtLZipCode As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtFZipCode As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtCFrom1 As System.Windows.Forms.TextBox
    Friend WithEvents txtCFrom2 As System.Windows.Forms.TextBox
    Friend WithEvents txtCTo1 As System.Windows.Forms.TextBox
    Friend WithEvents txtCTo2 As System.Windows.Forms.TextBox
    Friend WithEvents Label95 As System.Windows.Forms.Label
    Friend WithEvents Label94 As System.Windows.Forms.Label
    Friend WithEvents txtDegreeDate2 As System.Windows.Forms.TextBox
    Friend WithEvents txtDegreeDate1 As System.Windows.Forms.TextBox
    Friend WithEvents Label93 As System.Windows.Forms.Label
    Friend WithEvents txtMajor2 As System.Windows.Forms.TextBox
    Friend WithEvents txtMajor1 As System.Windows.Forms.TextBox
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents txtCurrentHours2 As System.Windows.Forms.TextBox
    Friend WithEvents txtCurrentHours1 As System.Windows.Forms.TextBox
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents txtDegree2 As System.Windows.Forms.TextBox
    Friend WithEvents txtDegree1 As System.Windows.Forms.TextBox
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents txtHoursEarned2 As System.Windows.Forms.TextBox
    Friend WithEvents txtHoursEarned1 As System.Windows.Forms.TextBox
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents txtCGPA2 As System.Windows.Forms.TextBox
    Friend WithEvents txtCGPA1 As System.Windows.Forms.TextBox
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents txtCName2 As System.Windows.Forms.TextBox
    Friend WithEvents txtCName1 As System.Windows.Forms.TextBox
    Friend WithEvents cbxPState As System.Windows.Forms.ComboBox
    Friend WithEvents cbxFState As System.Windows.Forms.ComboBox
    Friend WithEvents cbxLState As System.Windows.Forms.ComboBox
    Friend WithEvents txtBirthday1 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtFYears As System.Windows.Forms.TextBox
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents txtPYears As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents EditToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblBirthdayFormat As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents Label73 As System.Windows.Forms.Label

End Class
