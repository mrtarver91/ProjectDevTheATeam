Option Strict On

Public Class Search


End Class
