Imports System.Data
Imports System.Data.Odbc

Public Class DBConnector
    ' Set up instance variables such as the connection string for the DB
    Shared _dc As String = "DSN=Walton College Teradata;UID=ES999999;PWD=#%$345"
    Public Function GetDataSet(ByVal query As String) As DataSet
        Dim con As OdbcConnection = Nothing
        Dim command As OdbcCommand = Nothing
        Dim da As OdbcDataAdapter
        Dim ds As New DataSet

        Try
            ' Make the database connection
            con = New OdbcConnection(_dc)
            con.Open()
            command = New OdbcCommand(query, con)

            ' Run the query to fill the dataset
            da = New OdbcDataAdapter()
            da.SelectCommand = command
            da.Fill(ds)
        Finally
            ' Close the connection and Return the dataset
            If Not con Is Nothing Then con.Close()
            If Not command Is Nothing Then command.Dispose()
        End Try

        Return ds

    End Function
    Public Function ExecuteNonQuery(ByVal query As String) As Integer
        Dim con As OdbcConnection = Nothing
        Dim command As OdbcCommand = Nothing
        Dim result As Integer = 0

        Try
            ' Make the database connection
            con = New OdbcConnection(_dc)
            command = New OdbcCommand(query, con)
            con.Open()
            ' Execute a "non-query" (doesn't return any result sets)
            result = command.ExecuteNonQuery()
        Finally
            If Not con Is Nothing Then con.Close()
            If Not command Is Nothing Then command.Dispose()
        End Try

        Return result

    End Function

    Public Function GetDataReader(ByVal query As String) As OdbcDataReader
        Dim con As OdbcConnection = Nothing
        Dim command As OdbcCommand = Nothing

        Try
            ' Make the database connection
            con = New OdbcConnection(_dc)
            con.Open()
            command = New OdbcCommand(query, con)
            ' Run the query to fill the reader
            Return command.ExecuteReader(System.Data.CommandBehavior.CloseConnection)
        Finally
            ' Close the connection and Return the dataset
            If Not command Is Nothing Then command.Dispose()
        End Try

    End Function
End Class

